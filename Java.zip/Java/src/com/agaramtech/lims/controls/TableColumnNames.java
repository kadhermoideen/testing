package com.agaramtech.lims.controls;


public class TableColumnNames {
	 
	private String scolumname;
	private String sdatatype;
	
	public String getscolumname() {
		return scolumname;
	}
	public void setscolumname(String scolumname) {
		this.scolumname = scolumname;
	}
	public String getsdatatype() {
		return sdatatype;
	}
	public void setSdatatype(String sdatatype) {
		this.sdatatype = sdatatype;
	}
	
	
}

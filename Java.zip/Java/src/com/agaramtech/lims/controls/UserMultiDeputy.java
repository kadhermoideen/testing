/**
 * @author Subha
 * @Date 09-May-2014
 * @time 14:45:19 PM
 */
package com.agaramtech.lims.controls;
import java.io.Serializable;
import java.sql.SQLException;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.agaramtech.lims.dao.support.AgaramResultSetMapper;
import com.agaramtech.lims.dao.support.AgaramRowMapper;

@Entity
@Table(name = "usermultideputy")
@SuppressWarnings("serial")
public class UserMultiDeputy implements Serializable,AgaramRowMapper<UserMultiDeputy>{

	@Id
	@Column(name = "nusermultideputycode")private int nusermultideputycode;
	@Column(name = "nusercode")private int  nusercode;
	@Column(name = "ndeputyusercode")private int  ndeputyusercode ;
	@Column(name = "nuserrolecode")private int  nuserrolecode;
	@Column(name = "ntransactionstatus")private int  ntransactionstatus;
	@Column(name = "nstatus")private int  nstatus ;
	@Column(name = "ncreatedby")private int  ncreatedby;
	@Column(name = "dcreateddate")private Date dcreateddate;
	@Column(name = "nmodifiedby")private int nmodifiedby;
	@Column(name = "dmodifieddate")private Date dmodifieddate;



	public int getnusermultideputycode() {
		return nusermultideputycode;
	}

	public void setnusermultideputycode(int nusermultideputycode) {
		this.nusermultideputycode = nusermultideputycode;
	}

	public int getnusercode() {
		return nusercode;
	}

	public void setnusercode(int nusercode) {
		this.nusercode = nusercode;
	}

	public int getndeputyusercode() {
		return ndeputyusercode;
	}

	public void setndeputyusercode(int ndeputyusercode) {
		this.ndeputyusercode = ndeputyusercode;
	}

	public int getnuserrolecode() {
		return nuserrolecode;
	}

	public void setnuserrolecode(int nuserrolecode) {
		this.nuserrolecode = nuserrolecode;
	}

	public int getntransactionstatus() {
		return ntransactionstatus;
	}

	public void setntransactionstatus(int ntransactionstatus) {
		this.ntransactionstatus = ntransactionstatus;
	}

	public int getnstatus() {
		return nstatus;
	}

	public void setnstatus(int nstatus) {
		this.nstatus = nstatus;
	}

	public int getncreatedby() {
		return ncreatedby;
	}

	public void setncreatedby(int sbloodgroup) {
		this.ncreatedby = sbloodgroup;
	}

	public Date getdcreateddate() {
		return dcreateddate;
	}

	public void setdcreateddate(Date dcreateddate) {
		this.dcreateddate = dcreateddate;
	}

	public int getnmodifiedby() {
		return nmodifiedby;
	}

	public void setnmodifiedby(int nmodifiedby) {
		this.nmodifiedby = nmodifiedby;
	}

	public Date getdmodifieddate() {
		return dmodifieddate;
	}

	public void setdmodifieddate(Date dmodifieddate) {
		this.dmodifieddate = dmodifieddate;
	}

	transient String sdeputyid;
	transient String sdeputyname;
	transient String suserrolename;
	transient String stransdisplaystatus;




	public String getsdeputyid() {
		return sdeputyid;
	}

	public void setsdeputyid(String sdeputyid) {
		this.sdeputyid = sdeputyid;
	}

	public String getsdeputyname() {
		return sdeputyname;
	}

	public void setsdeputyname(String sdeputyname) {
		this.sdeputyname = sdeputyname;
	}

	public String getsuserrolename() {
		return suserrolename;
	}

	public void setsuserrolename(String suserrolename) {
		this.suserrolename = suserrolename;
	}

	public String getstransdisplaystatus() {
		return stransdisplaystatus;
	}

	public void setstransdisplaystatus(String stransdisplaystatus) {
		this.stransdisplaystatus = stransdisplaystatus;
	}

	@Override
	public String isActiveFilter(AgaramResultSetMapper<Object> arg0)
			throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public UserMultiDeputy mapRow(AgaramResultSetMapper<Object> objMapper) throws SQLException {

		UserMultiDeputy objUserMultiDeputy = new UserMultiDeputy();
		objUserMultiDeputy.setdmodifieddate(objMapper.getDate("dmodifieddate"));
		objUserMultiDeputy.setnstatus(objMapper.getInteger("nstatus"));
		objUserMultiDeputy.setntransactionstatus(objMapper.getInteger("ntransactionstatus"));
		objUserMultiDeputy.setndeputyusercode(objMapper.getInteger("ndeputyusercode"));
		objUserMultiDeputy.setnuserrolecode(objMapper.getInteger("nuserrolecode"));
		objUserMultiDeputy.setncreatedby(objMapper.getInteger("ncreatedby"));
		objUserMultiDeputy.setdcreateddate(objMapper.getDate("dcreateddate"));
		objUserMultiDeputy.setnusercode(objMapper.getInteger("nusercode"));
		objUserMultiDeputy.setnmodifiedby(objMapper.getInteger("nmodifiedby"));
		objUserMultiDeputy.setnusermultideputycode(objMapper.getInteger("nusermultideputycode"));
		objUserMultiDeputy.setsdeputyid(objMapper.getString("sdeputyid"));
		objUserMultiDeputy.setsdeputyname(objMapper.getString("sdeputyname"));
		objUserMultiDeputy.setsuserrolename(objMapper.getString("suserrolename"));
		objUserMultiDeputy.setstransdisplaystatus(objMapper.getString("stransdisplaystatus"));
		return objUserMultiDeputy;
	}


}

package com.agaramtech.lims.controls;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="pairdesigndetails")
@SuppressWarnings("serial")

public class PairDesignDetails implements Serializable {

	@Id
	@Column(name="npaircode") private int npaircode;
	@Column(name="ndesingcode") private int ndesingcode;
	@Column(name="sfieldname",length=75) private String sfieldname;
	@Column(name="sdisplayname",length=75) private String sdisplayname;
	@Column(name="slabelfield",length=100) private String slabelfield;
	@Column(name="sdatatype",length=50) private String sdatatype;
	@Column(name="nsize") private int nsize;
	@Column(name="ncontrolcode") private int ncontrolcode;
	@Column(name="nmandatry") private int nmandatry;
	@Column(name="nlinktype") private int nlinktype;
	@Column(name="nlinktablecode") private int nlinktablecode;
	@Column(name="scriteria",length=500) private String scriteria;
	@Column(name="nstatus") private int nstatus;

	public int getnpaircode() {
		return npaircode;
	}
	public void setnpaircode(int npaircode) {
		this.npaircode = npaircode;
	}
	public int getndesingcode() {
		return ndesingcode;
	}
	public void setndesingcode(int ndesingcode) {
		this.ndesingcode = ndesingcode;
	}
	public String getsfieldname() {
		return sfieldname;
	}
	public void setsfieldname(String sfieldname) {
		this.sfieldname = sfieldname;
	}
	public String getsdisplayname() {
		return sdisplayname;
	}
	public void setsdisplayname(String sdisplayname) {
		this.sdisplayname = sdisplayname;
	}
	public String getslabelfield() {
		return slabelfield;
	}
	public void setslabelfield(String slabelfield) {
		this.slabelfield = slabelfield;
	}
	public String getsdatatype() {
		return sdatatype;
	}
	public void setsdatatype(String sdatatype) {
		this.sdatatype = sdatatype;
	}
	public int getnsize() {
		return nsize;
	}
	public void setnsize(int nsize) {
		this.nsize = nsize;
	}
	public int getncontrolcode() {
		return ncontrolcode;
	}
	public void setncontrolcode(int ncontrolcode) {
		this.ncontrolcode = ncontrolcode;
	}
	public int getnmandatry() {
		return nmandatry;
	}
	public void setnmandatry(int nmandatry) {
		this.nmandatry = nmandatry;
	}
	public int getnlinktype() {
		return nlinktype;
	}
	public void setnlinktype(int nlinktype) {
		this.nlinktype = nlinktype;
	}
	public int getnlinktablecode() {
		return nlinktablecode;
	}
	public void setnlinktablecode(int nlinktablecode) {
		this.nlinktablecode = nlinktablecode;
	}
	public String getscriteria() {
		return scriteria;
	}
	public void setscriteria(String scriteria) {
		this.scriteria = scriteria;
	}
	public int getnstatus() {
		return nstatus;
	}
	public void setnstatus(int nstatus) {
		this.nstatus = nstatus;
	}

}

package com.agaramtech.lims.controls;

import java.io.Serializable;
import java.sql.SQLException;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.agaramtech.lims.dao.support.AgaramResultSetMapper;
import com.agaramtech.lims.dao.support.AgaramRowMapper;

@Entity
@Table(name="CustomLinkTable")
@SuppressWarnings("serial")

/**
 * @author Kadher Moideen S
 *
 * Aug 10, 2012 5:39:04 PM
 */
public class CustomLinkTable implements Serializable,AgaramRowMapper<CustomLinkTable>
{
	@Id
	@Column(name="nCustomCode") private int nCustomCode;
	@Column(name="sCustomValue",length=150) private String sCustomValue;
	@Column(name="nControlCode") private int nControlCode;
	@Column(name="nDesingCode") private int nDesingCode;
	@Column(name="nRegistrationTypeCode") private int nRegistrationTypeCode;
	@Column(name="nStatus") private int nStatus;
	@Transient
	private int nRunningNumber;
	
	transient private String sFieldName;
	transient private String sDisplayName;

	public String getsFieldName() {
		return sFieldName;
	}
	public void setsFieldName(String sFieldName) {
		this.sFieldName = sFieldName;
	}
	public String getsDisplayName() {
		return sDisplayName;
	}
	public void setsDisplayName(String sDisplayName) {
		this.sDisplayName = sDisplayName;
	}
	
	
	public int getnRunningNumber() {
		return nRunningNumber;
	}
	public void setnRunningNumber(int nRunningNumber) {
		this.nRunningNumber = nRunningNumber;
	}
	/**
	 * @return the nCustomCode
	 */
	public int getnCustomCode() {
		return nCustomCode;
	}
	/**
	 * @param nCustomCode the nCustomCode to set
	 */
	public void setnCustomCode(int nCustomCode) {
		this.nCustomCode = nCustomCode;
	}
	/**
	 * @return the sCustomValue
	 */
	public String getsCustomValue() {
		return sCustomValue;
	}
	/**
	 * @param sCustomValue the sCustomValue to set
	 */
	public void setsCustomValue(String sCustomValue) {
		this.sCustomValue = sCustomValue;
	}
	/**
	 * @return the nControlCode
	 */
	public int getnControlCode() {
		return nControlCode;
	}
	/**
	 * @param nControlCode the nControlCode to set
	 */
	public void setnControlCode(int nControlCode) {
		this.nControlCode = nControlCode;
	}
	/**
	 * @return the nDesingCode
	 */
	public int getnDesingCode() {
		return nDesingCode;
	}
	/**
	 * @param nDesingCode the nDesingCode to set
	 */
	public void setnDesingCode(int nDesingCode) {
		this.nDesingCode = nDesingCode;
	}
	/**
	 * @return the nRegistrationTypeCode
	 */
	public int getnRegistrationTypeCode() {
		return nRegistrationTypeCode;
	}
	/**
	 * @param nRegistrationTypeCode the nRegistrationTypeCode to set
	 */
	public void setnRegistrationTypeCode(int nRegistrationTypeCode) {
		this.nRegistrationTypeCode = nRegistrationTypeCode;
	}
	/**
	 * @return the nStatus
	 */
	public int getnStatus() {
		return nStatus;
	}
	/**
	 * @param nStatus the nStatus to set
	 */
	public void setnStatus(int nStatus) {
		this.nStatus = nStatus;
	}
	@Override
	public CustomLinkTable mapRow(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {
		CustomLinkTable objCustomLinkTable=new CustomLinkTable();
		objCustomLinkTable.setnCustomCode(objMapper.getInteger("nCustomCode"));
		objCustomLinkTable.setnControlCode(objMapper.getInteger("nControlCode"));
		objCustomLinkTable.setnRegistrationTypeCode(objMapper.getInteger("nRegistrationTypeCode"));
		objCustomLinkTable.setnStatus(objMapper.getInteger("nStatus"));
		objCustomLinkTable.setsCustomValue(objMapper.getString("sCustomValue"));
		objCustomLinkTable.setnDesingCode(objMapper.getInteger("nDesingCode"));
		objCustomLinkTable.setsDisplayName(objMapper.getString("sDisplayName"));
		objCustomLinkTable.setsFieldName(objMapper.getString("sFieldName"));
		return objCustomLinkTable;
	}
	@Override
	public String isActiveFilter(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {
		objMapper.setfield("nStatus");
		objMapper.setvalue(1);
		return objMapper.toString();
	}

}


package com.agaramtech.lims.controls;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.agaramtech.lims.base.RunningMaker;

@Entity
@Table(name="DesignMaster")
@SuppressWarnings("serial")

/**
 * @author Kadher Moideen S
 *
 * Aug 10, 2012 3:29:04 PM
 */
public class DesignMaster implements Serializable
{
	private RunningMaker objMaker = new RunningMaker();
	@Id
	@Column(name="nDesingCode") private int nDesingCode;
	@Column(name="sFieldName",length=75) private String sFieldName;
	@Column(name="sDisplayName",length=75) private String sDisplayName;
	@Column(name="sDataType",length=50) private String sDataType;
	@Column(name="nSize") private int nSize;
	@Column(name="nControlCode") private int nControlCode;
	@Column(name="nMandatry") private int nMandatry;
	@Column(name="nLinkType") private int nLinkType;
	@Column(name="nLinkTableCode") private int nLinkTableCode;
	@Column(name="nRegistrationTypeCode") private int nRegistrationTypeCode;
	@Column(name="sCriteria",length=500) private String sCriteria;
	@Column(name="nStatus") private int nStatus;
	@Column(name="ntablecode") private int ntablecode;
	@Column(name="ntreenodecode") private int ntreenodecode;
	@Transient
	private int nRunningNumber;
	
	

	public RunningMaker getObjMaker() {
		return objMaker;
	}
	public void setObjMaker(RunningMaker objMaker) {
		this.objMaker = objMaker;
	}
	public int getnRunningNumber() {
		return nRunningNumber;
	}
	public void setnRunningNumber(int nRunningNumber) {
		this.nRunningNumber = nRunningNumber;
	}
	/**
	 * @return the nDesingCode
	 */
	public int getnDesingCode() {
		return nDesingCode;
	}
	/**
	 * @param nDesingCode the nDesingCode to set
	 */
	public void setnDesingCode(int nDesingCode) {
		this.nDesingCode = nDesingCode;
	}
	/**
	 * @return the sFieldName
	 */
	public String getsFieldName() {
		return sFieldName;
	}
	/**
	 * @param sFieldName the sFieldName to set
	 */
	public void setsFieldName(String sFieldName) {
		this.sFieldName = sFieldName;
	}
	/**
	 * @return the sDisplayName
	 */
	public String getsDisplayName() {
		return sDisplayName;
	}
	/**
	 * @param sDisplayName the sDisplayName to set
	 */
	public void setsDisplayName(String sDisplayName) {
		this.sDisplayName = sDisplayName;
	}
	/**
	 * @return the sDataType
	 */
	public String getsDataType() {
		return sDataType;
	}
	/**
	 * @param sDataType the sDataType to set
	 */
	public void setsDataType(String sDataType) {
		this.sDataType = sDataType;
	}
	/**
	 * @return the nSize
	 */
	public int getnSize() {
		return nSize;
	}
	/**
	 * @param nSize the nSize to set
	 */
	public void setnSize(int nSize) {
		this.nSize = nSize;
	}
	/**
	 * @return the nControlCode
	 */
	public int getnControlCode() {
		return nControlCode;
	}
	/**
	 * @param nControlCode the nControlCode to set
	 */
	public void setnControlCode(int nControlCode) {
		this.nControlCode = nControlCode;
	}
	/**
	 * @return the nMandatry
	 */
	public int getnMandatry() {
		return nMandatry;
	}
	/**
	 * @param nMandatry the nMandatry to set
	 */
	public void setnMandatry(int nMandatry) {
		this.nMandatry = nMandatry;
	}
	/**
	 * @return the nLinkType
	 */
	public int getnLinkType() {
		return nLinkType;
	}
	/**
	 * @param nLinkType the nLinkType to set
	 */
	public void setnLinkType(int nLinkType) {
		this.nLinkType = nLinkType;
	}
	/**
	 * @return the nLinkTableCode
	 */
	public int getnLinkTableCode() {
		return nLinkTableCode;
	}
	/**
	 * @param nLinkTableCode the nLinkTableCode to set
	 */
	public void setnLinkTableCode(int nLinkTableCode) {
		this.nLinkTableCode = nLinkTableCode;
	}
	/**
	 * @return the nRegistrationTypeCode
	 */
	public int getnRegistrationTypeCode() {
		return nRegistrationTypeCode;
	}
	/**
	 * @param nRegistrationTypeCode the nRegistrationTypeCode to set
	 */
	public void setnRegistrationTypeCode(int nRegistrationTypeCode) {
		this.nRegistrationTypeCode = nRegistrationTypeCode;
	}
	/**
	 * @return the sCriteria
	 */
	public String getsCriteria() {
		return sCriteria;
	}
	/**
	 * @param sCriteria the sCriteria to set
	 */
	public void setsCriteria(String sCriteria) {
		this.sCriteria = sCriteria;
	}
	/**
	 * @return the nStatus
	 */
	public int getnStatus() {
		return nStatus;
	}
	/**
	 * @param nStatus the nStatus to set
	 */
	public void setnStatus(int nStatus) {
		this.nStatus = nStatus;
	}
	public int getntablecode() {
		return ntablecode;
	}
	public void setntablecode(int ntablecode) {
		this.ntablecode = ntablecode;
	}
	public int getntreenodecode() {
		return ntreenodecode;
	}
	public void setntreenodecode(int ntreenodecode) {
		this.ntreenodecode = ntreenodecode;
	}

}

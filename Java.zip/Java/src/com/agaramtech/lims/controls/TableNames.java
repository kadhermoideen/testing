package com.agaramtech.lims.controls;

import java.io.Serializable;
import java.sql.SQLException;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.agaramtech.lims.dao.support.AgaramResultSetMapper;
import com.agaramtech.lims.dao.support.AgaramRowMapper;


@Entity
@Table(name="tablenames")
@SuppressWarnings("serial")

public class TableNames implements Serializable, AgaramRowMapper<TableNames> {
	@Id
	@Column(name="ntablecode") private int ntablecode;
	@Column(name="sclassname",length=100) private String sclassname;
	@Column(name="stablename",length=100) private String stablename;
	@Column(name="nhassub") private int nhassub;
	@Column(name="nsubtablecode") private int nsubtablecode;
	@Column(name="sprimarycolumn",length=100) private String sprimarycolumn;
	@Column(name="nstatus") private int nstatus;
	@Column(name="nformcode") private int nformcode;
	@Column(name="suniquecolumn") private String suniquecolumn;
	@Column(name="ssecondarycolumn") private String ssecondarycolumn;
	
	public int getntablecode() {
		return ntablecode;
	}
	public void setntablecode(int ntablecode) {
		this.ntablecode = ntablecode;
	}
	public String getsclassname() {
		return sclassname;
	}
	public void setsclassname(String sclassname) {
		this.sclassname = sclassname;
	}
	public String getstablename() {
		return stablename;
	}
	public void setstablename(String stablename) {
		this.stablename = stablename;
	}
	public int getnstatus() {
		return nstatus;
	}
	public void setnstatus(int nstatus) {
		this.nstatus = nstatus;
	}
	public int getnhassub() {
		return nhassub;
	}
	public void setnhassub(int nhassub) {
		this.nhassub = nhassub;
	}
	public int getnsubtablecode() {
		return nsubtablecode;
	}
	public void setnsubtablecode(int nsubtablecode) {
		this.nsubtablecode = nsubtablecode;
	}
	public String getsprimarycolumn() {
		return sprimarycolumn;
	}
	public void setsprimarycolumn(String sprimarycolumn) {
		this.sprimarycolumn = sprimarycolumn;
	}

	public int getnformcode() {
		return nformcode;
	}
	public void setnformcode(int nformcode) {
		this.nformcode = nformcode;
	}
	public String getsuniquecolumn() {
		return suniquecolumn;
	}
	public void setsuniquecolumn(String suniquecolumn) {
		this.suniquecolumn = suniquecolumn;
	}
	
	public String getssecondarycolumn() {
		return ssecondarycolumn;
	}
	public void setssecondarycolumn(String ssecondarycolumn) {
		this.ssecondarycolumn = ssecondarycolumn;
	}
	@Override
	public TableNames mapRow(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {
		TableNames objNames = new TableNames();
		objNames.setntablecode(objMapper.getInteger("ntablecode"));
		objNames.setsclassname(objMapper.getString("sclassname"));
		objNames.setstablename(objMapper.getString("stablename"));
		objNames.setsprimarycolumn(objMapper.getString("sprimarycolumn"));
		objNames.setnstatus(objMapper.getInteger("nstatus"));
		objNames.setnhassub(objMapper.getInteger("nhassub"));
		objNames.setnsubtablecode(objMapper.getInteger("nsubtablecode"));
		objNames.setnformcode(objMapper.getInteger("nformcode"));
		objNames.setsuniquecolumn(objMapper.getString("suniquecolumn"));
		objNames.setssecondarycolumn(objMapper.getString("ssecondarycolumn"));
		
		return objNames;
	}
	@Override
	public String isActiveFilter(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}


}

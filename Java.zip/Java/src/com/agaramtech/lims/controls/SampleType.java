package com.agaramtech.lims.controls;

import java.sql.SQLException;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.agaramtech.lims.dao.support.AgaramResultSetMapper;
import com.agaramtech.lims.dao.support.AgaramRowMapper;

@Entity
@Table(name = "SampleType")
@SuppressWarnings("serial")
public class SampleType implements java.io.Serializable, AgaramRowMapper<SampleType> {
	@Id
	private Integer nsampletypecode;

	public Integer getnsampletypecode() {
		return nsampletypecode;
	}

	public void setnsampletypecode(Integer nsampletypecode) {
		this.nsampletypecode = nsampletypecode;
	}

	private String ssamptype;

	public String getssamptype() {
		return ssamptype;
	}

	public void setssamptype(String ssamptype) {
		this.ssamptype = ssamptype;
	}

	private String sdescription;

	public String getsdescription() {
		return sdescription;
	}

	public void setsdescription(String sdescription) {
		this.sdescription = sdescription;
	}

	private String sstatus;

	public String getsstatus() {
		return sstatus;
	}

	public void setsstatus(String sstatus) {
		this.sstatus = sstatus;
	}

	private String screatedby;

	public String getscreatedby() {
		return screatedby;
	}

	public void setscreatedby(String screatedby) {
		this.screatedby = screatedby;
	}

	private Date dcreateddate;

	public Date getdcreateddate() {
		return dcreateddate;
	}

	public void setdcreateddate(Date dcreateddate) {
		this.dcreateddate = dcreateddate;
	}

	private String smodifiedby;

	public String getsmodifiedby() {
		return smodifiedby;
	}

	public void setsmodifiedby(String smodifiedby) {
		this.smodifiedby = smodifiedby;
	}

	private Date dmodifieddate;

	public Date getdmodifieddate() {
		return dmodifieddate;
	}

	public void setdmodifieddate(Date dmodifieddate) {
		this.dmodifieddate = dmodifieddate;
	}

	private String sseqtable;

	public String getsseqtable() {
		return sseqtable;
	}

	public void setsseqtable(String sseqtable) {
		this.sseqtable = sseqtable;
	}

	private Integer nconcodinate;

	public Integer getnconcodinate() {
		return nconcodinate;
	}

	public void setnconcodinate(Integer nconcodinate) {
		this.nconcodinate = nconcodinate;
	}

	private String sprefix;

	/**
	 * @return the sprefix
	 */
	public String getsprefix() {
		return sprefix;
	}

	/**
	 * @param sprefix
	 *            the sprefix to set
	 */
	public void setsprefix(String sprefix) {
		this.sprefix = sprefix;
	}

	// identify for Raw Material or Other Product
	private Integer nscreentype;

	public Integer getnscreentype() {
		return nscreentype;
	}

	public void setnscreentype(Integer nscreentype) {
		this.nscreentype = nscreentype;
	}

	private Integer norderno;

	public Integer getnorderno() {
		return norderno;
	}

	public void setnorderno(Integer norderno) {
		this.norderno = norderno;
	}

	private String sdisplaysamptype;

	public String getsdisplaysamptype() {
		return sdisplaysamptype;
	}

	public void setsdisplaysamptype(String sdisplaysamptype) {
		this.sdisplaysamptype = sdisplaysamptype;
	}

	@Override
	public SampleType mapRow(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {
		SampleType objSample = new SampleType();

		objSample.setnsampletypecode(objMapper.getInteger("nsampletypecode"));
		objSample.setssamptype(objMapper.getString("ssamptype"));
		objSample.setsdescription(objMapper.getString("sdescription"));
		objSample.setsstatus(objMapper.getString("sstatus"));
		objSample.setscreatedby(objMapper.getString("screatedby"));
		objSample.setdcreateddate(objMapper.getDate("dcreateddate"));
		objSample.setsmodifiedby(objMapper.getString("smodifiedby"));
		objSample.setdmodifieddate(objMapper.getDate("dmodifieddate"));

		objSample.setsseqtable(objMapper.getString("sseqtable"));
		objSample.setnconcodinate(objMapper.getInteger("nconcodinate"));
		objSample.setsprefix(objMapper.getString("sprefix"));

		objSample.setnscreentype(objMapper.getInteger("nscreentype"));
		objSample.setnorderno(objMapper.getInteger("norderno"));
		objSample.setsdisplaysamptype(objMapper.getString("sdisplaysamptype"));

		return objSample;
	}

	@Override
	public String isActiveFilter(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}


	/* Code Starts Here */
	/* Code Ends Here */
}

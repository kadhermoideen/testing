package com.agaramtech.lims.controls;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "exportsampletype")
@SuppressWarnings("serial")
public class ExportSampleType implements java.io.Serializable {
	@Id
	@Column(name="nexporttypeno") private int nexporttypeno;
	@Column(name="nsampletypecode")private int nsampletypecode;
	@Column(name="scountryname")private String scountryname;
	@Column(name="nstatus")private int nstatus;
	@Column(name="nsitecode")private int nsitecode;
	@Column(name="norderno")private int norderno;
	@Column(name="sdisplaycountryname")private String sdisplaycountryname;
	@Column(name="ntreemastercode")private int ntreemastercode;
	
	public int getnorderno() {
		return norderno;
	}
	public void setnorderno(int norderno) {
		this.norderno = norderno;
	}
	public int getnexporttypeno() {
		return nexporttypeno;
	}
	public void setnexporttypeno(int nexporttypeno) {
		this.nexporttypeno = nexporttypeno;
	}
	public int getnsampletypecode() {
		return nsampletypecode;
	}
	public void setnsampletypecode(int nsampletypecode) {
		this.nsampletypecode = nsampletypecode;
	}
	public String getscountryname() {
		return scountryname;
	}
	public void setscountryname(String scountryname) {
		this.scountryname = scountryname;
	}
	public int getnstatus() {
		return nstatus;
	}
	public void setnstatus(int nstatus) {
		this.nstatus = nstatus;
	}
	public int getnsitecode() {
		return nsitecode;
	}
	public void setnsitecode(int nsitecode) {
		this.nsitecode = nsitecode;
	}
	public String getsdisplaycountryname() {
		return sdisplaycountryname;
	}
	public void setsdisplaycountryname(String sdisplaycountryname) {
		this.sdisplaycountryname = sdisplaycountryname;
	}
	public int getntreemastercode() {
		return ntreemastercode;
	}
	public void setntreemastercode(int ntreemastercode) {
		this.ntreemastercode = ntreemastercode;
	}


}

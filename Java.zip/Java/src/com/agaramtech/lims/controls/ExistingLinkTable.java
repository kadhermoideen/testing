package com.agaramtech.lims.controls;

import java.io.Serializable;
import java.sql.SQLException;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.agaramtech.lims.dao.support.AgaramResultSetMapper;
import com.agaramtech.lims.dao.support.AgaramRowMapper;

@Entity
@Table(name="ExistingLinkTable")
@SuppressWarnings("serial")

/**
 * @author Kadher Moideen S
 *
 * Aug 10, 2012 5:40:04 PM
 */
public class ExistingLinkTable implements Serializable,AgaramRowMapper<ExistingLinkTable>
{
	@Id
	@Column(name="nExistingCode") private int nExistingCode;
	@Column(name="sExistingTableName",length=100) private String sExistingTableName;
	@Column(name="sExistingClassName",length=200) private String sExistingClassName;
	@Column(name="sDisplayMember",length=100) private String sDisplayMember;
	@Column(name="sValueMember",length=100) private String sValueMember;
	@Column(name="nStatus") private Integer nStatus;
	
	
	@Column(name="sExistingClassName1",length=200) private Float sExistingClassName1;
	@Column(name="sDisplayMember1",length=100) private float sDisplayMember1;
	@Column(name="sValueMember1",length=100) private byte sValueMember1;
	@Column(name="nStatus1") private Byte nStatus1;
	
	@Column(name="sExistingClassName2",length=200) private Short sExistingClassName2;
	@Column(name="sDisplayMember2",length=100) private short sDisplayMember2;
	@Column(name="sValueMember2",length=100) private double sValueMember2;
	@Column(name="nStatus2") private Double nStatus2;
	
	@Column(name="sExistingClassName3",length=200) private Date sExistingClassName3;
	@Column(name="sDisplayMember3",length=100) private long sDisplayMember3;
	@Column(name="sValueMember3",length=100) private Long sValueMember3;
	@Column(name="nStatus3") private Boolean nStatus3;
	@Column(name="nStatus4") private boolean nStatus4;
	
	public int getnExistingCode() {
		return nExistingCode;
	}
	public void setnExistingCode(int nExistingCode) {
		this.nExistingCode = nExistingCode;
	}
	public String getsExistingTableName() {
		return sExistingTableName;
	}
	public void setsExistingTableName(String sExistingTableName) {
		this.sExistingTableName = sExistingTableName;
	}
	public String getsExistingClassName() {
		return sExistingClassName;
	}
	public void setsExistingClassName(String sExistingClassName) {
		this.sExistingClassName = sExistingClassName;
	}
	public String getsDisplayMember() {
		return sDisplayMember;
	}
	public void setsDisplayMember(String sDisplayMember) {
		this.sDisplayMember = sDisplayMember;
	}
	public String getsValueMember() {
		return sValueMember;
	}
	public void setsValueMember(String sValueMember) {
		this.sValueMember = sValueMember;
	}
	public Integer getnStatus() {
		return nStatus;
	}
	public void setnStatus(Integer nStatus) {
		this.nStatus = nStatus;
	}
	public Float getsExistingClassName1() {
		return sExistingClassName1;
	}
	public void setsExistingClassName1(Float sExistingClassName1) {
		this.sExistingClassName1 = sExistingClassName1;
	}
	public float getsDisplayMember1() {
		return sDisplayMember1;
	}
	public void setsDisplayMember1(float sDisplayMember1) {
		this.sDisplayMember1 = sDisplayMember1;
	}
	public byte getsValueMember1() {
		return sValueMember1;
	}
	public void setsValueMember1(byte sValueMember1) {
		this.sValueMember1 = sValueMember1;
	}
	public Byte getnStatus1() {
		return nStatus1;
	}
	public void setnStatus1(Byte nStatus1) {
		this.nStatus1 = nStatus1;
	}
	public Short getsExistingClassName2() {
		return sExistingClassName2;
	}
	public void setsExistingClassName2(Short sExistingClassName2) {
		this.sExistingClassName2 = sExistingClassName2;
	}
	public short getsDisplayMember2() {
		return sDisplayMember2;
	}
	public void setsDisplayMember2(short sDisplayMember2) {
		this.sDisplayMember2 = sDisplayMember2;
	}
	public double getsValueMember2() {
		return sValueMember2;
	}
	public void setsValueMember2(double sValueMember2) {
		this.sValueMember2 = sValueMember2;
	}
	public Double getnStatus2() {
		return nStatus2;
	}
	public void setnStatus2(Double nStatus2) {
		this.nStatus2 = nStatus2;
	}
	public Date getsExistingClassName3() {
		return sExistingClassName3;
	}
	public void setsExistingClassName3(Date sExistingClassName3) {
		this.sExistingClassName3 = sExistingClassName3;
	}
	public long getsDisplayMember3() {
		return sDisplayMember3;
	}
	public void setsDisplayMember3(long sDisplayMember3) {
		this.sDisplayMember3 = sDisplayMember3;
	}
	public Long getsValueMember3() {
		return sValueMember3;
	}
	public void setsValueMember3(Long sValueMember3) {
		this.sValueMember3 = sValueMember3;
	}
	public Boolean getnStatus3() {
		return nStatus3;
	}
	public void setnStatus3(Boolean nStatus3) {
		this.nStatus3 = nStatus3;
	}
	public boolean isnStatus4() {
		return nStatus4;
	}
	public void setnStatus4(boolean nStatus4) {
		this.nStatus4 = nStatus4;
	}
	@Override
	public ExistingLinkTable mapRow(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {
		ExistingLinkTable objExistingLinkTable=new ExistingLinkTable();
		objExistingLinkTable.setnExistingCode(objMapper.getInteger("nExistingCode"));
		objExistingLinkTable.setsExistingTableName(objMapper.getString("sExistingTableName"));
		objExistingLinkTable.setsExistingClassName(objMapper.getString("sExistingClassName"));
		objExistingLinkTable.setsDisplayMember(objMapper.getString("sDisplayMember"));
		objExistingLinkTable.setsValueMember(objMapper.getString("sValueMember"));
		objExistingLinkTable.setnStatus(objMapper.getInteger("nStatus"));
		return objExistingLinkTable;
	}
	@Override
	public String isActiveFilter(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {
		objMapper.setfield("nStatus");
		objMapper.setvalue(1);
		return objMapper.toString();
	}


}

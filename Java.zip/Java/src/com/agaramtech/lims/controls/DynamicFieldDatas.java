package com.agaramtech.lims.controls;



import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="dynamicfielddatas")
@SuppressWarnings("serial")
public class DynamicFieldDatas implements Serializable
{
	@Id
	@Column(name="nfieldscode") private int nfieldscode;	
	@Column(name="npreregno") private int npreregno;	
	@Column(name="scolumnname",length=100) private String scolumnname;
	@Column(name="scolumnvalue",length=100) private String scolumnvalue;
	@Column(name="ndesigncode") private int ndesigncode;
	@Column(name="nprimarytypecode") private int nprimarytypecode;
	@Column(name="nsecondarytypecode") private int nsecondarytypecode;
	@Column(name="nmastercode") private int nmastercode;

	public int getnprimarytypecode() {
		return nprimarytypecode;
	}
	public void setnprimarytypecode(int nprimarytypecode) {
		this.nprimarytypecode = nprimarytypecode;
	}
	public int getnsecondarytypecode() {
		return nsecondarytypecode;
	}
	public void setnsecondarytypecode(int nsecondarytypecode) {
		this.nsecondarytypecode = nsecondarytypecode;
	}
	public int getndesigncode() {
		return ndesigncode;
	}
	public void setndesigncode(int ndesigncode) {
		this.ndesigncode = ndesigncode;
	}
	public int getnfieldscode() {
		return nfieldscode;
	}
	public void setnfieldscode(int nfieldscode) {
		this.nfieldscode = nfieldscode;
	}
	public int getnpreregno() {
		return npreregno;
	}
	public void setnpreregno(int npreregno) {
		this.npreregno = npreregno;
	}
	public String getscolumnname() {
		return scolumnname;
	}
	public void setscolumnname(String scolumnname) {
		this.scolumnname = scolumnname;
	}
	public String getscolumnvalue() {
		return scolumnvalue;
	}
	public void setscolumnvalue(String scolumnvalue) {
		this.scolumnvalue = scolumnvalue;
	}
	public int getnmastercode() {
		return nmastercode;
	}
	public void setnmastercode(int nmastercode) {
		this.nmastercode = nmastercode;
	}

}

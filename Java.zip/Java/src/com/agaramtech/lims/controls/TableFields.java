package com.agaramtech.lims.controls;

import java.io.Serializable;
import java.sql.SQLException;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.agaramtech.lims.dao.support.AgaramResultSetMapper;
import com.agaramtech.lims.dao.support.AgaramRowMapper;

@Entity
@Table(name="TableFields")
@SuppressWarnings("serial")

public class TableFields implements Serializable,AgaramRowMapper<TableFields>
{
	@Id
	@Column(name="nfieldscode") private int nfieldscode;
	@Column(name="sfieldname",length=75) private String sfieldname;
	@Column(name="sdisplayname",length=75) private String sdisplayname;
	@Column(name ="ncreatedby",length=5) private int ncreatedby ;
	@Column(name ="nmodifiedby",length=5) private int nmodifiedby ;
	@Column(name ="dcreateddate") private Date dcreateddate ;
	@Column(name ="dmodifieddate") private Date dmodifieddate ;
	@Column(name="nstatus") private int nstatus;
	@Column(name="ntablecode") private int ntablecode;
	

	public int getncreatedby() {
		return ncreatedby;
	}
	public void setncreatedby(int ncreatedby) {
		this.ncreatedby = ncreatedby;
	}
	public int getnmodifiedby() {
		return nmodifiedby;
	}
	public void setnmodifiedby(int nmodifiedby) {
		this.nmodifiedby = nmodifiedby;
	}
	public Date getdcreateddate() {
		return dcreateddate;
	}
	public void setdcreateddate(Date dcreateddate) {
		this.dcreateddate = dcreateddate;
	}
	public Date getdmodifieddate() {
		return dmodifieddate;
	}
	public void setdmodifieddate(Date dmodifieddate) {
		this.dmodifieddate = dmodifieddate;
	}
	public int getnfieldscode() {
		return nfieldscode;
	}
	public void setnfieldscode(int nfieldscode) {
		this.nfieldscode = nfieldscode;
	}
	public String getsfieldname() {
		return sfieldname;
	}
	public void setsfieldname(String sfieldname) {
		this.sfieldname = sfieldname;
	}
	public String getsdisplayname() {
		return sdisplayname;
	}
	public void setsdisplayname(String sdisplayname) {
		this.sdisplayname = sdisplayname;
	}
	public int getnstatus() {
		return nstatus;
	}
	public void setnstatus(int nstatus) {
		this.nstatus = nstatus;
	}
	public int getntablecode() {
		return ntablecode;
	}
	public void setntablecode(int ntablecode) {
		this.ntablecode = ntablecode;
	}
	@Override
	public TableFields mapRow(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {
		TableFields objTableFields = new TableFields();
		 objTableFields.setntablecode(objMapper.getInteger("ntablecode"));
		 objTableFields.setnmodifiedby(objMapper.getInteger("nmodifiedby"));
		 objTableFields.setsdisplayname(objMapper.getString("sdisplayname"));
		 objTableFields.setdmodifieddate(objMapper.getDate("dmodifieddate"));
		 objTableFields.setnfieldscode(objMapper.getInteger("nfieldscode"));
		 objTableFields.setncreatedby(objMapper.getInteger("ncreatedby"));
		 objTableFields.setnstatus(objMapper.getInteger("nstatus"));
		 objTableFields.setdcreateddate(objMapper.getDate("dcreateddate"));
		 objTableFields.setsfieldname(objMapper.getString("sfieldname"));
		return objTableFields;
	}
	@Override
	public String isActiveFilter(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}
	
}

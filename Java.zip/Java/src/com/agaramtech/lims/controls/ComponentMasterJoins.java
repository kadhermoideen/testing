package com.agaramtech.lims.controls;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Filter;

@Entity
@Table(name="ComponentMaster")
@SuppressWarnings("serial")

/**
 * @author Kadher Moideen S
 *
 * Aug 10, 2012 5:29:04 PM
 */
@Filter(name="fltStatus",condition=" nStatus <> 0 ")
public class ComponentMasterJoins implements Serializable
{
	@Id
	@Column(name="nControlCode") private int nControlCode;
	@Column(name="sControlName",length=75) private String sControlName;
	@Column(name="nLinkStatus") private int nLinkStatus;
	@Column(name="sClassName",length=100) private String sClassName;
	@Column(name="nStatus") private int nStatus;
	/**
	 * @return the sClassName
	 */
	public String getsClassName() {
		return sClassName;
	}
	/**
	 * @param sClassName the sClassName to set
	 */
	public void setsClassName(String sClassName) {
		this.sClassName = sClassName;
	}
	/**
	 * @return the nControlCode
	 */
	public int getnControlCode() {
		return nControlCode;
	}
	/**
	 * @param nControlCode the nControlCode to set
	 */
	public void setnControlCode(int nControlCode) {
		this.nControlCode = nControlCode;
	}
	/**
	 * @return the sControlName
	 */
	public String getsControlName() {
		return sControlName;
	}
	/**
	 * @param sControlName the sControlName to set
	 */
	public void setsControlName(String sControlName) {
		this.sControlName = sControlName;
	}
	/**
	 * @return the nLinkStatus
	 */
	public int getnLinkStatus() {
		return nLinkStatus;
	}
	/**
	 * @param nLinkStatus the nLinkStatus to set
	 */
	public void setnLinkStatus(int nLinkStatus) {
		this.nLinkStatus = nLinkStatus;
	}
	/**
	 * @return the nStatus
	 */
	public int getnStatus() {
		return nStatus;
	}
	/**
	 * @param nStatus the nStatus to set
	 */
	public void setnStatus(int nStatus) {
		this.nStatus = nStatus;
	}

	//	@OneToMany(fetch=FetchType.EAGER)
	//	@JoinColumn(name="nControlCode",insertable=false,updatable=false,referencedColumnName="nControlCode")
	//	@Filter(name="fltStatus",condition=" nStatus <> 0 ")
	//	private Set<PropertiesMaster> objPropertiesMaster = new HashSet<PropertiesMaster>();
	//	/**
	//	 * @return the objPropertiesMaster
	//	 */
	//	public Set<PropertiesMaster> getObjPropertiesMaster() {
	//		return objPropertiesMaster;
	//	}
	//	/**
	//	 * @param objPropertiesMaster the objPropertiesMaster to set
	//	 */
	//	public void setObjPropertiesMaster(Set<PropertiesMaster> objPropertiesMaster) {
	//		this.objPropertiesMaster = objPropertiesMaster;
	//	}
}

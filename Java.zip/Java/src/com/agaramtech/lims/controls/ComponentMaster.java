package com.agaramtech.lims.controls;

import java.io.Serializable;
import java.sql.SQLException;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.agaramtech.lims.dao.support.AgaramResultSetMapper;
import com.agaramtech.lims.dao.support.AgaramRowMapper;

@Entity
@Table(name="ComponentMaster")
@SuppressWarnings("serial")

/**
 * @author Kadher Moideen S
 *
 * Aug 10, 2012 5:29:04 PM
 */
public class ComponentMaster implements Serializable,AgaramRowMapper<ComponentMaster>
{
	@Id
	@Column(name="nControlCode") private int nControlCode;
	@Column(name="sControlName",length=75) private String sControlName;
	@Column(name="nLinkStatus") private int nLinkStatus;
	@Column(name="sClassName",length=100) private String sClassName;
	@Column(name="nStatus") private int nStatus;
	/**
	 * @return the sClassName
	 */
	public String getsClassName() {
		return sClassName;
	}
	/**
	 * @param sClassName the sClassName to set
	 */
	public void setsClassName(String sClassName) {
		this.sClassName = sClassName;
	}
	/**
	 * @return the nControlCode
	 */
	public int getnControlCode() {
		return nControlCode;
	}
	/**
	 * @param nControlCode the nControlCode to set
	 */
	public void setnControlCode(int nControlCode) {
		this.nControlCode = nControlCode;
	}
	/**
	 * @return the sControlName
	 */
	public String getsControlName() {
		return sControlName;
	}
	/**
	 * @param sControlName the sControlName to set
	 */
	public void setsControlName(String sControlName) {
		this.sControlName = sControlName;
	}
	/**
	 * @return the nLinkStatus
	 */
	public int getnLinkStatus() {
		return nLinkStatus;
	}
	/**
	 * @param nLinkStatus the nLinkStatus to set
	 */
	public void setnLinkStatus(int nLinkStatus) {
		this.nLinkStatus = nLinkStatus;
	}
	/**
	 * @return the nStatus
	 */
	public int getnStatus() {
		return nStatus;
	}
	/**
	 * @param nStatus the nStatus to set
	 */
	public void setnStatus(int nStatus) {
		this.nStatus = nStatus;
	}
	@Override
	public ComponentMaster mapRow(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {
		ComponentMaster objComponentMaster=new ComponentMaster();
		objComponentMaster.setnControlCode(objMapper.getInteger("nControlCode"));
		objComponentMaster.setnLinkStatus(objMapper.getInteger("nLinkStatus"));
		objComponentMaster.setnStatus(objMapper.getInteger("nStatus"));
		objComponentMaster.setsClassName(objMapper.getString("sClassName"));
		objComponentMaster.setsControlName(objMapper.getString("sControlName"));
		return objComponentMaster;
	}
	@Override
	public String isActiveFilter(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {
		objMapper.setfield("nStatus");
		objMapper.setvalue(1);
		return objMapper.toString();
	}
}

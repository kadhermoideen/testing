package com.agaramtech.lims.controls;


import java.io.Serializable;
import java.sql.SQLException;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.agaramtech.lims.dao.support.AgaramResultSetMapper;
import com.agaramtech.lims.dao.support.AgaramRowMapper;

@Entity
@Table(name="TableColumns")
@SuppressWarnings("serial")

/**
 * @author Mani
 *
 * Mar 25, 2014 7:12:04 PM
 */

public class TableColumns implements Serializable,AgaramRowMapper<TableColumns>{

	@Id
	@Column(name="ntablecolumncode") private int ntablecolumncode;
	@Column(name="stablecolumnname",length=75) private String stablecolumnname;
	@Column(name="nstatus") private int nstatus;
	@Column(name="ntablecode") private int ntablecode;

	public int getntablecolumncode() {
		return ntablecolumncode;
	}
	public void setntablecolumncode(int ntablecolumncode) {
		this.ntablecolumncode = ntablecolumncode;
	}
	public String getstablecolumnname() {
		return stablecolumnname;
	}
	public void setstablecolumnname(String stablecolumnname) {
		this.stablecolumnname = stablecolumnname;
	}
	public int getnstatus() {
		return nstatus;
	}
	public void setnstatus(int nstatus) {
		this.nstatus = nstatus;
	}
	public int getntablecode() {
		return ntablecode;
	}
	public void setntablecode(int ntablecode) {
		this.ntablecode = ntablecode;
	}

/*	public int indexOf(List<TableColumns> lstColumns,TableColumns objTableColumns) {
		if (objTableColumns == null) {
			for (int i = 0; i < lstColumns.size(); i++)
				if (lstColumns.get(i)==null)
					return i;
		} else {
			for (int i = 0; i < lstColumns.size(); i++)
				if (objTableColumns.equals(lstColumns.get(i)))
					return i;
		}
		return -1;
	}*/

	@Override
	public int hashCode() {
		int hash = 3;
		hash = 7 * hash + this.stablecolumnname.hashCode();
		return hash;
	}

	@Override
	public boolean equals(Object object) {
		boolean result = false;
		if (object == null || object.getClass() != getClass()) {
			result = false;
		} else {
			TableColumns objColumns = (TableColumns) object;
			if (this.stablecolumnname.equals(objColumns.getstablecolumnname())) {
				result = true;
			}
		}
		return result;
	}

	@Override
	public TableColumns mapRow(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {
		TableColumns objTableColumns = new TableColumns();
		objTableColumns.setntablecolumncode(objMapper.getInteger("ntablecolumncode"));
		objTableColumns.setntablecode(objMapper.getInteger("ntablecode"));
		objTableColumns.setnstatus(objMapper.getInteger("nstatus"));
		objTableColumns.setstablecolumnname(objMapper.getString("stablecolumnname"));
		return objTableColumns;

	}
	@Override
	public String isActiveFilter(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}



}

package com.agaramtech.lims.controls;

import java.io.Serializable;
import java.sql.SQLException;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.agaramtech.lims.dao.support.AgaramResultSetMapper;
import com.agaramtech.lims.dao.support.AgaramRowMapper;



@Entity
@Table(name="country")
public class Country  implements Serializable,AgaramRowMapper<Country> {


	@Id
	@Column(name="ncountrycode") private int ncountrycode;
	@Column(name="scountryname",length=50) private String scountryname;
	@Column(name="scountryshotname",length=10) private String scountryshotname;
	@Column(name="stwocharcountry",length=2) private String stwocharcountry;
	@Column(name="sthreecharcountry",length=3) private String sthreecharcountry;
	@Column(name="npoolcountry") private int npoolcountry;
	@Column(name="nbatchcountry") private int nbatchcountry;
	@Column(name="nstatus") private int nstatus;
	@Column(name="ncreatedby") private int ncreatedby;
	@Column(name="dcreateddate") private Date dcreateddate;
	@Column(name="nmodifiedby") private int nmodifiedby;
	@Column(name="dmodifieddate") private Date dmodifieddate;
	
	transient private String sbatchcountry;
	transient private String spoolcountry;
	
	//	@Column(name="ntransactionstatus") private int ntransactionstatus;


	public String getspoolcountry() {
		return spoolcountry;
	}
	public void setspoolcountry(String spoolcountry) {
		this.spoolcountry = spoolcountry;
	}
	public String getsbatchcountry() {
		return sbatchcountry;
	}
	public void setsbatchcountry(String sbatchcountry) {
		this.sbatchcountry = sbatchcountry;
	}
	/*	public int getNtransactionstatus() {
		return ntransactionstatus;
	}
	public void setNtransactionstatus(int ntransactionstatus) {
		this.ntransactionstatus = ntransactionstatus;
	}*/
	public int getncountrycode() {
		return ncountrycode;
	}
	public void setncountrycode(int ncountrycode) {
		this.ncountrycode = ncountrycode;
	}
	public String getscountryname() {
		return scountryname;
	}
	public void setscountryname(String scountryname) {
		this.scountryname = scountryname;
	}
	public String getscountryshotname() {
		return scountryshotname;
	}
	public void setscountryshotname(String scountryshotname) {
		this.scountryshotname = scountryshotname;
	}
	public String getstwocharcountry() {
		return stwocharcountry;
	}
	public void setstwocharcountry(String stwocharcountry) {
		this.stwocharcountry = stwocharcountry;
	}
	public String getsthreecharcountry() {
		return sthreecharcountry;
	}
	public void setsthreecharcountry(String sthreecharcountry) {
		this.sthreecharcountry = sthreecharcountry;
	}
	public int getnpoolcountry() {
		return npoolcountry;
	}
	public void setnpoolcountry(int npoolcountry) {
		this.npoolcountry = npoolcountry;
	}
	public int getnbatchcountry() {
		return nbatchcountry;
	}
	public void setnbatchcountry(int nbatchcountry) {
		this.nbatchcountry = nbatchcountry;
	}
	public int getnstatus() {
		return nstatus;
	}
	public void setnstatus(int nstatus) {
		this.nstatus = nstatus;
	}
	public int getncreatedby() {
		return ncreatedby;
	}
	public void setncreatedby(int ncreatedby) {
		this.ncreatedby = ncreatedby;
	}
	public Date getdcreateddate() {
		return dcreateddate;
	}
	public void setdcreateddate(Date dcreateddate) {
		this.dcreateddate = dcreateddate;
	}
	public int getnmodifiedby() {
		return nmodifiedby;
	}
	public void setnmodifiedby(int nmodifiedby) {
		this.nmodifiedby = nmodifiedby;
	}
	public Date getdmodifieddate() {
		return dmodifieddate;
	}
	public void setdmodifieddate(Date dmodifieddate) {
		this.dmodifieddate = dmodifieddate;
	}



	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((dcreateddate == null) ? 0 : dcreateddate.hashCode());
		result = prime * result
				+ ((dmodifieddate == null) ? 0 : dmodifieddate.hashCode());
		result = prime * result + nbatchcountry;
		result = prime * result + ncountrycode;
		result = prime * result + ncreatedby;
		result = prime * result + nmodifiedby;
		result = prime * result + npoolcountry;
		result = prime * result + nstatus;
		result = prime * result
				+ ((scountryname == null) ? 0 : scountryname.hashCode());
		result = prime
				* result
				+ ((scountryshotname == null) ? 0 : scountryshotname.hashCode());
		result = prime
				* result
				+ ((sthreecharcountry == null) ? 0 : sthreecharcountry
						.hashCode());
		result = prime * result
				+ ((stwocharcountry == null) ? 0 : stwocharcountry.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Country other = (Country) obj;
		if (dcreateddate == null) {
			if (other.dcreateddate != null)
				return false;
		} else if (!dcreateddate.equals(other.dcreateddate))
			return false;
		if (dmodifieddate == null) {
			if (other.dmodifieddate != null)
				return false;
		} else if (!dmodifieddate.equals(other.dmodifieddate))
			return false;
		if (nbatchcountry != other.nbatchcountry)
			return false;
		if (ncountrycode != other.ncountrycode)
			return false;
		if (ncreatedby != other.ncreatedby)
			return false;
		if (nmodifiedby != other.nmodifiedby)
			return false;
		if (npoolcountry != other.npoolcountry)
			return false;
		if (nstatus != other.nstatus)
			return false;
		if (scountryname == null) {
			if (other.scountryname != null)
				return false;
		} else if (!scountryname.equals(other.scountryname))
			return false;
		if (scountryshotname == null) {
			if (other.scountryshotname != null)
				return false;
		} else if (!scountryshotname.equals(other.scountryshotname))
			return false;
		if (sthreecharcountry == null) {
			if (other.sthreecharcountry != null)
				return false;
		} else if (!sthreecharcountry.equals(other.sthreecharcountry))
			return false;
		if (stwocharcountry == null) {
			if (other.stwocharcountry != null)
				return false;
		} else if (!stwocharcountry.equals(other.stwocharcountry))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Country [ncountrycode=" + ncountrycode + ", scountryname="
				+ scountryname + ", scountryshotname=" + scountryshotname
				+ ", stwocharcountry=" + stwocharcountry
				+ ", sthreecharcountry=" + sthreecharcountry
				+ ", npoolcountry=" + npoolcountry + ", nbatchcountry="
				+ nbatchcountry + ", nstatus=" + nstatus + ", ncreatedby="
				+ ncreatedby + ", dcreateddate=" + dcreateddate
				+ ", nmodifiedby=" + nmodifiedby + ", dmodifieddate="
				+ dmodifieddate + "]";
	}

	@Override
	public String isActiveFilter(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {
		objMapper.setfield("nstatus");
		objMapper.setvalue(1);
		return objMapper.toString();
	}


	@Override
	public Country mapRow(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {

		Country objCountry = new Country();
		objCountry.setnmodifiedby(objMapper.getInteger("nmodifiedby"));
		objCountry.setdmodifieddate(objMapper.getDate("dmodifieddate"));
		objCountry.setscountryname(objMapper.getString("scountryname"));
		objCountry.setncreatedby(objMapper.getInteger("ncreatedby"));
		objCountry.setsthreecharcountry(objMapper.getString("sthreecharcountry"));
		objCountry.setnstatus(objMapper.getInteger("nstatus"));
		objCountry.setspoolcountry(objMapper.getString("spoolcountry"));
		objCountry.setncountrycode(objMapper.getInteger("ncountrycode"));
		objCountry.setstwocharcountry(objMapper.getString("stwocharcountry"));
		objCountry.setdcreateddate(objMapper.getDate("dcreateddate"));
		objCountry.setsbatchcountry(objMapper.getString("sbatchcountry"));
		objCountry.setscountryshotname(objMapper.getString("scountryshotname"));

		return objCountry;
	}






}

package com.agaramtech.lims.tree;

/**
 * @author Mani
 * 07 Jan 2014
 */

import java.io.Serializable;
import java.sql.SQLException;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.agaramtech.lims.dao.support.AgaramResultSetMapper;
import com.agaramtech.lims.dao.support.AgaramRowMapper;


@Entity
@Table(name="tablenamessub")
@SuppressWarnings("serial")
public class TableNamesSub implements Serializable, AgaramRowMapper<TableNamesSub>{

	@Column(name="nsubtablecode") 	private int nsubtablecode;
	@Column(name="ssubclassname",length=100) private String ssubclassname;
	@Column(name="ssubtablename",length=100) private String ssubtablename;
	@Column(name="sprimarycolumn",length=100) private String sprimarycolumn;
	@Column(name="schildcolumn",length=100) private String schildcolumn;
	@Column(name="sparentcolumn",length=100) private String sparentcolumn;
	
	public int getnsubtablecode() {
		return nsubtablecode;
	}
	public void setnsubtablecode(int nsubtablecode) {
		this.nsubtablecode = nsubtablecode;
	}
	public String getssubclassname() {
		return ssubclassname;
	}
	public void setssubclassname(String ssubclassname) {
		this.ssubclassname = ssubclassname;
	}
	public String getssubtablename() {
		return ssubtablename;
	}
	public void setssubtablename(String ssubtablename) {
		this.ssubtablename = ssubtablename;
	}
	public String getsprimarycolumn() {
		return sprimarycolumn;
	}
	public void setsprimarycolumn(String sprimarycolumn) {
		this.sprimarycolumn = sprimarycolumn;
	}
	
	
	public String getschildcolumn() {
		return schildcolumn;
	}
	public void setschildcolumn(String schildcolumn) {
		this.schildcolumn = schildcolumn;
	}
	public String getsparentcolumn() {
		return sparentcolumn;
	}
	public void setsparentcolumn(String sparentcolumn) {
		this.sparentcolumn = sparentcolumn;
	}
	@Override
	public TableNamesSub mapRow(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {
		TableNamesSub objNamesSub = new TableNamesSub();
		objNamesSub.setnsubtablecode(objMapper.getInteger("nsubtablecode"));
		objNamesSub.setssubclassname(objMapper.getString("ssubclassname"));
		objNamesSub.setssubtablename(objMapper.getString("ssubtablename"));
		objNamesSub.setsprimarycolumn(objMapper.getString("sprimarycolumn"));
		objNamesSub.setschildcolumn(objMapper.getString("schildcolumn"));
		objNamesSub.setsparentcolumn(objMapper.getString("sparentcolumn"));
		
		return objNamesSub;
	}
	@Override
	public String isActiveFilter(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	
	
}

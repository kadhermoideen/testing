package com.agaramtech.lims.tree;

import java.sql.SQLException;
import java.util.List;

import com.agaramtech.lims.dao.support.AgaramResultSetMapper;
import com.agaramtech.lims.dao.support.AgaramRowMapper;

public class AgaramTree implements AgaramRowMapper<AgaramTree>{

	private int nrownum;
	private int nprimaryid;
	private String svalue;
	private String srtnerrmsg;
	private String sxml;
	private int nsecondid;
	private int nchild;
	private int nparent;
	private String  sparent;
	private String  schild;
	private String  sclose;
	private int nrank;
	private List<?> rtnList;
	private int nparentcode;
	private int nchildcode;

	public int getnrownum() {
		return nrownum;
	}
	public void setnrownum(int nrownum) {
		this.nrownum = nrownum;
	}
	public int getnprimaryid() {
		return nprimaryid;
	}
	public void setnprimaryid(int nprimaryid) {
		this.nprimaryid = nprimaryid;
	}
	public String getsvalue() {
		return svalue;
	}
	public void setsvalue(String svalue) {
		this.svalue = svalue;
	}
	public String getsrtnerrmsg() {
		return srtnerrmsg;
	}
	public void setsrtnerrmsg(String srtnerrmsg) {
		this.srtnerrmsg = srtnerrmsg;
	}
	public String getsxml() {
		return sxml;
	}
	public void setsxml(String sxml) {
		this.sxml = sxml;
	}
	public int getnsecondid() {
		return nsecondid;
	}
	public void setnsecondid(int nsecondid) {
		this.nsecondid = nsecondid;
	}
	public int getnchild() {
		return nchild;
	}
	public void setnchild(int nchild) {
		this.nchild = nchild;
	}
	public int getnparent() {
		return nparent;
	}
	public void setnparent(int nparent) {
		this.nparent = nparent;
	}
	public String getsparent() {
		return sparent;
	}
	public void setsparent(String sparent) {
		this.sparent = sparent;
	}
	public String getschild() {
		return schild;
	}
	public void setschild(String schild) {
		this.schild = schild;
	}
	public String getsclose() {
		return sclose;
	}
	public void setsclose(String sclose) {
		this.sclose = sclose;
	}
	public int getnrank() {
		return nrank;
	}
	public void setnrank(int nrank) {
		this.nrank = nrank;
	}

	public List<?> getrtnList() {
		return rtnList;
	}
	public void setrtnList(List<?> rtnList) {
		this.rtnList = rtnList;
	}

	public int getnparentcode() {
		return nparentcode;
	}
	public void setnparentcode(int nparentcode) {
		this.nparentcode = nparentcode;
	}
	public int getnchildcode() {
		return nchildcode;
	}
	public void setnchildcode(int nchildcode) {
		this.nchildcode = nchildcode;
	}
	@Override
	public AgaramTree mapRow(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {
		AgaramTree objTree = new AgaramTree();
		objTree.setnrownum(objMapper.getInteger("nrownum"));
		objTree.setnprimaryid(objMapper.getInteger("nprimaryid"));
		objTree.setsvalue(objMapper.getString("svalue"));
		objTree.setsrtnerrmsg(objMapper.getString("srtnerrmsg"));
		objTree.setsxml(objMapper.getString("sxml"));
		objTree.setnsecondid(objMapper.getInteger("nsecondid"));
		objTree.setnchild(objMapper.getInteger("nchild"));
		objTree.setnparent(objMapper.getInteger("nparent"));
		objTree.setsparent(objMapper.getString("sparent"));
		objTree.setschild(objMapper.getString("schild"));
		objTree.setsclose(objMapper.getString("sclose"));
		objTree.setnrank(objMapper.getInteger("nrank"));
		objTree.setnparentcode(objMapper.getInteger("nparentcode"));
		objTree.setnchildcode(objMapper.getInteger("nchildcode"));

		return objTree;
	}
	@Override
	public String isActiveFilter(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}
}

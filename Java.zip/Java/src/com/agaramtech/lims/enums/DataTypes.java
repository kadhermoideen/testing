/**
 *
 *Kadher
 *
 * 23-Dec-2013
 *
 */
package com.agaramtech.lims.enums;

/**
 * @author Kadher
 *
 */
public enum DataTypes
{  
	Integer("int"),
	String("String"),
	Double("double"),
	Float("float"),
	Byte("byte"),
	Date("Date"),
	Long("long"),
	ByteArray("byte[]"),
	Boolean("boolean"),
	None(""),
	Short("short");


	private DataTypes(String datatype) {
		this.datatype = datatype;

	}
	private final String datatype;

	public String getdatatype(){  
		return this.datatype;  
	}  
}
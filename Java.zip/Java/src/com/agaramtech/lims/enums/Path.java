package com.agaramtech.lims.enums;

public enum Path
{
	UPLOAD_PATH_LINUX("ROOT/SharedFolder/"),
	UPLOAD_PATH_WINDOWS("\\webapps\\ROOT\\SharedFolder\\");

	private final String path; 

	private Path(String path) {
		this.path = path;
	}

	public String getPath() {
		return path;
	}
}

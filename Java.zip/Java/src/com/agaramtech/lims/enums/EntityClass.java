/**
 *
 *Kadher
 *
 * 23-Dec-2013
 *
 */
package com.agaramtech.lims.enums;

/**
 * @author Kadher
 *
 */
public enum EntityClass
{  
	ENTITYNAME("com.agaramtech.lims.grid.GridSqlQueryMapping");

	private EntityClass(String classname) {
		this.classname = classname;

	}
	private final String classname;

	public String getclassname(){  
		return this.classname;  
	}  
}
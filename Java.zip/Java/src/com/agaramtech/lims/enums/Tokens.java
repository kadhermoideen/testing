/**
 *
 *Kadher
 *
 * 23-Dec-2013
 *
 */
package com.agaramtech.lims.enums;

/**
 * @author Kadher
 *
 */
public enum Tokens
{  
	QUERY_GRID_SQL_QUERY_MAPPING("query_gridsqlquerymapping"),
	GRID_SQL_QUERY_MAPPING_PARM_ONE("gridsqlquerymapping.parmone"),
	QUERY_GRID_SQL_QUERY_MAPPING_PARAM("query_gridsqlquerymappingparam"),
	GRID_SQL_QUERY_MAPPING_PARAM_PARM_ONE("gridsqlquerymappingparam_parm_one"),
	QUERY_GRID_COLUMN_SQL_QUERY_BUILDER("query_gridcolumnsqlquerybuilder"),
	GRID_COLUMN_SQL_QUERY_BUILDER_PARM_ONE("gridcolumnsqlquerybuilder_parm_one"),
	TABLES_PSQL("tables_psql"),
	TABLES_MSSQL("tables_mssql"),
	HASH("#"),
	PARANTHES_LEFT("("),
	PARANTHES_RIGHT(")"),
	COMMA(","),
	SEMICOLON(";");


	private Tokens(String tokens) {
		this.tokens = tokens;

	}
	private final String tokens;

	public String gettokens(){  
		return this.tokens;  
	}  
}
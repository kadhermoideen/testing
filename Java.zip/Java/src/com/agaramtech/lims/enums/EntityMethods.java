/**
 *
 *Kadher
 *
 * 23-Dec-2013
 *
 */
package com.agaramtech.lims.enums;

/**
 * @author Kadher
 *
 */
public enum EntityMethods
{  
	EQUALS("equals"),
	GETDATAGRIDID("getdatagridid"),
	GETSQLMAPPINGNO("getsqlmappingno"),
	GETSQLFORCLIENT("getsqlforclient"),
	GETSEQUENCENUMBER("getnsequenceno");

	private EntityMethods(String methodname) {
		this.methodname = methodname;

	}
	private final String methodname;

	public String getmethodname(){  
		return this.methodname;  
	}  
}
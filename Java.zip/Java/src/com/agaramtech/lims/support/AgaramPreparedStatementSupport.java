/**
 *
 *Kadher
 *
 * 02-Jan-2014
 *
 */
package com.agaramtech.lims.support;

import com.agaramtech.lims.dao.support.AgaramQueryCreater;

/**
 * @author Kadher
 *
 */
@SuppressWarnings("unchecked")
public class AgaramPreparedStatementSupport extends AgaramQueryCreater {


	private static volatile AgaramPreparedStatementSupport _instance  = null;

	private AgaramPreparedStatementSupport() {

	}

	public static AgaramPreparedStatementSupport getInstance() { 
		if(_instance == null){
			synchronized(AgaramPreparedStatementSupport.class) {
				if (_instance == null) {
					_instance = new AgaramPreparedStatementSupport();
				}
			} 
		} 
		return _instance;
	}




}

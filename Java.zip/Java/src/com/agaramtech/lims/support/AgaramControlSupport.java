package com.agaramtech.lims.support;

import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.agaramtech.lims.controls.SampleType;
import com.agaramtech.lims.controls.TableNames;
import com.agaramtech.lims.dao.support.global.AgaramtechGeneralfunction;
import com.agaramtech.lims.tree.TableNamesSub;

@SuppressWarnings("all")
public class AgaramControlSupport{
	
	public List<?> getObjectToSave(List<TableNames> lstTableNames,List<TableNamesSub> lstTableNamesSubs,AgaramtechGeneralfunction objGeneral,List<flex.messaging.io.amf.ASObject> lstObjects,int masterCount) throws Exception
	{
		List<Object> lst = null;
		final Log logging = LogFactory.getLog(AgaramControlSupport.class);
		int primaryTableNo = 0;
		Object classTableName = Class.forName(lstTableNames.get(0).getsclassname()).newInstance();
		Object classTableNameSub = Class.forName(lstTableNamesSubs.get(0).getssubclassname()).newInstance();
		logging.info("1---> "+lstTableNames.size());
		if(lstTableNames.get(0).getsprimarycolumn() != null){
			if(lstTableNames.get(0).getsprimarycolumn() != ""){
				primaryTableNo = objGeneral.getRunningCode(classTableName);
				objGeneral.getPrivateFields(classTableName,lstTableNames.get(0).getsprimarycolumn(),String.valueOf(primaryTableNo));
				objGeneral.getPrivateFields(classTableNameSub,lstTableNamesSubs.get(0).getschildcolumn(),String.valueOf(primaryTableNo));
			}
		}
		logging.info("2---> "+lstTableNames.size());
		if(lstTableNamesSubs.get(0).getsprimarycolumn() != null){
			if(lstTableNamesSubs.get(0).getsprimarycolumn() != ""){
				primaryTableNo = objGeneral.getRunningCode(classTableNameSub);
				objGeneral.getPrivateFields(classTableNameSub,lstTableNamesSubs.get(0).getsprimarycolumn(),String.valueOf(primaryTableNo));
			}
		}
		logging.info("3---> "+lstTableNames.size());
		for(flex.messaging.io.amf.ASObject obj:lstObjects)
		{
			Set<String> columnname = obj.keySet();
			for (Iterator<String> iterator = columnname.iterator(); iterator.hasNext();) 
			{
				logging.info("4---> "+lstTableNames.size());
				String keys = iterator.next();

				if(!keys.equals("ndesigncode")){
					if(keys.equals("masterName") && obj.get(keys).toString() != null && obj.get(keys).toString().length() > 0)
					{
						
						SampleType objSampleType= new SampleType();
						objSampleType.setnsampletypecode(masterCount);
						objSampleType.setdcreateddate(objGeneral.getdDateTime());
						objSampleType.setdmodifieddate(objGeneral.getdDateTime());
						objSampleType.setnconcodinate(1);
						objSampleType.setnorderno(1);
						objSampleType.setnscreentype(0);
						objSampleType.setsdisplaysamptype(obj.get(keys).toString());
						objSampleType.setssamptype(obj.get(keys).toString());
						objSampleType.setsseqtable(obj.get(keys).toString());
						objSampleType.setsstatus("A");

					}
					else
					{
						if(!lstTableNames.get(0).getsprimarycolumn().equalsIgnoreCase(keys)){
							logging.info("5---> "+obj.get(keys).toString());
							objGeneral.getPrivateFields(classTableName,keys,obj.get(keys).toString());
							logging.info("5---> "+obj.get(keys).toString());

						}
						if(!lstTableNamesSubs.get(0).getsprimarycolumn().equalsIgnoreCase(keys)){
							if(!lstTableNamesSubs.get(0).getschildcolumn().equalsIgnoreCase(keys)){
								logging.info("6---> "+obj.get(keys).toString());
								objGeneral.getPrivateFields(classTableNameSub,keys,obj.get(keys).toString());
								logging.info("6---> "+obj.get(keys).toString());
							}
						}
					}
				}
			}
		}
		lst.add(classTableName);
		lst.add(classTableNameSub);
		return lst;
	}
}

/**
 *
 *Kadher
 *
 * 02-Jan-2014
 *
 */
package com.agaramtech.lims.support;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;

import com.agaramtech.lims.dao.support.AgaramQueryCreater;

/**
 * @author Kadher
 *
 */
public class AgaramResultSetConvertor extends AgaramQueryCreater {


	private static volatile AgaramResultSetConvertor _instance  = null;

	private AgaramResultSetConvertor() {

	}
	
	public static AgaramResultSetConvertor getInstance() { 
		if(_instance == null){
			synchronized(AgaramResultSetConvertor.class) {
				if (_instance == null) {
					_instance = new AgaramResultSetConvertor();
				}
			} 
		} 
		return _instance;
	}
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List resultSetToArrayList(ResultSet rs,List listOfEntity) throws SQLException{
		ResultSetMetaData md = rs.getMetaData();
		int columns = md.getColumnCount();
		while (rs.next()){
			HashMap row = new HashMap(columns);
			for(int i=1; i<=columns; ++i){           
				row.put(md.getColumnName(i),rs.getObject(i));
			}
			listOfEntity.add(row);
		}

		return listOfEntity;
	}


}

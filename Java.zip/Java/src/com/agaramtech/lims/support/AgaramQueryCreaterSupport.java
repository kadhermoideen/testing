/**
 *
 *Kadher
 *
 * 02-Jan-2014
 *
 */
package com.agaramtech.lims.support;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.agaramtech.lims.dao.support.AgaramQueryCreater;
import com.agaramtech.lims.enums.EntityClass;
import com.agaramtech.lims.enums.EntityMethods;
import com.agaramtech.lims.enums.Tokens;
import com.agaramtech.lims.grid.GridColumnSqlQueryBuilder;
import com.agaramtech.lims.grid.GridSqlQueryMapping;
import com.agaramtech.lims.grid.GridSqlQueryMappingParam;

/**
 * @author Kadher
 *
 */
@SuppressWarnings("unchecked")
public class AgaramQueryCreaterSupport extends AgaramQueryCreater {


	private static volatile AgaramQueryCreaterSupport _instance  = null;

	private AgaramQueryCreaterSupport() {

	}

	public static AgaramQueryCreaterSupport getInstance() { 
		if(_instance == null){
			synchronized(AgaramQueryCreaterSupport.class) {
				if (_instance == null) {
					_instance = new AgaramQueryCreaterSupport();
				}
			} 
		} 
		return _instance;
	}


	public String multiPlainQueryFormation(Map<String, List<?>> gridList) throws Exception
	{
		StringBuilder objBuilder = null;
		StringBuilder objFinalQuery = null;
		Pattern pattern = null;
		Matcher matcher = null;

		List<GridSqlQueryMappingParam> parameterList=getGridSqlQueryMappingParam(gridList,GridSqlQueryMappingParam.class.getSimpleName());
		List<GridSqlQueryMapping> mappingList = getGridSqlQueryMapping(gridList,GridSqlQueryMapping.class.getSimpleName());
		List<GridColumnSqlQueryBuilder> builderList = getGridColumnSqlQueryBuilder(gridList,GridColumnSqlQueryBuilder.class.getSimpleName());

		if(objFinalQuery == null)
			objFinalQuery = new StringBuilder();
		objectCollection= new ArrayList<Object>();
		if(mappingList != null){
			if(mappingList.size() > 0){
				for(int i=0; i<mappingList.size();i++){

					objectCollection.add(mappingList.get(i));
					objBuilder = new StringBuilder();
					String finalquery = getQuerys(mappingList.get(i),EntityMethods.GETSQLFORCLIENT.getmethodname());
					if(finalquery  != null)
						if(finalquery != ""){
							for(GridSqlQueryMappingParam objMappingParam:parameterList){
								if(mappingList.get(i).getsqlmappingno() == objMappingParam.getsqlmappingno()){
									pattern = Pattern.compile(Tokens.HASH.gettokens()+objMappingParam.getparametername()+Tokens.HASH.gettokens());
									if(objBuilder.length() != 0) {
										matcher = pattern.matcher(objBuilder); 
									} else {
										matcher = pattern.matcher(finalquery);
									}
									while (matcher.find()) { 
										String replaceingText = Tokens.PARANTHES_LEFT.gettokens()+objMappingParam.getparameterquery()+Tokens.PARANTHES_RIGHT.gettokens();
										finalquery=matcher.replaceAll(replaceingText);
									} 

								}

							}
							objBuilder.append(finalquery +Tokens.SEMICOLON.gettokens());
							for(GridColumnSqlQueryBuilder objQueryBuilder:builderList){
								if(mappingList.get(i).getsqlmappingno() == objQueryBuilder.getsqlmappingno()){
									objectCollection.add(objQueryBuilder);
									objBuilder.append(objQueryBuilder.getcolumnloader()+Tokens.SEMICOLON.gettokens());
									break;
								}
							}
						}
					objFinalQuery.append(objBuilder);
				}
			}

		}
		return objFinalQuery == null?"":objFinalQuery.toString();
	}



	private List<GridSqlQueryMappingParam> getGridSqlQueryMappingParam(Map<String, List<?>> gridList,String key){
		List<GridSqlQueryMappingParam> lst = (List<GridSqlQueryMappingParam>) gridList.get(GridSqlQueryMappingParam.class.getSimpleName());
		return lst;
	}

	private List<GridSqlQueryMapping> getGridSqlQueryMapping(Map<String, List<?>> gridList,String key){
		List<GridSqlQueryMapping> lst = (List<GridSqlQueryMapping>) gridList.get(GridSqlQueryMapping.class.getSimpleName());
		return lst;
	}

	private List<GridColumnSqlQueryBuilder> getGridColumnSqlQueryBuilder(Map<String, List<?>> gridList,String key){
		List<GridColumnSqlQueryBuilder> lst = (List<GridColumnSqlQueryBuilder>) gridList.get(GridColumnSqlQueryBuilder.class.getSimpleName());
		return lst;
	}

	public String invokeMethod(Object args,String methodName){
		String gridId = "";
		try{
			Method lMethod = null;

			lMethod  = args.getClass().getMethod(methodName);
			gridId =(String) lMethod.invoke(args);
		}catch(Exception e){
			e.printStackTrace();
		}
		return gridId;
	}

	public String replaceWithPattern(String str,String replace,String compile){
		Pattern pattern = Pattern.compile(compile);
		Matcher matcher = pattern.matcher(str);
		return matcher.replaceAll(replace);
	}
	
	public boolean findPattern(String str,String compile){
		 String patStr=".*\\b(" + compile+ ")\\b.*";
		Pattern pattern = Pattern.compile(patStr);
		Matcher matcher = pattern.matcher(str);
		return matcher.matches();
	}



	public boolean invokeEqualsMethod(Class<?> args){
		boolean flag = false;
		try{
			Class<?> entityClass = (Class.forName(args.getName()));
			Class<?> gridClass = (Class.forName(EntityClass.ENTITYNAME.getclassname()));
			Class<?>[] cArgs = new Class[1];
			cArgs[0] = Object.class;

			Method lMethod  = gridClass.getMethod(EntityMethods.EQUALS.getmethodname(), cArgs);
			flag =(boolean) lMethod.invoke(gridClass.newInstance(),entityClass.newInstance());
		}catch(Exception e){
			e.printStackTrace();
		}
		return flag;
	}

}

package com.agaramtech.lims.base;

import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.agaramtech.lims.dao.annotation.AgaramtechOneToMany;
import com.agaramtech.lims.dao.annotation.AgaramtechOneToOne;
import com.agaramtech.lims.dao.support.AgaramResultSetMapper;
import com.agaramtech.lims.dao.support.AgaramRowMapper;
import com.agaramtech.lims.enums.DataTypes;

@Entity
@Table(name = "runningmaker")
@SuppressWarnings("serial")
public class RunningMaker implements java.io.Serializable,AgaramRowMapper<RunningMaker> {
	
	@Id
	@Column(name = "tablename")	private String tablename;
	@Column(name = "prefix") private String prefix;
	@Column(name = "seqlength")	private int seqlength;
	@Column(name = "sequencenumber")private int sequencenumber;
	@Column(name = "suffix")private String suffix;
	@Column(name = "dateformat")private String dateformat;
	@Column(name = "dsequencedate")	private Date dsequencedate;
	
	@AgaramtechOneToOne(parentkey="tablename",childkey="something",displayfield="sequence",childname=RunningMaker.class,datatype=DataTypes.String)
	transient private String sdescription;
	
	@AgaramtechOneToMany(parentkey="tablename",childkey="something",displayfield="sequence",childname=RunningMaker.class,datatype=DataTypes.String)
	transient private List<RunningMaker> lst;

	public String gettablename() {
		return tablename;
	}

	public void settablename(String tablename) {
		this.tablename = tablename;
	}


	public String getprefix() {
		return prefix;
	}

	public void setprefix(String prefix) {
		this.prefix = prefix;
	}


	public int getseqlength() {
		return seqlength;
	}

	public void setseqlength(int seqlength) {
		this.seqlength = seqlength;
	}


	public int getsequencenumber() {
		return sequencenumber;
	}

	public void setsequencenumber(int sequencenumber) {
		this.sequencenumber = sequencenumber;
	}


	public String getsuffix() {
		return suffix;
	}

	public void setsuffix(String suffix) {
		this.suffix = suffix;
	}


	public String getDateformat() {
		return dateformat;
	}

	public void setDateformat(String dateformat) {
		this.dateformat = dateformat;
	}

	public Date getDsequencedate() {
		return dsequencedate;
	}

	public void setDsequencedate(Date dsequencedate) {
		this.dsequencedate = dsequencedate;
	}

	@Override
	public RunningMaker mapRow(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {
		RunningMaker objRunningMaker = new RunningMaker();
		objRunningMaker.setseqlength(objMapper.getInteger("seqlength"));
		objRunningMaker.settablename(objMapper.getString("tablename"));
		objRunningMaker.setprefix(objMapper.getString("prefix"));
		objRunningMaker.setsuffix(objMapper.getString("suffix"));
		objRunningMaker.setsequencenumber(objMapper.getInteger("sequencenumber"));
		objRunningMaker.setDateformat(objMapper.getString("dateformat"));
		objRunningMaker.setDsequencedate(objMapper.getDate("dsequencedate"));
		return objRunningMaker;
	}

	@Override
	public String isActiveFilter(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}
}

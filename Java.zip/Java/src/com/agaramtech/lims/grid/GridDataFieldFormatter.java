/**
 *
 *Kadher
 *
 * 12-Dec-2013
 *
 */
package com.agaramtech.lims.grid;

import java.io.Serializable;
import java.sql.SQLException;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.agaramtech.lims.dao.support.AgaramResultSetMapper;
import com.agaramtech.lims.dao.support.AgaramRowMapper;

/**
 * @author Kadher
 *
 */
@Entity
@Table(name="griddatafieldformatter")
@SuppressWarnings("serial")
public class GridDataFieldFormatter implements Serializable,AgaramRowMapper<GridDataFieldFormatter> {

	@Id
	@Column(name="formatterno")private int formatterno;
	@Column(name="datatypeno")private int datatypeno;
	@Column(name="format")private String format;
	@Column(name="createdby")private int createdby;
	@Column(name="modifiedby")private int modifiedby;
	@Column(name="createddate")private Date createddate;
	@Column(name="modifieddate")private Date modifieddate;
	@Column(name="status")private int status;


	public int getformatterno() {
		return formatterno;
	}
	public void setformatterno(int formatterno) {
		this.formatterno = formatterno;
	}
	public int getdatatypeno() {
		return datatypeno;
	}
	public void setdatatypeno(int datatypeno) {
		this.datatypeno = datatypeno;
	}
	public String getformat() {
		return format;
	}
	public void setformat(String format) {
		this.format = format;
	}
	public int getcreatedby() {
		return createdby;
	}
	public void setcreatedby(int createdby) {
		this.createdby = createdby;
	}
	public int getmodifiedby() {
		return modifiedby;
	}
	public void setmodifiedby(int modifiedby) {
		this.modifiedby = modifiedby;
	}
	public Date getcreateddate() {
		return createddate;
	}
	public void setcreateddate(Date createddate) {
		this.createddate = createddate;
	}
	public Date getmodifieddate() {
		return modifieddate;
	}
	public void setmodifieddate(Date modifieddate) {
		this.modifieddate = modifieddate;
	}
	public int getstatus() {
		return status;
	}
	public void setstatus(int status) {
		this.status = status;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + createdby;
		result = prime * result
				+ ((createddate == null) ? 0 : createddate.hashCode());
		result = prime * result + datatypeno;
		result = prime * result + ((format == null) ? 0 : format.hashCode());
		result = prime * result + formatterno;
		result = prime * result + modifiedby;
		result = prime * result
				+ ((modifieddate == null) ? 0 : modifieddate.hashCode());
		result = prime * result + status;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof GridDataFieldFormatter)) {
			return false;
		}
		GridDataFieldFormatter other = (GridDataFieldFormatter) obj;
		if (createdby != other.createdby) {
			return false;
		}
		if (createddate == null) {
			if (other.createddate != null) {
				return false;
			}
		} else if (!createddate.equals(other.createddate)) {
			return false;
		}
		if (datatypeno != other.datatypeno) {
			return false;
		}
		if (format == null) {
			if (other.format != null) {
				return false;
			}
		} else if (!format.equals(other.format)) {
			return false;
		}
		if (formatterno != other.formatterno) {
			return false;
		}
		if (modifiedby != other.modifiedby) {
			return false;
		}
		if (modifieddate == null) {
			if (other.modifieddate != null) {
				return false;
			}
		} else if (!modifieddate.equals(other.modifieddate)) {
			return false;
		}
		if (status != other.status) {
			return false;
		}
		return true;
	}
	/* (non-Javadoc)
	 * @see com.agaramtech.lims.dao.support.AgaramRowMapper#mapRow(com.agaramtech.lims.dao.support.AgaramResultSetMapper)
	 */
	@Override
	public GridDataFieldFormatter mapRow(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {
		GridDataFieldFormatter objBuilder = new GridDataFieldFormatter();

		objBuilder.setformatterno(objMapper.getInteger("formatterno"));
		objBuilder.setdatatypeno(objMapper.getInteger("datatypeno"));
		objBuilder.setformat(objMapper.getString("format"));
		objBuilder.setcreatedby(objMapper.getInteger("createdby"));
		objBuilder.setcreateddate(objMapper.getDate("createddate"));
		objBuilder.setmodifiedby(objMapper.getInteger("modifiedby"));
		objBuilder.setmodifieddate(objMapper.getDate("modifieddate"));
		objBuilder.setstatus(objMapper.getInteger("status"));
		return objBuilder;
	}
	/* (non-Javadoc)
	 * @see com.agaramtech.lims.dao.support.AgaramRowMapper#isActiveFilter(com.agaramtech.lims.dao.support.AgaramResultSetMapper)
	 */
	@Override
	public String isActiveFilter(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {
		objMapper.setfield("status");
		objMapper.setvalue(1);
		return objMapper.toString();
	}


}

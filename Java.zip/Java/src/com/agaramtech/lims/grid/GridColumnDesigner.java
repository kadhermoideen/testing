/**
 *
 *Kadher
 *
 * 12-Dec-2013
 *
 */
package com.agaramtech.lims.grid;

import java.io.Serializable;
import java.sql.SQLException;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.agaramtech.lims.dao.support.AgaramResultSetMapper;
import com.agaramtech.lims.dao.support.AgaramRowMapper;

/**
 * @author Kadher
 *
 */
@Entity
@Table(name="gridcolumndesigner")
@SuppressWarnings("serial")
public class GridColumnDesigner implements Serializable,AgaramRowMapper<GridColumnDesigner> {

	@Id
	@Column(name="designno")private int designno;
	@Column(name="headertext")private String headertext;
	@Column(name="datafield")private String datafield;
	@Column(name="orderno")private int orderno;
	@Column(name="datatypeno")private int datatypeno;
	@Column(name="sqlmappingno")private int sqlmappingno;
	@Column(name="visible")private boolean visible;
	@Column(name="editable")private boolean editable;
	@Column(name="datatipfield")private String datatipfield;
	@Column(name="width")private String width;
	@Column(name="itemrenderer")private String itemrenderer;
	@Column(name="backgroundcolor")private String backgroundcolor;
	@Column(name="color")private String color;
	@Column(name="labelfunction")private String labelfunction;
	@Column(name="sortable")private boolean sortable;
	@Column(name="createdby")private int createdby;
	@Column(name="modifiedby")private int modifiedby;
	@Column(name="createddate")private Date createddate;
	@Column(name="modifieddate")private Date modifieddate;
	@Column(name="status")private int status;

	public int getdesignno() {
		return designno;
	}
	public void setdesignno(int designno) {
		this.designno = designno;
	}
	public String getheadertext() {
		return headertext;
	}
	public void setheadertext(String headertext) {
		this.headertext = headertext;
	}
	public String getdatafield() {
		return datafield;
	}
	public void setdatafield(String datafield) {
		this.datafield = datafield;
	}
	public int getorderno() {
		return orderno;
	}
	public void setorderno(int orderno) {
		this.orderno = orderno;
	}
	public int getdatatypeno() {
		return datatypeno;
	}
	public void setdatatypeno(int datatypeno) {
		this.datatypeno = datatypeno;
	}
	public int getsqlmappingno() {
		return sqlmappingno;
	}
	public void setsqlmappingno(int sqlmappingno) {
		this.sqlmappingno = sqlmappingno;
	}
	public boolean getvisible() {
		return visible;
	}
	public void setvisible(boolean visible) {
		this.visible = visible;
	}
	public boolean geteditable() {
		return editable;
	}
	public void seteditable(boolean editable) {
		this.editable = editable;
	}
	public String getdatatipfield() {
		return datatipfield;
	}
	public void setdatatipfield(String datatipfield) {
		this.datatipfield = datatipfield;
	}
	public String getwidth() {
		return width;
	}
	public void setwidth(String width) {
		this.width = width;
	}
	public String getitemrenderer() {
		return itemrenderer;
	}
	public void setitemrenderer(String itemrenderer) {
		this.itemrenderer = itemrenderer;
	}
	public String getbackgroundcolor() {
		return backgroundcolor;
	}
	public void setbackgroundcolor(String backgroundcolor) {
		this.backgroundcolor = backgroundcolor;
	}
	public String getcolor() {
		return color;
	}
	public void setcolor(String color) {
		this.color = color;
	}
	public String getlabelfunction() {
		return labelfunction;
	}
	public void setlabelfunction(String labelfunction) {
		this.labelfunction = labelfunction;
	}
	public boolean getsortable() {
		return sortable;
	}
	public void setsortable(boolean sortable) {
		this.sortable = sortable;
	}
	public int getstatus() {
		return status;
	}
	public void setstatus(int status) {
		this.status = status;
	}
	public int getcreatedby() {
		return createdby;
	}
	public void setcreatedby(int createdby) {
		this.createdby = createdby;
	}
	public int getmodifiedby() {
		return modifiedby;
	}
	public void setmodifiedby(int modifiedby) {
		this.modifiedby = modifiedby;
	}
	public Date getcreateddate() {
		return createddate;
	}
	public void setcreateddate(Date createddate) {
		this.createddate = createddate;
	}
	public Date getmodifieddate() {
		return modifieddate;
	}
	public void setmodifieddate(Date modifieddate) {
		this.modifieddate = modifieddate;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((backgroundcolor == null) ? 0 : backgroundcolor.hashCode());
		result = prime * result + ((color == null) ? 0 : color.hashCode());
		result = prime * result + createdby;
		result = prime * result
				+ ((createddate == null) ? 0 : createddate.hashCode());
		result = prime * result
				+ ((datafield == null) ? 0 : datafield.hashCode());
		result = prime * result
				+ ((datatipfield == null) ? 0 : datatipfield.hashCode());
		result = prime * result + datatypeno;
		result = prime * result + designno;
		result = prime * result + (editable ? 1231 : 1237);
		result = prime * result
				+ ((headertext == null) ? 0 : headertext.hashCode());
		result = prime * result
				+ ((itemrenderer == null) ? 0 : itemrenderer.hashCode());
		result = prime * result
				+ ((labelfunction == null) ? 0 : labelfunction.hashCode());
		result = prime * result + modifiedby;
		result = prime * result
				+ ((modifieddate == null) ? 0 : modifieddate.hashCode());
		result = prime * result + orderno;
		result = prime * result + (sortable ? 1231 : 1237);
		result = prime * result + sqlmappingno;
		result = prime * result + status;
		result = prime * result + (visible ? 1231 : 1237);
		result = prime * result + ((width == null) ? 0 : width.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof GridColumnDesigner)) {
			return false;
		}
		GridColumnDesigner other = (GridColumnDesigner) obj;
		if (backgroundcolor == null) {
			if (other.backgroundcolor != null) {
				return false;
			}
		} else if (!backgroundcolor.equals(other.backgroundcolor)) {
			return false;
		}
		if (color == null) {
			if (other.color != null) {
				return false;
			}
		} else if (!color.equals(other.color)) {
			return false;
		}
		if (createdby != other.createdby) {
			return false;
		}
		if (createddate == null) {
			if (other.createddate != null) {
				return false;
			}
		} else if (!createddate.equals(other.createddate)) {
			return false;
		}
		if (datafield == null) {
			if (other.datafield != null) {
				return false;
			}
		} else if (!datafield.equals(other.datafield)) {
			return false;
		}
		if (datatipfield == null) {
			if (other.datatipfield != null) {
				return false;
			}
		} else if (!datatipfield.equals(other.datatipfield)) {
			return false;
		}
		if (datatypeno != other.datatypeno) {
			return false;
		}
		if (designno != other.designno) {
			return false;
		}
		if (editable != other.editable) {
			return false;
		}
		if (headertext == null) {
			if (other.headertext != null) {
				return false;
			}
		} else if (!headertext.equals(other.headertext)) {
			return false;
		}
		if (itemrenderer == null) {
			if (other.itemrenderer != null) {
				return false;
			}
		} else if (!itemrenderer.equals(other.itemrenderer)) {
			return false;
		}
		if (labelfunction == null) {
			if (other.labelfunction != null) {
				return false;
			}
		} else if (!labelfunction.equals(other.labelfunction)) {
			return false;
		}
		if (modifiedby != other.modifiedby) {
			return false;
		}
		if (modifieddate == null) {
			if (other.modifieddate != null) {
				return false;
			}
		} else if (!modifieddate.equals(other.modifieddate)) {
			return false;
		}
		if (orderno != other.orderno) {
			return false;
		}
		if (sortable != other.sortable) {
			return false;
		}
		if (sqlmappingno != other.sqlmappingno) {
			return false;
		}
		if (status != other.status) {
			return false;
		}
		if (visible != other.visible) {
			return false;
		}
		if (width == null) {
			if (other.width != null) {
				return false;
			}
		} else if (!width.equals(other.width)) {
			return false;
		}
		return true;
	}
	/* (non-Javadoc)
	 * @see com.agaramtech.lims.dao.support.AgaramRowMapper#mapRow(com.agaramtech.lims.dao.support.AgaramResultSetMapper)
	 */
	@Override
	public GridColumnDesigner mapRow(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {
		GridColumnDesigner objBuilder = new GridColumnDesigner();

		objBuilder.setdesignno(objMapper.getInteger("designno"));
		objBuilder.setheadertext(objMapper.getString("headertext"));
		objBuilder.setdatafield(objMapper.getString("datafield"));
		objBuilder.setdatatipfield(objMapper.getString("datatipfield"));
		objBuilder.setwidth(objMapper.getString("width"));
		objBuilder.setitemrenderer(objMapper.getString("itemrenderer"));
		objBuilder.setbackgroundcolor(objMapper.getString("backgroundcolor"));
		objBuilder.setcolor(objMapper.getString("color"));
		objBuilder.setlabelfunction(objMapper.getString("labelfunction"));
		objBuilder.setorderno(objMapper.getInteger("orderno"));
		objBuilder.setdatatypeno(objMapper.getInteger("datatypeno"));
		objBuilder.setsqlmappingno(objMapper.getInteger("sqlmappingno"));
		objBuilder.setvisible(objMapper.getBoolean("visible"));
		objBuilder.seteditable(objMapper.getBoolean("editable"));
		objBuilder.setsortable(objMapper.getBoolean("sortable"));
		objBuilder.setcreatedby(objMapper.getInteger("createdby"));
		objBuilder.setcreateddate(objMapper.getDate("createddate"));
		objBuilder.setmodifiedby(objMapper.getInteger("modifiedby"));
		objBuilder.setmodifieddate(objMapper.getDate("modifieddate"));
		objBuilder.setstatus(objMapper.getInteger("status"));

		return objBuilder;
	}
	/* (non-Javadoc)
	 * @see com.agaramtech.lims.dao.support.AgaramRowMapper#isActiveFilter(com.agaramtech.lims.dao.support.AgaramResultSetMapper)
	 */
	@Override
	public String isActiveFilter(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {
		objMapper.setfield("status");
		objMapper.setvalue(1);
		return objMapper.toString();
	}

}

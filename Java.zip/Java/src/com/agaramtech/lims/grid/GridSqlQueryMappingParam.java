/**
 *
 *Kadher
 *
 * 12-Dec-2013
 *
 */
package com.agaramtech.lims.grid;

import java.io.Serializable;
import java.sql.SQLException;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.agaramtech.lims.dao.support.AgaramResultSetMapper;
import com.agaramtech.lims.dao.support.AgaramRowMapper;

/**
 * @author Kadher
 *
 */
@Entity
@Table(name="gridsqlquerymappingparam")
@SuppressWarnings("serial")
public class GridSqlQueryMappingParam implements Serializable,AgaramRowMapper<GridSqlQueryMappingParam> {

	@Id
	@Column(name="mappingparamno")private int mappingparamno;
	@Column(name="sqlmappingno")private int sqlmappingno;
	@Column(name="parametername")private String parametername;
	@Column(name="parameterquery")private String parameterquery;
	@Column(name="createdby")private int createdby;
	@Column(name="modifiedby")private int modifiedby;
	@Column(name="createddate")private Date createddate;
	@Column(name="modifieddate")private Date modifieddate;
	@Column(name="status")private int status;


	public int getmappingparamno() {
		return mappingparamno;
	}
	public void setmappingparamno(int mappingparamno) {
		this.mappingparamno = mappingparamno;
	}
	public int getsqlmappingno() {
		return sqlmappingno;
	}
	public void setsqlmappingno(int sqlmappingno) {
		this.sqlmappingno = sqlmappingno;
	}
	public String getparametername() {
		return parametername;
	}
	public void setparametername(String parametername) {
		this.parametername = parametername;
	}
	public String getparameterquery() {
		return parameterquery;
	}
	public void setparameterquery(String parameterquery) {
		this.parameterquery = parameterquery;
	}
	public int getcreatedby() {
		return createdby;
	}
	public void setcreatedby(int createdby) {
		this.createdby = createdby;
	}
	public int getmodifiedby() {
		return modifiedby;
	}
	public void setmodifiedby(int modifiedby) {
		this.modifiedby = modifiedby;
	}
	public Date getcreateddate() {
		return createddate;
	}
	public void setcreateddate(Date createddate) {
		this.createddate = createddate;
	}
	public Date getmodifieddate() {
		return modifieddate;
	}
	public void setmodifieddate(Date modifieddate) {
		this.modifieddate = modifieddate;
	}
	public int getstatus() {
		return status;
	}
	public void setstatus(int status) {
		this.status = status;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + createdby;
		result = prime * result
				+ ((createddate == null) ? 0 : createddate.hashCode());
		result = prime * result + mappingparamno;
		result = prime * result + modifiedby;
		result = prime * result
				+ ((modifieddate == null) ? 0 : modifieddate.hashCode());
		result = prime * result
				+ ((parametername == null) ? 0 : parametername.hashCode());
		result = prime * result
				+ ((parameterquery == null) ? 0 : parameterquery.hashCode());
		result = prime * result + sqlmappingno;
		result = prime * result + status;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof GridSqlQueryMappingParam)) {
			return false;
		}
		GridSqlQueryMappingParam other = (GridSqlQueryMappingParam) obj;
		if (createdby != other.createdby) {
			return false;
		}
		if (createddate == null) {
			if (other.createddate != null) {
				return false;
			}
		} else if (!createddate.equals(other.createddate)) {
			return false;
		}
		if (mappingparamno != other.mappingparamno) {
			return false;
		}
		if (modifiedby != other.modifiedby) {
			return false;
		}
		if (modifieddate == null) {
			if (other.modifieddate != null) {
				return false;
			}
		} else if (!modifieddate.equals(other.modifieddate)) {
			return false;
		}
		if (parametername == null) {
			if (other.parametername != null) {
				return false;
			}
		} else if (!parametername.equals(other.parametername)) {
			return false;
		}
		if (parameterquery == null) {
			if (other.parameterquery != null) {
				return false;
			}
		} else if (!parameterquery.equals(other.parameterquery)) {
			return false;
		}
		if (sqlmappingno != other.sqlmappingno) {
			return false;
		}
		if (status != other.status) {
			return false;
		}
		return true;
	}
	/* (non-Javadoc)
	 * @see com.agaramtech.lims.dao.support.AgaramRowMapper#mapRow(com.agaramtech.lims.dao.support.AgaramResultSetMapper)
	 */
	@Override
	public GridSqlQueryMappingParam mapRow(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {
		GridSqlQueryMappingParam objBuilder = new GridSqlQueryMappingParam();
		objBuilder.setmappingparamno(objMapper.getInteger("mappingparamno"));
		objBuilder.setsqlmappingno(objMapper.getInteger("sqlmappingno"));
		objBuilder.setparametername(objMapper.getString("parametername"));
		objBuilder.setparameterquery(objMapper.getString("parameterquery"));
		objBuilder.setcreatedby(objMapper.getInteger("createdby"));
		objBuilder.setcreateddate(objMapper.getDate("createddate"));
		objBuilder.setmodifiedby(objMapper.getInteger("modifiedby"));
		objBuilder.setmodifieddate(objMapper.getDate("modifieddate"));
		objBuilder.setstatus(objMapper.getInteger("status"));
		return objBuilder;
	}
	/* (non-Javadoc)
	 * @see com.agaramtech.lims.dao.support.AgaramRowMapper#isActiveFilter(com.agaramtech.lims.dao.support.AgaramResultSetMapper)
	 */
	@Override
	public String isActiveFilter(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {
		objMapper.setfield("status");
		objMapper.setvalue(1);
		return objMapper.toString();
	}


}

/**
 *
 *Kadher
 *
 * 12-Dec-2013
 *
 */
package com.agaramtech.lims.grid;

import java.io.Serializable;
import java.sql.SQLException;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.agaramtech.lims.dao.support.AgaramResultSetMapper;
import com.agaramtech.lims.dao.support.AgaramRowMapper;

/**
 * @author Kadher
 *
 */
@Entity
@Table(name="gridcolumnsqlquerybuilder")
@SuppressWarnings("serial")
public class GridColumnSqlQueryBuilder implements Serializable,AgaramRowMapper<GridColumnSqlQueryBuilder> {

	@Id
	@Column(name="columnbuilderno")private int columnbuilderno;
	@Column(name="sqlmappingno")private int sqlmappingno;
	@Column(name="columnloader")private String columnloader;
	@Column(name="status")private int status;
	@Column(name="createdby")private int createdby;
	@Column(name="modifiedby")private int modifiedby;
	@Column(name="createddate")private Date createddate;
	@Column(name="modifieddate")private Date modifieddate;


	public int getcolumnbuilderno() {
		return columnbuilderno;
	}
	public void setcolumnbuilderno(int columnbuilderno) {
		this.columnbuilderno = columnbuilderno;
	}
	public int getsqlmappingno() {
		return sqlmappingno;
	}
	public void setsqlmappingno(int sqlmappingno) {
		this.sqlmappingno = sqlmappingno;
	}
	public String getcolumnloader() {
		return columnloader;
	}
	public void setcolumnloader(String columnloader) {
		this.columnloader = columnloader;
	}
	public int getstatus() {
		return status;
	}
	public void setstatus(int status) {
		this.status = status;
	}
	public int getcreatedby() {
		return createdby;
	}
	public void setcreatedby(int createdby) {
		this.createdby = createdby;
	}
	public int getmodifiedby() {
		return modifiedby;
	}
	public void setmodifiedby(int modifiedby) {
		this.modifiedby = modifiedby;
	}
	public Date getcreateddate() {
		return createddate;
	}
	public void setcreateddate(Date createddate) {
		this.createddate = createddate;
	}
	public Date getmodifieddate() {
		return modifieddate;
	}
	public void setmodifieddate(Date modifieddate) {
		this.modifieddate = modifieddate;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + columnbuilderno;
		result = prime * result
				+ ((columnloader == null) ? 0 : columnloader.hashCode());
		result = prime * result + createdby;
		result = prime * result
				+ ((createddate == null) ? 0 : createddate.hashCode());
		result = prime * result + modifiedby;
		result = prime * result
				+ ((modifieddate == null) ? 0 : modifieddate.hashCode());
		result = prime * result + sqlmappingno;
		result = prime * result + status;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof GridColumnSqlQueryBuilder)) {
			return false;
		}
		GridColumnSqlQueryBuilder other = (GridColumnSqlQueryBuilder) obj;
		if (columnbuilderno != other.columnbuilderno) {
			return false;
		}
		if (columnloader == null) {
			if (other.columnloader != null) {
				return false;
			}
		} else if (!columnloader.equals(other.columnloader)) {
			return false;
		}
		if (createdby != other.createdby) {
			return false;
		}
		if (createddate == null) {
			if (other.createddate != null) {
				return false;
			}
		} else if (!createddate.equals(other.createddate)) {
			return false;
		}
		if (modifiedby != other.modifiedby) {
			return false;
		}
		if (modifieddate == null) {
			if (other.modifieddate != null) {
				return false;
			}
		} else if (!modifieddate.equals(other.modifieddate)) {
			return false;
		}
		if (sqlmappingno != other.sqlmappingno) {
			return false;
		}
		if (status != other.status) {
			return false;
		}
		return true;
	}
	/* (non-Javadoc)
	 * @see com.agaramtech.lims.dao.support.AgaramRowMapper#mapRow(com.agaramtech.lims.dao.support.AgaramResultSetMapper)
	 */
	@Override
	public GridColumnSqlQueryBuilder mapRow(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {
		GridColumnSqlQueryBuilder objBuilder = new GridColumnSqlQueryBuilder();

		objBuilder.setcolumnbuilderno(objMapper.getInteger("columnbuilderno"));
		objBuilder.setcreatedby(objMapper.getInteger("createdby"));
		objBuilder.setcreateddate(objMapper.getDate("createddate"));
		objBuilder.setmodifiedby(objMapper.getInteger("modifiedby"));
		objBuilder.setmodifieddate(objMapper.getDate("modifieddate"));
		objBuilder.setsqlmappingno(objMapper.getInteger("sqlmappingno"));
		objBuilder.setcolumnloader(objMapper.getString("columnloader"));
		objBuilder.setstatus(objMapper.getInteger("status"));
		return objBuilder;
	}
	/* (non-Javadoc)
	 * @see com.agaramtech.lims.dao.support.AgaramRowMapper#isActiveFilter(com.agaramtech.lims.dao.support.AgaramResultSetMapper)
	 */
	@Override
	public String isActiveFilter(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {
		objMapper.setfield("status");
		objMapper.setvalue(1);
		return objMapper.toString();
	}

}

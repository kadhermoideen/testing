/**
 *
 *Kadher
 *
 * 12-Dec-2013
 *
 */
package com.agaramtech.lims.grid;

import java.io.Serializable;
import java.sql.SQLException;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.agaramtech.lims.dao.support.AgaramResultSetMapper;
import com.agaramtech.lims.dao.support.AgaramRowMapper;

/**
 * @author Kadher
 *
 */
@Entity
@Table(name="gridscreeninfo")
@SuppressWarnings("serial")
public class GridScreenInfo implements Serializable,AgaramRowMapper<GridScreenInfo> {

	@Id
	@Column(name="screenid")private int screenid;
	@Column(name="classpath")private String classpath;
	@Column(name="simplename")private String simplename;
	@Column(name="createdby")private int createdby;
	@Column(name="modifiedby")private int modifiedby;
	@Column(name="createddate")private Date createddate;
	@Column(name="modifieddate")private Date modifieddate;
	@Column(name="status")private int status;

	public String getclasspath() {
		return classpath;
	}
	public void setclasspath(String classpath) {
		this.classpath = classpath;
	}
	public String getsimplename() {
		return simplename;
	}
	public void setsimplename(String simplename) {
		this.simplename = simplename;
	}
	public int getstatus() {
		return status;
	}
	public void setstatus(int status) {
		this.status = status;
	}
	public int getcreatedby() {
		return createdby;
	}
	public void setcreatedby(int createdby) {
		this.createdby = createdby;
	}
	public int getmodifiedby() {
		return modifiedby;
	}
	public void setmodifiedby(int modifiedby) {
		this.modifiedby = modifiedby;
	}
	public Date getcreateddate() {
		return createddate;
	}
	public void setcreateddate(Date createddate) {
		this.createddate = createddate;
	}
	public Date getmodifieddate() {
		return modifieddate;
	}
	public void setmodifieddate(Date modifieddate) {
		this.modifieddate = modifieddate;
	}
	public int getscreenid() {
		return screenid;
	}
	public void setscreenid(int screenid) {
		this.screenid = screenid;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((classpath == null) ? 0 : classpath.hashCode());
		result = prime * result + createdby;
		result = prime * result
				+ ((createddate == null) ? 0 : createddate.hashCode());
		result = prime * result + modifiedby;
		result = prime * result
				+ ((modifieddate == null) ? 0 : modifieddate.hashCode());
		result = prime * result + screenid;
		result = prime * result
				+ ((simplename == null) ? 0 : simplename.hashCode());
		result = prime * result + status;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof GridScreenInfo)) {
			return false;
		}
		GridScreenInfo other = (GridScreenInfo) obj;
		if (classpath == null) {
			if (other.classpath != null) {
				return false;
			}
		} else if (!classpath.equals(other.classpath)) {
			return false;
		}
		if (createdby != other.createdby) {
			return false;
		}
		if (createddate == null) {
			if (other.createddate != null) {
				return false;
			}
		} else if (!createddate.equals(other.createddate)) {
			return false;
		}
		if (modifiedby != other.modifiedby) {
			return false;
		}
		if (modifieddate == null) {
			if (other.modifieddate != null) {
				return false;
			}
		} else if (!modifieddate.equals(other.modifieddate)) {
			return false;
		}
		if (screenid != other.screenid) {
			return false;
		}
		if (simplename == null) {
			if (other.simplename != null) {
				return false;
			}
		} else if (!simplename.equals(other.simplename)) {
			return false;
		}
		if (status != other.status) {
			return false;
		}
		return true;
	}
	/* (non-Javadoc)
	 * @see com.agaramtech.lims.dao.support.AgaramRowMapper#mapRow(com.agaramtech.lims.dao.support.AgaramResultSetMapper)
	 */
	@Override
	public GridScreenInfo mapRow(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {
		GridScreenInfo objBuilder = new GridScreenInfo();

		objBuilder.setscreenid(objMapper.getInteger("screenid"));
		objBuilder.setclasspath(objMapper.getString("classpath"));
		objBuilder.setsimplename(objMapper.getString("simplename"));
		objBuilder.setcreatedby(objMapper.getInteger("createdby"));
		objBuilder.setcreateddate(objMapper.getDate("createddate"));
		objBuilder.setmodifiedby(objMapper.getInteger("modifiedby"));
		objBuilder.setmodifieddate(objMapper.getDate("modifieddate"));
		objBuilder.setstatus(objMapper.getInteger("status"));
		return objBuilder;
	}
	/* (non-Javadoc)
	 * @see com.agaramtech.lims.dao.support.AgaramRowMapper#isActiveFilter(com.agaramtech.lims.dao.support.AgaramResultSetMapper)
	 */
	@Override
	public String isActiveFilter(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {
		objMapper.setfield("status");
		objMapper.setvalue(1);
		return objMapper.toString();
	}


}

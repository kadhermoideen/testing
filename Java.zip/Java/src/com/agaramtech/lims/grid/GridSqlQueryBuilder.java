/**
 *
 *Kadher
 *
 * 12-Dec-2013
 *
 */
package com.agaramtech.lims.grid;

import java.io.Serializable;
import java.sql.SQLException;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.agaramtech.lims.dao.support.AgaramResultSetMapper;
import com.agaramtech.lims.dao.support.AgaramRowMapper;

/**
 * @author Kadher
 *
 */
@Entity
@Table(name="gridsqlquerybuilder")
@SuppressWarnings("serial")
public class GridSqlQueryBuilder implements Serializable,AgaramRowMapper<GridSqlQueryBuilder> {

	@Id
	@Column(name="sqlqueryno")private int sqlqueryno;
	@Column(name="sqlforide")private String sqlforide;
	@Column(name="sqlforclient")private String sqlforclient;
	@Column(name="status")private int status;
	@Column(name="createdby")private int createdby;
	@Column(name="modifiedby")private int modifiedby;
	@Column(name="createddate")private Date createddate;
	@Column(name="modifieddate")private Date modifieddate;

	public int getsqlqueryno() {
		return sqlqueryno;
	}
	public void setsqlqueryno(int sqlqueryno) {
		this.sqlqueryno = sqlqueryno;
	}
	public String getsqlforide() {
		return sqlforide;
	}
	public void setsqlforide(String sqlforide) {
		this.sqlforide = sqlforide;
	}
	public String getsqlforclient() {
		return sqlforclient;
	}
	public void setsqlforclient(String sqlforclient) {
		this.sqlforclient = sqlforclient;
	}
	public int getstatus() {
		return status;
	}
	public void setstatus(int status) {
		this.status = status;
	}
	public int getcreatedby() {
		return createdby;
	}
	public void setcreatedby(int createdby) {
		this.createdby = createdby;
	}
	public int getmodifiedby() {
		return modifiedby;
	}
	public void setmodifiedby(int modifiedby) {
		this.modifiedby = modifiedby;
	}
	public Date getcreateddate() {
		return createddate;
	}
	public void setcreateddate(Date createddate) {
		this.createddate = createddate;
	}
	public Date getmodifieddate() {
		return modifieddate;
	}
	public void setmodifieddate(Date modifieddate) {
		this.modifieddate = modifieddate;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + createdby;
		result = prime * result
				+ ((createddate == null) ? 0 : createddate.hashCode());
		result = prime * result + modifiedby;
		result = prime * result
				+ ((modifieddate == null) ? 0 : modifieddate.hashCode());
		result = prime * result
				+ ((sqlforclient == null) ? 0 : sqlforclient.hashCode());
		result = prime * result
				+ ((sqlforide == null) ? 0 : sqlforide.hashCode());
		result = prime * result + sqlqueryno;
		result = prime * result + status;
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof GridSqlQueryBuilder)) {
			return false;
		}
		GridSqlQueryBuilder other = (GridSqlQueryBuilder) obj;
		if (createdby != other.createdby) {
			return false;
		}
		if (createddate == null) {
			if (other.createddate != null) {
				return false;
			}
		} else if (!createddate.equals(other.createddate)) {
			return false;
		}
		if (modifiedby != other.modifiedby) {
			return false;
		}
		if (modifieddate == null) {
			if (other.modifieddate != null) {
				return false;
			}
		} else if (!modifieddate.equals(other.modifieddate)) {
			return false;
		}
		if (sqlforclient == null) {
			if (other.sqlforclient != null) {
				return false;
			}
		} else if (!sqlforclient.equals(other.sqlforclient)) {
			return false;
		}
		if (sqlforide == null) {
			if (other.sqlforide != null) {
				return false;
			}
		} else if (!sqlforide.equals(other.sqlforide)) {
			return false;
		}
		if (sqlqueryno != other.sqlqueryno) {
			return false;
		}
		if (status != other.status) {
			return false;
		}
		return true;
	}
	/* (non-Javadoc)
	 * @see com.agaramtech.lims.dao.support.AgaramRowMapper#mapRow(com.agaramtech.lims.dao.support.AgaramResultSetMapper)
	 */
	@Override
	public GridSqlQueryBuilder mapRow(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {
		GridSqlQueryBuilder objBuilder = new GridSqlQueryBuilder();
		objBuilder.setsqlqueryno(objMapper.getInteger("sqlqueryno"));
		objBuilder.setcreatedby(objMapper.getInteger("createdby"));
		objBuilder.setcreateddate(objMapper.getDate("createddate"));
		objBuilder.setmodifiedby(objMapper.getInteger("modifiedby"));
		objBuilder.setmodifieddate(objMapper.getDate("modifieddate"));
		objBuilder.setsqlforclient(objMapper.getString("sqlforclient"));
		objBuilder.setsqlforide(objMapper.getString("sqlforide"));
		objBuilder.setstatus(objMapper.getInteger("status"));
		return objBuilder;
	}
	/* (non-Javadoc)
	 * @see com.agaramtech.lims.dao.support.AgaramRowMapper#isActiveFilter(com.agaramtech.lims.dao.support.AgaramResultSetMapper)
	 */
	@Override
	public String isActiveFilter(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {
		objMapper.setfield("status");
		objMapper.setvalue(1);
		return objMapper.toString();
	}

}

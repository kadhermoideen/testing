/**
 *
 *Kadher
 *
 * 12-Dec-2013
 *
 */
package com.agaramtech.lims.grid;

import java.io.Serializable;
import java.sql.SQLException;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.agaramtech.lims.dao.support.AgaramResultSetMapper;
import com.agaramtech.lims.dao.support.AgaramRowMapper;

/**
 * @author Kadher
 *
 */
@Entity
@Table(name="gridsqlquerymapping")
@SuppressWarnings("serial")
public class GridSqlQueryMapping implements Serializable,AgaramRowMapper<GridSqlQueryMapping> {

	@Id
	@Column(name="sqlmappingno")private int sqlmappingno;
	@Column(name="formcode")private int formcode;
	@Column(name="datagridid")private String datagridid;
	@Column(name="sqlqueryno")private int sqlqueryno;
	@Column(name="createdby")private int createdby;
	@Column(name="modifiedby")private int modifiedby;
	@Column(name="createddate")private Date createddate;
	@Column(name="modifieddate")private Date modifieddate;
	@Column(name="status")private int status;
	@Column(name="linkcode")private String linkcode;
	@Column(name="linktypecode")private int linktypecode;

	transient private String sqlforclient;
	transient private String sqlforide;

	public int getlinktypecode() {
		return linktypecode;
	}
	public void setlinktypecode(int linktypecode) {
		this.linktypecode = linktypecode;
	}
	public String getlinkcode() {
		return linkcode;
	}
	public void setlinkcode(String linkcode) {
		this.linkcode = linkcode;
	}
	public String getsqlforclient() {
		return sqlforclient;
	}
	public void setsqlforclient(String sqlforclient) {
		this.sqlforclient = sqlforclient;
	}
	public String getsqlforide() {
		return sqlforide;
	}
	public void setsqlforide(String sqlforide) {
		this.sqlforide = sqlforide;
	}
	public int getsqlqueryno() {
		return sqlqueryno;
	}
	public void setsqlqueryno(int sqlqueryno) {
		this.sqlqueryno = sqlqueryno;
	}
	public int getstatus() {
		return status;
	}
	public void setstatus(int status) {
		this.status = status;
	}
	public int getcreatedby() {
		return createdby;
	}
	public void setcreatedby(int createdby) {
		this.createdby = createdby;
	}
	public int getmodifiedby() {
		return modifiedby;
	}
	public void setmodifiedby(int modifiedby) {
		this.modifiedby = modifiedby;
	}
	public Date getcreateddate() {
		return createddate;
	}
	public void setcreateddate(Date createddate) {
		this.createddate = createddate;
	}
	public Date getmodifieddate() {
		return modifieddate;
	}
	public void setmodifieddate(Date modifieddate) {
		this.modifieddate = modifieddate;
	}
	public int getsqlmappingno() {
		return sqlmappingno;
	}
	public void setsqlmappingno(int sqlmappingno) {
		this.sqlmappingno = sqlmappingno;
	}
	public int getformcode() {
		return formcode;
	}
	public void setformcode(int formcode) {
		this.formcode = formcode;
	}
	public String getdatagridid() {
		return datagridid;
	}
	public void setdatagridid(String datagridid) {
		this.datagridid = datagridid;
	}



	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + createdby;
		result = prime * result
				+ ((createddate == null) ? 0 : createddate.hashCode());
		result = prime * result
				+ ((datagridid == null) ? 0 : datagridid.hashCode());
		result = prime * result + formcode;
		result = prime * result 
				+ ((linkcode == null) ? 0 : linkcode.hashCode());
		result = prime * result + linktypecode;
		result = prime * result + modifiedby;
		result = prime * result
				+ ((modifieddate == null) ? 0 : modifieddate.hashCode());
		result = prime * result + sqlmappingno;
		result = prime * result + sqlqueryno;
		result = prime * result + status;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof GridSqlQueryMapping)) {
			return false;
		}
		GridSqlQueryMapping other = (GridSqlQueryMapping) obj;
		if (createdby != other.createdby) {
			return false;
		}
		if (createddate == null) {
			if (other.createddate != null) {
				return false;
			}
		} else if (!createddate.equals(other.createddate)) {
			return false;
		}
		if (datagridid == null) {
			if (other.datagridid != null) {
				return false;
			}
		} else if (!datagridid.equals(other.datagridid)) {
			return false;
		}
		if (formcode != other.formcode) {
			return false;
		}
		if (linkcode != other.linkcode) {
			return false;
		}
		if (linktypecode != other.linktypecode) {
			return false;
		}
		if (modifiedby != other.modifiedby) {
			return false;
		}
		if (modifieddate == null) {
			if (other.modifieddate != null) {
				return false;
			}
		} else if (!modifieddate.equals(other.modifieddate)) {
			return false;
		}
		if (sqlmappingno != other.sqlmappingno) {
			return false;
		}
		if (sqlqueryno != other.sqlqueryno) {
			return false;
		}
		if (status != other.status) {
			return false;
		}
		return true;
	}
	/* (non-Javadoc)
	 * @see com.agaramtech.lims.dao.support.AgaramRowMapper#mapRow(com.agaramtech.lims.dao.support.AgaramResultSetMapper)
	 */
	@Override
	public GridSqlQueryMapping mapRow(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {
		GridSqlQueryMapping objBuilder = new GridSqlQueryMapping();

		objBuilder.setsqlmappingno(objMapper.getInteger("sqlmappingno"));
		objBuilder.setsqlforide(objMapper.getString("sqlforide"));
		objBuilder.setsqlforclient(objMapper.getString("sqlforclient"));
		objBuilder.setformcode(objMapper.getInteger("formcode"));
		objBuilder.setdatagridid(objMapper.getString("datagridid"));
		objBuilder.setsqlqueryno(objMapper.getInteger("sqlqueryno"));
		objBuilder.setlinkcode(objMapper.getString("linkcode"));
		objBuilder.setlinktypecode(objMapper.getInteger("linktypecode"));
		objBuilder.setcreatedby(objMapper.getInteger("createdby"));
		objBuilder.setcreateddate(objMapper.getDate("createddate"));
		objBuilder.setmodifiedby(objMapper.getInteger("modifiedby"));
		objBuilder.setmodifieddate(objMapper.getDate("modifieddate"));
		objBuilder.setstatus(objMapper.getInteger("status"));
		return objBuilder;
	}
	/* (non-Javadoc)
	 * @see com.agaramtech.lims.dao.support.AgaramRowMapper#isActiveFilter(com.agaramtech.lims.dao.support.AgaramResultSetMapper)
	 */
	@Override
	public String isActiveFilter(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {
		objMapper.setfield("status");
		objMapper.setvalue(1);
		return objMapper.toString();
	}


}

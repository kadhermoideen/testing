package com.agaramtech.lims.dao.support.global;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.StringReader;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import javax.persistence.Column;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.commons.lang.SystemUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.impl.SessionFactoryImpl;
import org.reflections.ReflectionUtils;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ResourceLoaderAware;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.flex.core.AbstractDestinationFactory;
import org.springframework.flex.remoting.RemotingDestinationExporter;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.web.context.ServletContextAware;
import org.springframework.web.context.support.ServletContextResource;
import org.springframework.web.context.support.WebApplicationContextUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import com.agaramtech.agdesign.service.AgDesignServiceImpl;
import com.agaramtech.lims.base.RunningMaker;
import com.agaramtech.lims.dao.support.AgaramDaoSupport;
import com.agaramtech.lims.dao.support.AgaramEntityMethods;
import com.agaramtech.lims.dao.support.bridge.RDBMSBridge;
import com.agaramtech.lims.dao.support.enums.EntityMapper;
import com.agaramtech.lims.dao.support.enums.Status;
import com.agaramtech.lims.enums.EntityMethods;
import com.agaramtech.lims.enums.Path;
import com.agaramtech.lims.support.AgaramQueryCreaterSupport;

import flex.messaging.FlexContext;
import flex.messaging.client.FlexClient;

@SuppressWarnings("all")
public class AgaramtechGeneralfunction implements ServletContextAware,ResourceLoaderAware{


	private AgaramDaoSupport agaramDaoSupport;


	public AgaramDaoSupport getAgaramDaoSupport() {
		return agaramDaoSupport;
	}

	public void setAgaramDaoSupport(AgaramDaoSupport agaramDaoSupport) {
		this.agaramDaoSupport = agaramDaoSupport;
	}

	private static ResourceLoader resourceLoader;
	private ApplicationContext applicationContext;
	private static String absolutePath = "";
	private static ServletContext servletcontext ;

	private static final Log log =LogFactory.getLog(AgaramtechGeneralfunction.class);
	public final AgaramQueryCreaterSupport objQueryCreater = AgaramQueryCreaterSupport.getInstance();

	private Timestamp timestamp;
	private String sGDateTime;
	private Date dDateTime;

	DateFormat dateFormat = new SimpleDateFormat("dd/MMM/yyyy hh:mm:ss.S a");


	public Date getdDateTime() {
		timestamp=GetDate();

		sGDateTime = dateFormat.format(timestamp.getTime());
		dDateTime = fnCurrentDateTimeforConversion(sGDateTime);

		return dDateTime;
	}

	private Timestamp GetDate(){	
		return getAgaramDaoSupport().getHibernateTemplate().execute(new HibernateCallback<Timestamp>() {

			@Override
			public Timestamp doInHibernate(Session sess) throws HibernateException,SQLException {
				return (Timestamp) sess.createSQLQuery("select "+RDBMSBridge.getSystemDate()).list().get(0);
			}
		});  
	}
	private Date fnCurrentDateTimeforConversion(String sDateTime){
		try{
			return new SimpleDateFormat("dd/MMM/yyyy hh:mm:ss.S a").parse(sDateTime);
		}
		catch(Exception e){
			return null;
		}
	}

	public String fnRemoteClientIP()
	{
		Resource resource = resourceLoader.getResource("");
		String clientIP = "";
		FlexClient flexClient = FlexContext.getFlexClient();
		HttpServletRequest httpRequest = FlexContext.getHttpRequest();

		if (resource instanceof ServletContextResource) {
			clientIP = httpRequest.getRemoteHost();
		}
		else{
			clientIP = "1";
		}


		return clientIP;
	}

	public String getAbsolutePath(){
		Resource resource = resourceLoader.getResource("");

		if (resource instanceof ServletContextResource) {
			ServletContextResource scResource = (ServletContextResource) resource;
			servletcontext = scResource.getServletContext();
			String parentPath = servletcontext.getRealPath("/");
			String blazeds = servletcontext.getContextPath();
			blazeds = blazeds.substring(1);
			int index=parentPath.indexOf(blazeds);
			absolutePath = parentPath.substring(0, index);

			log.info("First Path ------------>" + absolutePath);

			if(SystemUtils.IS_OS_WINDOWS){
				log.info("Four Path ------------>" + Path.UPLOAD_PATH_WINDOWS.getPath());
				absolutePath = new File("").getAbsolutePath() + Path.UPLOAD_PATH_WINDOWS.getPath();
				log.info("Enumerations.UPLOAD_PATH ------------>"+absolutePath);
			}
			else if(SystemUtils.IS_OS_LINUX){
				log.info("Second Path ------------>" + Path.UPLOAD_PATH_LINUX.getPath());
				String connnection = absolutePath + Path.UPLOAD_PATH_LINUX.getPath();
				log.info("Thir Path ------------>" + connnection);
				absolutePath = connnection;
				log.info("Enumerations.UPLOAD_PATH_LINUX ------------>"+absolutePath);
			}
		}else{
			if(SystemUtils.IS_OS_WINDOWS){
				log.info("Four Path ------------>" + Path.UPLOAD_PATH_WINDOWS.getPath());
				absolutePath = new File("").getAbsolutePath() + Path.UPLOAD_PATH_WINDOWS.getPath();
				log.info("Enumerations.UPLOAD_PATH ------------>"+absolutePath);
			}
			else if(SystemUtils.IS_OS_LINUX){
				log.info("Second Path ------------>" + Path.UPLOAD_PATH_LINUX.getPath());
				String connnection = absolutePath + Path.UPLOAD_PATH_LINUX.getPath();
				log.info("Thir Path ------------>" + connnection);
				absolutePath = connnection;
				log.info("Enumerations.UPLOAD_PATH_LINUX ------------>"+absolutePath);
			}
		}
		return absolutePath;
	}

	@Override
	public void setServletContext(ServletContext servletcontext) {
		Resource resource = resourceLoader.getResource("");
		if (resource instanceof ServletContextResource) {
			ServletContextResource scResource = (ServletContextResource) resource;
			servletcontext = scResource.getServletContext();
			this.servletcontext = servletcontext;
		}
	}

	public ServletContext getServletContext(){
		return servletcontext;
	}

	@Override
	public void setResourceLoader(ResourceLoader resourceLoader) {
		this.resourceLoader = resourceLoader;
	}

	public void getPrivateFields(Object object,String columnname,String value) throws Exception{
		Field[] fields = object.getClass().getDeclaredFields();
		log.info("General   columnname>"+columnname);
		log.info("General   value>"+value);
		for(Field field:fields){
			field.setAccessible(true);
			Class<?> type = field.getType();
			if(field.getName().trim().toUpperCase().equals(columnname.trim().toUpperCase()))
			{
				switch(type.getName()){
				case "int":
					field.setInt(object, Integer.parseInt(value));
					break;
				case "java.lang.String":
					field.set(object, value);
					log.info("field   value>"+value);
					break;
				case "double":
					field.setDouble(object, Double.parseDouble(value));
					break;
				case "float":
					field.setFloat(object, Float.parseFloat(value));
					break;
				case "java.util.Date":
					field.set(object, new Date(value));
					break;
				case "long":
					field.setLong(object, Long.parseLong(value));
					break;
				case "byte":
					field.setByte(object, Byte.parseByte(value));
					break;
				default :
					break;
				}
			}

		}
	}

	public void setPrivateFieldsMultiple(Object object,String primaryColumn,String primaryValue,String uniqueColumn,List<?> lstObject,AgaramtechGeneralfunction objGeneral) throws Exception{
		Field[] fieldArrayObject = object.getClass().getDeclaredFields();
		Field[] fieldArrayValue = object.getClass().getDeclaredFields();


		for(Object objectValue:lstObject){
			for(Field fieldValue:fieldArrayValue){
				fieldValue.setAccessible(true);
				Class<?> typeValue = fieldValue.getType();
				for(Field fieldObject:fieldArrayObject){
					boolean bBreakFlag = false;
					fieldObject.setAccessible(true);
					Class<?> typeObject = fieldObject.getType();
					if(fieldObject.getName().trim().toUpperCase().equals(fieldValue.getName().trim().toUpperCase()))
					{
						switch(typeObject.getName()){
						case "int":
						{
							if(primaryColumn.trim().toUpperCase().equals(fieldValue.getName().trim().toUpperCase()))
								fieldValue.setInt(object,Integer.parseInt(primaryValue));
							else
								fieldValue.setInt(object,fieldObject.getInt(objectValue));

							bBreakFlag = true;
							break;
						}
						case "java.lang.String":
						{
							if(uniqueColumn != null)
							{
								if(uniqueColumn.trim().toUpperCase().equals(fieldValue.getName().trim().toUpperCase()))
									fieldValue.set(object,fieldObject.get(objectValue)+" copy");
								else
									fieldValue.set(object, fieldObject.get(objectValue));
							}
							else
							{
								fieldValue.set(object, fieldObject.get(objectValue));
							}
							bBreakFlag = true;
							break;
						}
						case "double":
							fieldValue.setDouble(object,fieldObject.getDouble(objectValue));
							bBreakFlag = true;
							break;
						case "float":
							fieldValue.setFloat(object, fieldObject.getFloat(objectValue));
							bBreakFlag = true;
							break;
						case "java.util.Date":
							fieldValue.set(object,getdDateTime());
							bBreakFlag = true;
							break;
						case "long":
							fieldValue.setLong(object, fieldObject.getLong(objectValue));
							bBreakFlag = true;
							break;
						case "byte":
							fieldValue.setByte(object, fieldObject.getByte(objectValue));
							bBreakFlag = true;
							break;
						default :
							break;
						}
					}
					if(bBreakFlag)
					{
						break;
					}
				}
			}
		}
	}

	public void setPrivateFieldsTreeSub(Object object,String primaryColumn,String primaryValue,String parentColumn,String parentValue,String childColumn,String childValue,AgaramtechGeneralfunction objGeneral) throws Exception{
		Field[] fieldArrayObject = object.getClass().getDeclaredFields();
		Field[] fieldArrayValue = object.getClass().getDeclaredFields();


		for(Field fieldValue:fieldArrayValue){
			fieldValue.setAccessible(true);
			for(Field fieldObject:fieldArrayObject){
				boolean bBreakFlag = false;
				fieldObject.setAccessible(true);
				Class<?> typeObject = fieldObject.getType();
				if(fieldObject.getName().trim().toUpperCase().equals(fieldValue.getName().trim().toUpperCase()))
				{
					switch(typeObject.getName()){
					case "int":
					{
						if(primaryColumn.trim().toUpperCase().equals(fieldValue.getName().trim().toUpperCase()))
							fieldValue.setInt(object,Integer.parseInt(primaryValue));
						else if(parentColumn.trim().toUpperCase().equals(fieldValue.getName().trim().toUpperCase()))
							fieldValue.setInt(object,Integer.parseInt(parentValue));
						else if(childColumn.trim().toUpperCase().equals(fieldValue.getName().trim().toUpperCase()))
							fieldValue.setInt(object,Integer.parseInt(childValue));
						else if("nstatus".toUpperCase().equals(fieldValue.getName().trim().toUpperCase()))
							fieldValue.setInt(object,Status.ACTIVE.getstatus());

						bBreakFlag = true;
						break;
					}
					case "java.util.Date":
						fieldValue.set(object,objGeneral.getdDateTime());
						bBreakFlag = true;
						break;
					default :
						break;
					}
				}
				if(bBreakFlag)
				{
					break;
				}
			}
		}
	}

	public static Object findColumnName(Object object,String columnname) throws Exception{
		Field[] fields = object.getClass().getDeclaredFields();
		log.info("General   columnname>"+columnname);
		Object obj = null;
		for(Field field:fields){
			field.setAccessible(true);
			Class<?> type = field.getType();
			if(field.getName().trim().toUpperCase().equals(columnname.trim().toUpperCase()))
			{

				switch(type.getName()){
				case "int":
				{
					if(obj == null)
						obj = new Object();
					obj = field.getInt(object);
					break;
				}
				case "java.lang.String":

					break;
				case "double":

					break;
				case "float":

					break;
				case "java.util.Date":

					break;
				case "long":

					break;
				case "byte":

					break;
				default :
					break;
				}
			}

		}
		return obj;
	}

	public int getRunningCode(Object object) throws Exception{
		int number = 0;
		List<RunningMaker> lstMaker = (List<RunningMaker>) getAgaramDaoSupport().findBySingleConditionalField("sequencenumber", RunningMaker.class, "where tablename='"+object.getClass().getSimpleName()+"'");
		if(lstMaker != null){
			if(lstMaker.size() > 0){
				RunningMaker objMaker = lstMaker.get(0);
				number = objMaker.getsequencenumber();
				number = number +1;
				getAgaramDaoSupport().getHibernateTemplate().bulkUpdate("Update RunningMaker set sequencenumber="+number+" where tablename='"+object.getClass().getSimpleName()+"' ");

			}
		}
		return number;
	}

	public int getSequence(Class<?> classname,String sequenceTablename) throws Exception{

		int number = 0;
		List<Class<?>> lstSequence = (List<Class<?>>) getAgaramDaoSupport().findBySingleConditionalField(EntityMapper.SEQUENCENO.getmappername(),classname, "where "+EntityMapper.TABLENAME.getmappername()+"='"+sequenceTablename+"'");
		if(lstSequence != null){
			if(lstSequence.size() > 0){
				Object objMaker =lstSequence.get(0);
				number = Integer.parseInt(objQueryCreater.invokeMethod(objMaker,EntityMethods.GETSEQUENCENUMBER.getmethodname()));
				number = number +1;
				getAgaramDaoSupport().getHibernateTemplate().bulkUpdate("Update "+classname.getSimpleName()+" set "+EntityMapper.SEQUENCENO.getmappername()+"="+number+" where "+EntityMapper.TABLENAME.getmappername()+"='"+sequenceTablename+"' ");

			}
		}
		return number;
	}

	public int getSequence(Class<?> classname) throws Exception{

		int number = 0;
		List<Class<?>> lstSequence = (List<Class<?>>) getAgaramDaoSupport().findBySingleConditionalField(EntityMapper.SEQUENCENO.getmappername(),classname, "where "+EntityMapper.TABLENAME.getmappername()+"='"+classname.getSimpleName()+"'");
		if(lstSequence != null){
			if(lstSequence.size() > 0){
				Object objMaker =lstSequence.get(0);
				number = Integer.parseInt(objQueryCreater.invokeMethod(objMaker,EntityMethods.GETSEQUENCENUMBER.getmethodname()));
				number = number +1;
				getAgaramDaoSupport().getHibernateTemplate().bulkUpdate("Update "+classname.getSimpleName()+" set "+EntityMapper.SEQUENCENO.getmappername()+"="+number+" where "+EntityMapper.TABLENAME.getmappername()+"='"+classname.getSimpleName()+"' ");

			}
		}
		return number;
	}

	public int getSequence(Object object) throws Exception{

		int number = 0;
		List<Class<?>> lstSequence = (List<Class<?>>) getAgaramDaoSupport().findBySingleConditionalField(EntityMapper.SEQUENCENO.getmappername(),object.getClass(), "where "+EntityMapper.TABLENAME.getmappername()+"='"+object.getClass().getSimpleName()+"'");
		if(lstSequence != null){
			if(lstSequence.size() > 0){
				Object objMaker =lstSequence.get(0);
				number = Integer.parseInt(objQueryCreater.invokeMethod(objMaker,EntityMethods.GETSEQUENCENUMBER.getmethodname()));
				number = number +1;
				getAgaramDaoSupport().getHibernateTemplate().bulkUpdate("Update "+object.getClass().getSimpleName()+" set "+EntityMapper.SEQUENCENO.getmappername()+"="+number+" where "+EntityMapper.TABLENAME.getmappername()+"='"+object.getClass().getSimpleName()+"' ");

			}
		}
		return number;
	}

	public byte[]  fnParseFile(String sFileName) throws IOException {

		String stFilePath = getAbsolutePath() + sFileName;

		File file = new File(stFilePath);
		byte[] bFile = new byte[(int) file.length()];

		//convert file into array of bytes
		FileInputStream fileInputStream;
		fileInputStream = new FileInputStream(file);
		fileInputStream.read(bFile);
		fileInputStream.close();
		return bFile;
	}

	public void fnDownloadFile(byte[] bfileimage,String sFileName) throws IOException {
		byte[] bFileImage = bfileimage;
		String stFilePath  = getAbsolutePath() + sFileName;

		FileOutputStream fos = new FileOutputStream(stFilePath);
		fos.write(bFileImage);
		fos.close();

	}

	public void updateSequence(Object object,int count) throws Exception{
		getAgaramDaoSupport().getHibernateTemplate().bulkUpdate("Update "+object.getClass().getSimpleName()+" set "+EntityMapper.SEQUENCENO.getmappername()+"="+count+" where "+EntityMapper.TABLENAME.getmappername()+"='"+object.getClass().getSimpleName()+"' ");
	}

	public void updateSequence(Class<?> classname,int count) throws Exception{
		getAgaramDaoSupport().getHibernateTemplate().bulkUpdate("Update "+classname.getSimpleName()+" set "+EntityMapper.SEQUENCENO.getmappername()+"="+count+" where "+EntityMapper.TABLENAME.getmappername()+"='"+classname.getSimpleName()+"' ");

	}

	public int lockRunningMaker(Object object) throws Exception{
		int number = 0;
		List<RunningMaker> lstMaker = (List<RunningMaker>) getAgaramDaoSupport().findBySingleConditionalField("sequencenumber", RunningMaker.class, "where tablename='"+object.getClass().getSimpleName()+"'");
		if(lstMaker != null){
			if(lstMaker.size() > 0){
				RunningMaker objMaker = lstMaker.get(0);
				number = objMaker.getsequencenumber();
			}
		}
		return number;
	}

	public void updateRunningMaker(int number,Object object) throws Exception{
		getAgaramDaoSupport().getHibernateTemplate().bulkUpdate("Update RunningMaker set sequencenumber="+number+" where tablename='"+object.getClass().getSimpleName()+"' ");

	}




	public static String getRowMapper(Class<?> classes){
		StringBuilder objBuilder = new StringBuilder();
		Set<Method> settter = ReflectionUtils.getAllMethods(classes,
				ReflectionUtils.withModifier(Modifier.PUBLIC), ReflectionUtils.withPrefix("set"));
		objBuilder.append(classes.getSimpleName() +" obj"+ classes.getSimpleName()+" = new "+classes.getSimpleName()+"();"+ "\n");
		List<Field>  lstField = Arrays.asList(classes.getDeclaredFields());
		for(Method method:settter){
			method.setAccessible(true);

			Type[] type = method.getGenericParameterTypes();
			Class<?> typeValue = (Class<?>) type[0];
			switch(typeValue.getSimpleName()){
			case "int":
				objBuilder.append(" obj"+ classes.getSimpleName()+"."+method.getName()+"(objMapper.getInteger("+getFieldName(method.getName(),lstField)+"));"+ "\n");
				break;
			case "Integer":
				objBuilder.append(" obj"+ classes.getSimpleName()+"."+method.getName()+"(objMapper.getInteger("+getFieldName(method.getName(),lstField)+"));"+ "\n");
				break;
			case "String":
				objBuilder.append(" obj"+ classes.getSimpleName()+"."+method.getName()+"(objMapper.getString("+getFieldName(method.getName(),lstField)+"));"+ "\n");
				break;
			case "double":
				objBuilder.append(" obj"+ classes.getSimpleName()+"."+method.getName()+"(objMapper.getDouble("+getFieldName(method.getName(),lstField)+"));"+ "\n");
				break;
			case "Double":
				objBuilder.append(" obj"+ classes.getSimpleName()+"."+method.getName()+"(objMapper.getDouble("+getFieldName(method.getName(),lstField)+"));"+ "\n");
				break;
			case "float":
				objBuilder.append(" obj"+ classes.getSimpleName()+"."+method.getName()+"(objMapper.getFloat("+getFieldName(method.getName(),lstField)+"));"+ "\n");
				break;
			case "Float":
				objBuilder.append(" obj"+ classes.getSimpleName()+"."+method.getName()+"(objMapper.getFloat("+getFieldName(method.getName(),lstField)+"));"+ "\n");
				break;
			case "Date":
				objBuilder.append(" obj"+ classes.getSimpleName()+"."+method.getName()+"(objMapper.getDate("+getFieldName(method.getName(),lstField)+"));"+ "\n");
				break;
			case "long":
				objBuilder.append(" obj"+ classes.getSimpleName()+"."+method.getName()+"(objMapper.getLong("+getFieldName(method.getName(),lstField)+"));"+ "\n");
				break;
			case "Long":
				objBuilder.append(" obj"+ classes.getSimpleName()+"."+method.getName()+"(objMapper.getLong("+getFieldName(method.getName(),lstField)+"));"+ "\n");
				break;
			case "byte":
				objBuilder.append(" obj"+ classes.getSimpleName()+"."+method.getName()+"(objMapper.getByte("+getFieldName(method.getName(),lstField)+"));"+ "\n");
				break;
			case "Byte":
				objBuilder.append(" obj"+ classes.getSimpleName()+"."+method.getName()+"(objMapper.getByte("+getFieldName(method.getName(),lstField)+"));"+ "\n");
				break;
			case "boolean":
				objBuilder.append(" obj"+ classes.getSimpleName()+"."+method.getName()+"(objMapper.getBoolean("+getFieldName(method.getName(),lstField)+"));"+ "\n");
				break;
			case "Boolean":
				objBuilder.append(" obj"+ classes.getSimpleName()+"."+method.getName()+"(objMapper.getBoolean("+getFieldName(method.getName(),lstField)+"));"+ "\n");
				break;
			case "short":
				objBuilder.append(" obj"+ classes.getSimpleName()+"."+method.getName()+"(objMapper.getShort("+getFieldName(method.getName(),lstField)+"));"+ "\n");
				break;
			case "Short":
				objBuilder.append(" obj"+ classes.getSimpleName()+"."+method.getName()+"(objMapper.getShort("+getFieldName(method.getName(),lstField)+"));"+ "\n");
				break;
			default :
				break;
			}

		}

		System.err.println(objBuilder.toString());
		return  objBuilder.toString();

	}

	private static String getFieldName(String methodname, List<Field> lstField){
		String name= methodname.substring(3, methodname.length());
		for(Field objField : lstField){
			if(objField.getName().trim().toUpperCase().equals(name.trim().toUpperCase())){
				name = "\""+objField.getName()+"\"";
				break;
			}
		}
		return name;
	}

	public String getQuery(String query,String columnname,Object... args) {
		List<Object> lstObject = Arrays.asList(args);
		//		columnname = columnname.trim().endsWith(Tokens.COMMA.gettokens())==true?columnname.trim():columnname.trim()+Tokens.COMMA.gettokens();
		List<String> lstColumns = Arrays.asList(columnname.split(","));
		for(Object object : lstObject){

			boolean flag = false;
			//			
			if(object != null){


				//			String ss= object.getClass().getSimpleName();
				Type type = object.getClass();
				Class<?> typeValue = (Class<?>) type;

				for(String field:lstColumns){

					String find = "@"+field+"@";
					switch(typeValue.getSimpleName()){

					case "int":
						do{
							String lowerCase = query.toLowerCase();
							int index = lowerCase.indexOf(find);
							if(index > -1){
								String findText= query.substring(index);
								String findReplaceText= findText.substring(1);
								int textLastIndex = findReplaceText.indexOf("@");
								String actualText=query.substring(index,index+(textLastIndex+2));
								actualText = actualText.replaceAll("\"", "");
								if(actualText.equalsIgnoreCase(find)){
									int output = ((Integer)object).intValue();
									query = query.substring(0,index)+Integer.toString(output)+query.substring(index+(textLastIndex+2),query.length());  
									flag = true;
								}
								System.err.println(actualText);
							}else{
								break;
							}
							System.err.println(index);	

						}while(true);

						break;
					case "Integer":
						do{
							String lowerCase = query.toLowerCase();
							int index = lowerCase.indexOf(find);
							if(index > -1){
								String findText= query.substring(index);
								String findReplaceText= findText.substring(1);
								int textLastIndex = findReplaceText.indexOf("@");
								String actualText=query.substring(index,index+(textLastIndex+2));
								actualText = actualText.replaceAll("\"", "");
								if(actualText.equalsIgnoreCase(find)){
									int output = ((Integer)object).intValue();
									query = query.substring(0,index)+Integer.toString(output)+query.substring(index+(textLastIndex+2),query.length());  
									flag = true;
								}
								System.err.println(actualText);
							}else{
								break;
							}
							System.err.println(index);	

						}while(true);
						break;
					case "String":
						do{
							String lowerCase = query.toLowerCase();
							int index = lowerCase.indexOf(find);
							if(index > -1){
								String findText= query.substring(index);
								String findReplaceText= findText.substring(1);
								int textLastIndex = findReplaceText.indexOf("@");
								String actualText=query.substring(index,index+(textLastIndex+2));
								actualText = actualText.replaceAll("\"", "");
								if(actualText.equalsIgnoreCase(find)){
									String output = ((String)object);
									query = query.substring(0,index)+"'"+output+"'"+query.substring(index+(textLastIndex+2),query.length());
									flag = true;
								}
								System.err.println(actualText);
							}
							else{
								break;
							}
							System.err.println(index);	

						}while(true);
						break;
					case "double":
						do{
							String lowerCase = query.toLowerCase();
							int index = lowerCase.indexOf(find);
							if(index > -1){
								String findText= query.substring(index);
								String findReplaceText= findText.substring(1);
								int textLastIndex = findReplaceText.indexOf("@");
								String actualText=query.substring(index,index+(textLastIndex+2));
								actualText = actualText.replaceAll("\"", "");
								if(actualText.equalsIgnoreCase(find)){
									double output = ((Double)object).doubleValue();
									query = query.substring(0,index)+output+query.substring(index+(textLastIndex+2),query.length());
									flag = true;
								}
								System.err.println(actualText);
							}
							else{
								break;
							}
							System.err.println(index);	

						}while(true);
						break;
					case "Double":
						do{
							String lowerCase = query.toLowerCase();
							int index = lowerCase.indexOf(find);
							if(index > -1){
								String findText= query.substring(index);
								String findReplaceText= findText.substring(1);
								int textLastIndex = findReplaceText.indexOf("@");
								String actualText=query.substring(index,index+(textLastIndex+2));
								actualText = actualText.replaceAll("\"", "");
								if(actualText.equalsIgnoreCase(find)){
									double output = ((Double)object).doubleValue();
									query = query.substring(0,index)+output+query.substring(index+(textLastIndex+2),query.length());  
									flag = true;
								}
								System.err.println(actualText);
							}
							else{
								break;
							}
							System.err.println(index);	

						}while(true);
						break;
					case "float":
						do{
							String lowerCase = query.toLowerCase();
							int index = lowerCase.indexOf(find);
							if(index > -1){
								String findText= query.substring(index);
								String findReplaceText= findText.substring(1);
								int textLastIndex = findReplaceText.indexOf("@");
								String actualText=query.substring(index,index+(textLastIndex+2));
								actualText = actualText.replaceAll("\"", "");
								if(actualText.equalsIgnoreCase(find)){
									float output = ((Float)object).floatValue();
									query = query.substring(0,index)+output+query.substring(index+(textLastIndex+2),query.length());  
									flag = true;
								}
								System.err.println(actualText);
							}
							else{
								break;
							}
							System.err.println(index);	

						}while(true);
						break;
					case "Float":
						do{
							String lowerCase = query.toLowerCase();
							int index = lowerCase.indexOf(find);
							if(index > -1){
								String findText= query.substring(index);
								String findReplaceText= findText.substring(1);
								int textLastIndex = findReplaceText.indexOf("@");
								String actualText=query.substring(index,index+(textLastIndex+2));
								actualText = actualText.replaceAll("\"", "");
								if(actualText.equalsIgnoreCase(find)){
									float output = ((Float)object).floatValue();
									query = query.substring(0,index)+output+query.substring(index+(textLastIndex+2),query.length());  
									flag = true;
								}
								System.err.println(actualText);
							}
							else{
								break;
							}
							System.err.println(index);	

						}while(true);
						break;
					case "Date":
						do{
							String lowerCase = query.toLowerCase();
							int index = lowerCase.indexOf(find);
							if(index > -1){
								String findText= query.substring(index);
								String findReplaceText= findText.substring(1);
								int textLastIndex = findReplaceText.indexOf("@");
								String actualText=query.substring(index,index+(textLastIndex+2));
								actualText = actualText.replaceAll("\"", "");
								if(actualText.equalsIgnoreCase(find)){
									Date output = ((Date)object);
									query = query.substring(0,index)+"'"+output+"'"+query.substring(index+(textLastIndex+2),query.length());  
									flag = true;
								}
								System.err.println(actualText);
							}
							else{
								break;
							}
							System.err.println(index);	

						}while(true);
						break;
					case "long":
						do{
							String lowerCase = query.toLowerCase();
							int index = lowerCase.indexOf(find);
							if(index > -1){
								String findText= query.substring(index);
								String findReplaceText= findText.substring(1);
								int textLastIndex = findReplaceText.indexOf("@");
								String actualText=query.substring(index,index+(textLastIndex+2));
								actualText = actualText.replaceAll("\"", "");
								if(actualText.equalsIgnoreCase(find)){
									long output = ((Long)object).longValue();
									query = query.substring(0,index)+output+query.substring(index+(textLastIndex+2),query.length());  
									flag = true;
								}
								System.err.println(actualText);
							}
							else{
								break;
							}
							System.err.println(index);	

						}while(true);
						break;
					case "Long":
						do{
							String lowerCase = query.toLowerCase();
							int index = lowerCase.indexOf(find);
							if(index > -1){
								String findText= query.substring(index);
								String findReplaceText= findText.substring(1);
								int textLastIndex = findReplaceText.indexOf("@");
								String actualText=query.substring(index,index+(textLastIndex+2));
								actualText = actualText.replaceAll("\"", "");
								if(actualText.equalsIgnoreCase(find)){
									long output = ((Long)object).longValue();
									query = query.substring(0,index)+output+query.substring(index+(textLastIndex+2),query.length());  
									flag = true;
								}
								System.err.println(actualText);
							}else{
								break;
							}
							System.err.println(index);	

						}while(true);
						break;
					case "byte":
						do{
							String lowerCase = query.toLowerCase();
							int index = lowerCase.indexOf(find);
							if(index > -1){
								String findText= query.substring(index);
								String findReplaceText= findText.substring(1);
								int textLastIndex = findReplaceText.indexOf("@");
								String actualText=query.substring(index,index+(textLastIndex+2));
								actualText = actualText.replaceAll("\"", "");
								if(actualText.equalsIgnoreCase(find)){
									byte output = ((Byte)object).byteValue();
									query = query.substring(0,index)+output+query.substring(index+(textLastIndex+2),query.length());  
									flag = true;
								}
								System.err.println(actualText);
							}
							else{
								break;
							}
							System.err.println(index);	

						}while(true);
						break;
					case "Byte":
						do{
							String lowerCase = query.toLowerCase();
							int index = lowerCase.indexOf(find);
							if(index > -1){
								String findText= query.substring(index);
								String findReplaceText= findText.substring(1);
								int textLastIndex = findReplaceText.indexOf("@");
								String actualText=query.substring(index,index+(textLastIndex+2));
								actualText = actualText.replaceAll("\"", "");
								if(actualText.equalsIgnoreCase(find)){
									byte output = ((Byte)object).byteValue();
									query = query.substring(0,index)+output+query.substring(index+(textLastIndex+2),query.length());  
									flag = true;
								}
								System.err.println(actualText);
							}
							else{
								break;
							}
							System.err.println(index);	

						}while(true);
						break;
					case "boolean":
						do{
							String lowerCase = query.toLowerCase();
							int index = lowerCase.indexOf(find);
							if(index > -1){
								String findText= query.substring(index);
								String findReplaceText= findText.substring(1);
								int textLastIndex = findReplaceText.indexOf("@");
								String actualText=query.substring(index,index+(textLastIndex+2));
								actualText = actualText.replaceAll("\"", "");
								if(actualText.equalsIgnoreCase(find)){
									boolean output = ((Boolean)object).booleanValue();
									query = query.substring(0,index)+output+query.substring(index+(textLastIndex+2),query.length());  
									flag = true;
								}
								System.err.println(actualText);
							}
							else{
								break;
							}
							System.err.println(index);	

						}while(true);
						break;
					case "Boolean":
						do{
							String lowerCase = query.toLowerCase();
							int index = lowerCase.indexOf(find);
							if(index > -1){
								String findText= query.substring(index);
								String findReplaceText= findText.substring(1);
								int textLastIndex = findReplaceText.indexOf("@");
								String actualText=query.substring(index,index+(textLastIndex+2));
								actualText = actualText.replaceAll("\"", "");
								if(actualText.equalsIgnoreCase(find)){
									boolean output = ((Boolean)object).booleanValue();
									query = query.substring(0,index)+output+query.substring(index+(textLastIndex+2),query.length());  
									flag = true;
								}
								System.err.println(actualText);
							}
							else{
								break;
							}
							System.err.println(index);	

						}while(true);
						break;
					case "short":
						do{
							String lowerCase = query.toLowerCase();
							int index = lowerCase.indexOf(find);
							if(index > -1){
								String findText= query.substring(index);
								String findReplaceText= findText.substring(1);
								int textLastIndex = findReplaceText.indexOf("@");
								String actualText=query.substring(index,index+(textLastIndex+2));
								actualText = actualText.replaceAll("\"", "");
								if(actualText.equalsIgnoreCase(find)){
									short output = ((Short)object).shortValue();
									query = query.substring(0,index)+output+query.substring(index+(textLastIndex+2),query.length());  
									flag = true;
								}
								System.err.println(actualText);
							}
							else{
								break;
							}
							System.err.println(index);	

						}while(true);
						break;
					case "Short":
						do{
							String lowerCase = query.toLowerCase();
							int index = lowerCase.indexOf(find);
							if(index > -1){
								String findText= query.substring(index);
								String findReplaceText= findText.substring(1);
								int textLastIndex = findReplaceText.indexOf("@");
								String actualText=query.substring(index,index+(textLastIndex+2));
								actualText = actualText.replaceAll("\"", "");
								if(actualText.equalsIgnoreCase(find)){
									short output = ((Short)object).shortValue();
									query = query.substring(0,index)+output+query.substring(index+(textLastIndex+2),query.length());  
									flag = true;
								}
								System.err.println(actualText);
							}
							else{
								break;
							}
							System.err.println(index);	

						}while(true);
						break;
					default :
						break;
					}
					if(flag)
						break;
				}
			}else{
				for(String field:lstColumns){
					String find = "@"+field+"@";
					do{
						String lowerCase = query.toLowerCase();
						int index = lowerCase.indexOf(find);
						if(index > -1){
							String findText= query.substring(index);
							String findReplaceText= findText.substring(1);
							int textLastIndex = findReplaceText.indexOf("@");
							String actualText=query.substring(index,index+(textLastIndex+2));
							actualText = actualText.replaceAll("\"", "");
							if(actualText.equalsIgnoreCase(find)){
								//								String output = ((String)object);
								query = query.substring(0,index)+null+query.substring(index+(textLastIndex+2),query.length());
								flag = true;
							}
							System.err.println(actualText);
						}
						else{
							break;
						}
						System.err.println(index);	

					}while(true);
					if(flag)
						break;
				}
			}

			//			System.err.println(typeValue.getSimpleName());

		}
		return query;
	}

	public String getQuery(String query,Object... args) throws IllegalArgumentException, IllegalAccessException{

		//		Pattern pattern = Pattern.compile("\"([^\"]*)\"");
		//		Pattern pattern = Pattern.compile("\\@.*\\@");

		List<Object> lstObject = Arrays.asList(args);
		StringBuilder objBuilder = new StringBuilder(query);

		for(Object object : lstObject){
			String ss= object.getClass().getSimpleName();
			String tableName = objQueryCreater.getEntityTableName(object.getClass());
			List<Field>  lstField = Arrays.asList(object.getClass().getDeclaredFields());
			for(Field field:lstField){
				field.setAccessible(true);
				Type type = field.getGenericType();
				Class<?> typeValue = (Class<?>) type;
				String find = "@"+tableName+"."+field.getName().toLowerCase()+"@";
				switch(typeValue.getSimpleName()){

				case "int":
					do{
						String lowerCase = query.toLowerCase();
						int index = lowerCase.indexOf(find);
						if(index > -1){
							String findText= query.substring(index);
							String findReplaceText= findText.substring(1);
							int textLastIndex = findReplaceText.indexOf("@");
							String actualText=query.substring(index,index+(textLastIndex+2));
							actualText = actualText.replaceAll("\"", "");
							if(actualText.equalsIgnoreCase(find)){
								int output = field.getInt(object);
								query = query.substring(0,index)+Integer.toString(output)+query.substring(index+(textLastIndex+2),query.length());  
							}
							System.err.println(actualText);
						}else{
							break;
						}
						System.err.println(index);	

					}while(true);

					break;
				case "Integer":
					do{
						String lowerCase = query.toLowerCase();
						int index = lowerCase.indexOf(find);
						if(index > -1){
							String findText= query.substring(index);
							String findReplaceText= findText.substring(1);
							int textLastIndex = findReplaceText.indexOf("@");
							String actualText=query.substring(index,index+(textLastIndex+2));
							actualText = actualText.replaceAll("\"", "");
							if(actualText.equalsIgnoreCase(find)){
								int output = ((Integer)field.get(object)).intValue();
								query = query.substring(0,index)+Integer.toString(output)+query.substring(index+(textLastIndex+2),query.length());  
							}
							System.err.println(actualText);
						}else{
							break;
						}
						System.err.println(index);	

					}while(true);
					break;
				case "String":
					do{
						String lowerCase = query.toLowerCase();
						int index = lowerCase.indexOf(find);
						if(index > -1){
							String findText= query.substring(index);
							String findReplaceText= findText.substring(1);
							int textLastIndex = findReplaceText.indexOf("@");
							String actualText=query.substring(index,index+(textLastIndex+2));
							actualText = actualText.replaceAll("\"", "");
							if(actualText.equalsIgnoreCase(find)){
								String output = ((String)field.get(object));
								query = query.substring(0,index)+"'"+output+"'"+query.substring(index+(textLastIndex+2),query.length());  
							}
							System.err.println(actualText);
						}else{
							break;
						}
						System.err.println(index);	

					}while(true);
					break;
				case "double":
					do{
						String lowerCase = query.toLowerCase();
						int index = lowerCase.indexOf(find);
						if(index > -1){
							String findText= query.substring(index);
							String findReplaceText= findText.substring(1);
							int textLastIndex = findReplaceText.indexOf("@");
							String actualText=query.substring(index,index+(textLastIndex+2));
							actualText = actualText.replaceAll("\"", "");
							if(actualText.equalsIgnoreCase(find)){
								double output = field.getDouble(object);
								query = query.substring(0,index)+output+query.substring(index+(textLastIndex+2),query.length());  
							}
							System.err.println(actualText);
						}else{
							break;
						}
						System.err.println(index);	

					}while(true);
					break;
				case "Double":
					do{
						String lowerCase = query.toLowerCase();
						int index = lowerCase.indexOf(find);
						if(index > -1){
							String findText= query.substring(index);
							String findReplaceText= findText.substring(1);
							int textLastIndex = findReplaceText.indexOf("@");
							String actualText=query.substring(index,index+(textLastIndex+2));
							actualText = actualText.replaceAll("\"", "");
							if(actualText.equalsIgnoreCase(find)){
								double output = ((Double)field.get(object)).doubleValue();
								query = query.substring(0,index)+output+query.substring(index+(textLastIndex+2),query.length());  
							}
							System.err.println(actualText);
						}else{
							break;
						}
						System.err.println(index);	

					}while(true);
					break;
				case "float":
					do{
						String lowerCase = query.toLowerCase();
						int index = lowerCase.indexOf(find);
						if(index > -1){
							String findText= query.substring(index);
							String findReplaceText= findText.substring(1);
							int textLastIndex = findReplaceText.indexOf("@");
							String actualText=query.substring(index,index+(textLastIndex+2));
							actualText = actualText.replaceAll("\"", "");
							if(actualText.equalsIgnoreCase(find)){
								float output = field.getFloat(object);
								query = query.substring(0,index)+output+query.substring(index+(textLastIndex+2),query.length());  
							}
							System.err.println(actualText);
						}else{
							break;
						}
						System.err.println(index);	

					}while(true);
					break;
				case "Float":
					do{
						String lowerCase = query.toLowerCase();
						int index = lowerCase.indexOf(find);
						if(index > -1){
							String findText= query.substring(index);
							String findReplaceText= findText.substring(1);
							int textLastIndex = findReplaceText.indexOf("@");
							String actualText=query.substring(index,index+(textLastIndex+2));
							actualText = actualText.replaceAll("\"", "");
							if(actualText.equalsIgnoreCase(find)){
								float output = ((Float)field.get(object)).floatValue();
								query = query.substring(0,index)+output+query.substring(index+(textLastIndex+2),query.length());  
							}
							System.err.println(actualText);
						}else{
							break;
						}
						System.err.println(index);	

					}while(true);
					break;
				case "Date":
					do{
						String lowerCase = query.toLowerCase();
						int index = lowerCase.indexOf(find);
						if(index > -1){
							String findText= query.substring(index);
							String findReplaceText= findText.substring(1);
							int textLastIndex = findReplaceText.indexOf("@");
							String actualText=query.substring(index,index+(textLastIndex+2));
							actualText = actualText.replaceAll("\"", "");
							if(actualText.equalsIgnoreCase(find)){
								Date output = ((Date)field.get(object));
								query = query.substring(0,index)+"'"+output+"'"+query.substring(index+(textLastIndex+2),query.length());  
							}
							System.err.println(actualText);
						}else{
							break;
						}
						System.err.println(index);	

					}while(true);
					break;
				case "long":
					do{
						String lowerCase = query.toLowerCase();
						int index = lowerCase.indexOf(find);
						if(index > -1){
							String findText= query.substring(index);
							String findReplaceText= findText.substring(1);
							int textLastIndex = findReplaceText.indexOf("@");
							String actualText=query.substring(index,index+(textLastIndex+2));
							actualText = actualText.replaceAll("\"", "");
							if(actualText.equalsIgnoreCase(find)){
								long output = field.getLong(object);
								query = query.substring(0,index)+output+query.substring(index+(textLastIndex+2),query.length());  
							}
							System.err.println(actualText);
						}else{
							break;
						}
						System.err.println(index);	

					}while(true);
					break;
				case "Long":
					do{
						String lowerCase = query.toLowerCase();
						int index = lowerCase.indexOf(find);
						if(index > -1){
							String findText= query.substring(index);
							String findReplaceText= findText.substring(1);
							int textLastIndex = findReplaceText.indexOf("@");
							String actualText=query.substring(index,index+(textLastIndex+2));
							actualText = actualText.replaceAll("\"", "");
							if(actualText.equalsIgnoreCase(find)){
								long output = ((Long)field.get(object)).longValue();
								query = query.substring(0,index)+output+query.substring(index+(textLastIndex+2),query.length());  
							}
							System.err.println(actualText);
						}else{
							break;
						}
						System.err.println(index);	

					}while(true);
					break;
				case "byte":
					do{
						String lowerCase = query.toLowerCase();
						int index = lowerCase.indexOf(find);
						if(index > -1){
							String findText= query.substring(index);
							String findReplaceText= findText.substring(1);
							int textLastIndex = findReplaceText.indexOf("@");
							String actualText=query.substring(index,index+(textLastIndex+2));
							actualText = actualText.replaceAll("\"", "");
							if(actualText.equalsIgnoreCase(find)){
								byte output = field.getByte(object);
								query = query.substring(0,index)+output+query.substring(index+(textLastIndex+2),query.length());  
							}
							System.err.println(actualText);
						}else{
							break;
						}
						System.err.println(index);	

					}while(true);
					break;
				case "Byte":
					do{
						String lowerCase = query.toLowerCase();
						int index = lowerCase.indexOf(find);
						if(index > -1){
							String findText= query.substring(index);
							String findReplaceText= findText.substring(1);
							int textLastIndex = findReplaceText.indexOf("@");
							String actualText=query.substring(index,index+(textLastIndex+2));
							actualText = actualText.replaceAll("\"", "");
							if(actualText.equalsIgnoreCase(find)){
								byte output = ((Byte)field.get(object)).byteValue();
								query = query.substring(0,index)+output+query.substring(index+(textLastIndex+2),query.length());  
							}
							System.err.println(actualText);
						}else{
							break;
						}
						System.err.println(index);	

					}while(true);
					break;
				case "boolean":
					do{
						String lowerCase = query.toLowerCase();
						int index = lowerCase.indexOf(find);
						if(index > -1){
							String findText= query.substring(index);
							String findReplaceText= findText.substring(1);
							int textLastIndex = findReplaceText.indexOf("@");
							String actualText=query.substring(index,index+(textLastIndex+2));
							actualText = actualText.replaceAll("\"", "");
							if(actualText.equalsIgnoreCase(find)){
								boolean output = field.getBoolean(object);
								query = query.substring(0,index)+output+query.substring(index+(textLastIndex+2),query.length());  
							}
							System.err.println(actualText);
						}else{
							break;
						}
						System.err.println(index);	

					}while(true);
					break;
				case "Boolean":
					do{
						String lowerCase = query.toLowerCase();
						int index = lowerCase.indexOf(find);
						if(index > -1){
							String findText= query.substring(index);
							String findReplaceText= findText.substring(1);
							int textLastIndex = findReplaceText.indexOf("@");
							String actualText=query.substring(index,index+(textLastIndex+2));
							actualText = actualText.replaceAll("\"", "");
							if(actualText.equalsIgnoreCase(find)){
								boolean output = ((Boolean)field.get(object)).booleanValue();
								query = query.substring(0,index)+output+query.substring(index+(textLastIndex+2),query.length());  
							}
							System.err.println(actualText);
						}else{
							break;
						}
						System.err.println(index);	

					}while(true);
					break;
				case "short":
					do{
						String lowerCase = query.toLowerCase();
						int index = lowerCase.indexOf(find);
						if(index > -1){
							String findText= query.substring(index);
							String findReplaceText= findText.substring(1);
							int textLastIndex = findReplaceText.indexOf("@");
							String actualText=query.substring(index,index+(textLastIndex+2));
							actualText = actualText.replaceAll("\"", "");
							if(actualText.equalsIgnoreCase(find)){
								short output = field.getShort(object);
								query = query.substring(0,index)+output+query.substring(index+(textLastIndex+2),query.length());  
							}
							System.err.println(actualText);
						}else{
							break;
						}
						System.err.println(index);	

					}while(true);
					break;
				case "Short":
					do{
						String lowerCase = query.toLowerCase();
						int index = lowerCase.indexOf(find);
						if(index > -1){
							String findText= query.substring(index);
							String findReplaceText= findText.substring(1);
							int textLastIndex = findReplaceText.indexOf("@");
							String actualText=query.substring(index,index+(textLastIndex+2));
							actualText = actualText.replaceAll("\"", "");
							if(actualText.equalsIgnoreCase(find)){
								short output = ((Short)field.get(object)).shortValue();
								query = query.substring(0,index)+output+query.substring(index+(textLastIndex+2),query.length());  
							}
							System.err.println(actualText);
						}else{
							break;
						}
						System.err.println(index);	

					}while(true);
					break;
				default :
					break;
				}
			}
		}
		System.out.println(query);
		return query;

	}

	public ApplicationContext getApplicationContext() {
		return applicationContext;
	}

	public void setApplicationContext(ApplicationContext applicationContext) {
		this.applicationContext = applicationContext;
	}

	// Created By mani on 23-07-14 
	// Description ----- this method return all the active services in applicationcontext
	public List<AgaramEntityMethods> getService() throws ServletException, IOException, NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, ClassNotFoundException {
		setApplicationContext(WebApplicationContextUtils.getWebApplicationContext(getServletContext()));
		List<AgaramEntityMethods> lstServices = null;


		getApplicationContext().getBeanDefinitionNames();
		getApplicationContext().getBeanNamesForType(RemotingDestinationExporter.class, true, true);


		Map<String,RemotingDestinationExporter> map=getApplicationContext().getBeansOfType(RemotingDestinationExporter.class, false, true);

		for (Map.Entry<String, RemotingDestinationExporter> entry : map.entrySet()) {


			Method[] mtt=	entry.getValue().getClass().getSuperclass().getDeclaredMethods();

			Method mtha;

			mtha = entry.getValue().getClass().getSuperclass().getDeclaredMethod("getDestinationId",null);

			AbstractDestinationFactory djd=entry.getValue();

			mtha.setAccessible(true);

			String returnValue = (String)
					mtha.invoke(entry.getValue(),(Object[]) null);

			Object obj = getApplicationContext().getBean(returnValue);



			AgaramEntityMethods objMethod = new AgaramEntityMethods();
			objMethod.setservicename(returnValue);

			if(lstServices == null)
			{
				lstServices = new ArrayList<>();
			}	
			lstServices.add(objMethod);

		}

		return lstServices;
	}


	// Created By mani on 23-07-14 
	// Description ----- this method return all the public methods from the class
	public List<AgaramEntityMethods> getServicePublicMethod(String className) throws ClassNotFoundException{



		Map<String, List<AgaramEntityMethods>> mapMethod = null;
		Map<String,List<AgaramEntityMethods>> mapParameter = null;
		Map<String, Map<String, List<AgaramEntityMethods>>> mapRtn = null;

		Class clazz = Class.forName(className);
		Method[] method = clazz.getDeclaredMethods();

		List<AgaramEntityMethods> lstMethods = null;


		for (int i = 0; i < method.length; i++)
		{
			if(lstMethods == null)
			{
				lstMethods = new ArrayList<>();
			}


			AgaramEntityMethods objMethod = new AgaramEntityMethods();

			objMethod.setmethodname(method[i].getName());
			Class<?> classReturn = method[i].getReturnType();
			objMethod.setreturntype(classReturn.getSimpleName());

			lstMethods.add(objMethod);

			if(mapParameter == null)
				mapParameter = new HashMap<String,List<AgaramEntityMethods>>();
		}

		if(mapMethod == null)
			mapMethod = new HashMap<String, List<AgaramEntityMethods>>();

		mapMethod.put("method", lstMethods);

		if(mapRtn == null)
			mapRtn = new HashMap<String, Map<String, List<AgaramEntityMethods>>>();

		mapRtn.put("method", mapMethod);
		mapRtn.put("parameter", mapParameter);

		return lstMethods;
	}

	// Description ----- this method return all the method parameter and return type
	public List<AgaramEntityMethods> getMethodParameter(String service,String methodName) throws ClassNotFoundException, NoSuchMethodException, SecurityException{

		List<AgaramEntityMethods> lstMethods = null;
		Class clazz = Class.forName(service);
		Method[] methodarray = clazz.getDeclaredMethods();

		Method method = null;
		for (int index = 0; index < methodarray.length; index++)
		{
			if(methodName.compareTo(methodarray[index].getName().toString()) == 0)
			{
				method = methodarray[index];
				break;
			}
		}
		if(method != null)
		{
			Map<String,List<AgaramEntityMethods>> mapRtn = new HashMap<String,List<AgaramEntityMethods>>();

			Class<?> classReturn = method.getReturnType();

			Class[] classArray = method.getParameterTypes();
			if(classArray.length > 0)
			{
				for (int i = 0; i < classArray.length; i++)
				{
					AgaramEntityMethods objMethod = new AgaramEntityMethods();
					objMethod.setparametertypes(classArray[i].getName().toString());
					if(lstMethods == null)
					{
						lstMethods = new ArrayList<AgaramEntityMethods>();
					}

					lstMethods.add(objMethod);
				}
				mapRtn.put(method.getName(), lstMethods);
			}
		}
		return lstMethods;
	}




	public String getServiceXML() throws Exception  {
		setApplicationContext(WebApplicationContextUtils.getWebApplicationContext(getServletContext()));
		List<AgaramEntityMethods> lstServices = null;
		String root = "";
		Map<String,RemotingDestinationExporter> map = getApplicationContext().getBeansOfType(RemotingDestinationExporter.class, false, true);
		root = "<node name='Services'>";
		for(Map.Entry<String,RemotingDestinationExporter> entry : map.entrySet()) {
			Method method = null;
			try {
				method = entry.getValue().getClass().getSuperclass().getDeclaredMethod("getDestinationId",null);
			} catch (NoSuchMethodException | SecurityException e) {
				throw e;
			}

			AbstractDestinationFactory objFactory= entry.getValue();
			method.setAccessible(true);
			String Id = null;
			try {
				Id = (String) method.invoke(entry.getValue(),(Object[]) null);
			} catch (IllegalAccessException e) {
				throw e;
			}
			catch (IllegalArgumentException e) {
				throw e;
			}
			catch (InvocationTargetException e) {
				throw e;
			}

			Object obj = getApplicationContext().getBean(Id);

			root = root +"<node classname='"+obj.getClass().getName() +"' name='"+Id+"'></node>";
		}
		root = root + "</node>";
		return root;
	}

	public String getEntityXML() throws Exception{
		setApplicationContext(WebApplicationContextUtils.getWebApplicationContext(getServletContext()));
		SessionFactoryImpl sessionFactoryImpl = (SessionFactoryImpl) getApplicationContext().getBean("sessionFactory");
		Map<?,?> entityMap = new TreeMap<>(sessionFactoryImpl.getAllClassMetadata());
		String root = "";
		if(entityMap != null){
			if(entityMap.size() > 0 ){
				root = "<node name='Entity'>";
				for (Map.Entry<?, ?> entry : entityMap.entrySet()) {
					try {
						Class<?> entityClass = (Class.forName(((String) entry.getKey())));
						root = root +"<node parentclass='"+entry.getKey()+"' classname='"+entry.getKey() +"' name='"+entityClass.getSimpleName()+"' type='Entity'></node>";
					} catch (ClassNotFoundException e) {
						// TODO Auto-generated catch block
						throw e;
					}

				}
				root = root + "</node>";
			}
		}


		return root;
	}

	public String getEntityXML(String service,String methodName,int parameterCount,String parentclass,String serviceid) throws Exception{
		setApplicationContext(WebApplicationContextUtils.getWebApplicationContext(getServletContext()));
		SessionFactoryImpl sessionFactoryImpl = (SessionFactoryImpl) getApplicationContext().getBean("sessionFactory");
		Map<?,?> entityMap = new TreeMap<>(sessionFactoryImpl.getAllClassMetadata());
		String root = "";
		if(entityMap != null){
			if(entityMap.size() > 0 ){
				root = "<node name='Entity'>";
				for (Map.Entry<?, ?> entry : entityMap.entrySet()) {
					try {
						Class<?> entityClass = (Class.forName(((String) entry.getKey())));
						root = root +"<node parentclass='"+parentclass+"' parameterindex='"+parameterCount+"' serviceid='"+serviceid+"' service='"+service+"' method='"+methodName+"' classname='"+entry.getKey() +"' name='"+entityClass.getSimpleName()+"' type='Entity'></node>";
					} catch (ClassNotFoundException e) {
						// TODO Auto-generated catch block
						throw e;
					}

				}
				root = root + "</node>";
			}
		}


		return root;
	}

	public String getFieldsXML(String classname) throws ClassNotFoundException{
		String root = "";
		if(classname != null){
			if(classname != ""){
				Class<?> entityClass = Class.forName(classname);
				Field[] fields = entityClass.getDeclaredFields();
				root = "<node name='Fields'>";

				for (Field field : fields) {
					Column column = field.getAnnotation(Column.class);
					if (column != null) {
						root = root +"<node parentclass='"+classname+"' classname = '"+classname+"' datatype='"+field.getType()+"' name='"+field.getName()+"' type='Field'></node>";
					}
				}
				root = root + "</node>";
			}
		}


		return root;
	}


	public String getMethodXML(String classname) throws ClassNotFoundException{

		String root = "";
		if(classname != null){
			if(classname != ""){
				root = "<node name='Methods'>";
				Class clazz = Class.forName(classname);
				Method[] methodArray = clazz.getDeclaredMethods();

				//	for (int i = 0; i < methodArray.length; i++)
				for (Method method : methodArray) {
					root = root +"<node service='"+classname+"' returntype='"+method.getReturnType()+"' name='"+method.getName()+"' type='Method'></node>";
				}
				root = root + "</node>";
			}
		}
		return root;
	}


	public String getMethodParameterXML(String service,String methodName) throws ClassNotFoundException, NoSuchMethodException, SecurityException{

		String root = "";

		Class clazz = Class.forName(service);
		Method[] methodArray = clazz.getDeclaredMethods();

		Method method = null;
		for (Method methodTemp : methodArray)
		{
			if(methodName.compareTo(methodTemp.getName().toString()) == 0)
			{
				method = methodTemp;
				break;
			}
		}
		if(method != null)
		{
			Class[] classArray = method.getParameterTypes();
			if(classArray.length > 0)
			{
				root = "<node name='Parameters'>";
				for (Class clazzTemp : classArray)
				{
					root = root +"<node service='"+service+"' method='"+methodName+"' name='"+clazzTemp.getName().toString()+"' type='Parameter'></node>";
				}
				root = root + "</node>";
			}
		}
		return root;
	}

	public String getFieldsXML(String classname,String service,String methodName,int parameterCount,String parentclass,String serviceid) throws ClassNotFoundException{
		String root = "";
		if(classname != null){
			if(classname != ""){
				Class<?> entityClass = Class.forName(classname);
				Field[] fields = entityClass.getDeclaredFields();
				root = "<node name='Fields'>";

				for (Field field : fields) {
					Column column = field.getAnnotation(Column.class);
					if (column != null) {
						root = root +"<node parentclass='"+parentclass+"' parameterindex='"+parameterCount+"' serviceid='"+serviceid+"' service='"+service+"' method='"+methodName+"' classname = '"+classname+"' datatype='"+field.getType()+"' name='"+field.getName()+"' type='Field'></node>";
					}
				}
				root = root + "</node>";
			}
		}


		return root;
	}


	public String getMethodParameterWithEntityFieldsXML(String service,String methodName,String serviceid) throws Exception{

		String root = "";

		Class clazz = Class.forName(service);
		Method[] methodArray = clazz.getDeclaredMethods();

		Method method = null;
		for (Method methodTemp : methodArray)
		{
			if(methodName.compareTo(methodTemp.getName().toString()) == 0)
			{
				method = methodTemp;
				break;
			}
		}
		if(method != null)
		{
			Class[] classArray = method.getParameterTypes();

			int i = 0;

			if(classArray.length > 0)
			{
				root = "<node name='Parameters'>";
				int parameterCount = 0;
				for (Class classes : classArray)
				{
					parameterCount++;
					if(classes.getName().equalsIgnoreCase(List.class.getName()))
					{
						try {

							Type[] types = method.getGenericParameterTypes();
							//Now assuming that the first parameter to the method is of type List<Integer>
							if(types[i] instanceof ParameterizedType)
							{
								ParameterizedType pType = (ParameterizedType) types[i];
								Class<?> clazzc = (Class<?>) pType.getActualTypeArguments()[0];
								root = root+"<node parentclass='"+List.class.getName()+"' parameterindex='"+parameterCount+"' classname = '"+clazzc.getName()+"' service='"+service+"' method='"+methodName+"' name='List-"+clazzc.getSimpleName()+"'>";
								root = root+getFieldsXML(clazzc.getName(),service,methodName,parameterCount,List.class.getName(),serviceid);
								root = root + "</node>";
							}else{
								root = root + "<node parentclass='"+List.class.getName()+"' parameterindex='"+parameterCount+"' service='"+service+"' method='"+methodName+"' name='"+classes.getSimpleName()+"' type='Parameter'>";
								root = root + getEntityXML(service,methodName,parameterCount,List.class.getName(),serviceid);
								root = root + "</node>";
							}

						} catch (Exception e) {
							throw e;
						}
					}
					else if(classes.getName().equalsIgnoreCase(Set.class.getName()))
					{
						try {
							Type[] types = method.getGenericParameterTypes();
							if(types[i] instanceof ParameterizedType)
							{
								ParameterizedType pType = (ParameterizedType) types[i];
								Class<?> clazzc = (Class<?>) pType.getActualTypeArguments()[0];
								root = root+"<node parentclass='"+Set.class.getName()+"' parameterindex='"+parameterCount+"' classname = '"+clazzc.getName()+"' service='"+service+"' method='"+methodName+"' name='Set-"+clazzc.getSimpleName()+"'>";
								root = root+getFieldsXML(clazzc.getName(),service,methodName,parameterCount,Set.class.getName(),serviceid);
								root = root + "</node>";
							}else{
								root = root + "<node parentclass='"+Set.class.getName()+"' parameterindex='"+parameterCount+"' service='"+service+"' method='"+methodName+"' name='"+classes.getSimpleName()+"' type='Parameter'>";
								root = root + getEntityXML(service,methodName,parameterCount,Set.class.getName(),serviceid);
								root = root + "</node>";
							}
						} catch (Exception e) {
							throw e;
						}
					}

					else if(classes.getName() instanceof Object)
					{

						if(Integer.TYPE.getName().compareToIgnoreCase(classes.getName()) != 0 && String.class.getName().compareToIgnoreCase(classes.getName()) != 0 
								&& Double.TYPE.getName().compareToIgnoreCase(classes.getName()) != 0 && Float.TYPE.getName().compareToIgnoreCase(classes.getName()) != 0
								&& Short.TYPE.getName().compareToIgnoreCase(classes.getName()) != 0)
						{

							String strQuery = "";

							strQuery = getEntityFieldsXMLWithIndex(classes.getName(),service,methodName,parameterCount,serviceid);

							if(strQuery.trim().length() > 0)
							{
								root = root+"<node parentclass='"+classes.getName()+"' parameterindex='"+parameterCount+"' classname= '"+classes.getName()+"' serviceid='"+serviceid+"' service='"+service+"' method='"+methodName+"' name='"+classes.getSimpleName()+"' type='Parameter'>";
								root = root+""+strQuery;
								root = root + "</node>";
								log.info("root 1 "+root);
							}else{
								root = root +"<node parentclass='"+classes.getName()+"' parameterindex='"+parameterCount+"' classname= '"+classes.getName().toString()+"' serviceid='"+serviceid+"' service='"+service+"' method='"+methodName+"' name='"+classes.getName().toString()+"' type='Parameter'></node>";
							}
						}
						else
						{
							root = root +"<node parentclass='"+classes.getName()+"' parameterindex='"+parameterCount+"' classname= '"+classes.getName().toString()+"' serviceid='"+serviceid+"' service='"+service+"' method='"+methodName+"' name='"+classes.getName().toString()+"' type='Parameter'></node>";
						}
					}
					i ++;
				}
				root = root + "</node>";
			}
		}
		return root;
	}


	public String getReturnTypeXML(String service,String methodName,String serviceid) throws Exception{

		String root = "";

		Class clazz = Class.forName(service);
		Method[] methodArray = clazz.getDeclaredMethods();

		Method method = null;
		for (Method methodTemp : methodArray)
		{
			if(methodName.compareTo(methodTemp.getName().toString()) == 0)
			{
				method = methodTemp;
				break;
			}
		}
		if(method != null)
		{
			Class<?> classes = method.getReturnType();

			if(classes.getName().equalsIgnoreCase(List.class.getName()))
			{
				Type types = method.getGenericReturnType();
				//Now assuming that the first parameter to the method is of type List<Integer>
				if(types instanceof ParameterizedType)
				{
					ParameterizedType pType = (ParameterizedType) types;
					Class<?> clazzc = (Class<?>) pType.getActualTypeArguments()[0];
					root = root+"<node name='List-"+clazzc.getSimpleName()+"'>";
					root = root+getEntityFieldsXML(clazzc.getName(),service,methodName,serviceid);
					root = root + "</node>";

					log.info("root 1 "+root);

				}else{
					root = root + "<node name='"+classes.getSimpleName()+"' serviceid='"+serviceid+"' service='"+service+"' method='"+methodName+"' type='Parameter'>";
					root = root + getEntityXML();
					root = root + "</node>";

					log.info("root 2 "+root);
				}


			}
			else if(classes.getName().equalsIgnoreCase(Set.class.getName()))
			{
				Type[] types = method.getGenericParameterTypes();
				if(types[0] instanceof ParameterizedType)
				{
					ParameterizedType pType = (ParameterizedType) types[0];
					Class<?> clazzc = (Class<?>) pType.getActualTypeArguments()[0];
					root = root+"<node name='Set-"+clazzc.getSimpleName()+"'>";
					root = root+getEntityFieldsXML(clazzc.getName(),service,methodName,serviceid);
					root = root + "</node>";
					log.info("root 3 "+root);
				}else{
					root = root + "<node name='"+classes.getSimpleName()+"' serviceid='"+serviceid+"' service='"+service+"' method='"+methodName+"' type='Parameter'>";
					root = root + getEntityXML();
					root = root + "</node>";
					log.info("root 4 "+root);
				}

			}
			else if(classes.getName() instanceof Object)
			{

				String strQuery = "";

				strQuery = getEntityFieldsXML(classes.getName(),service,methodName,serviceid);

				if(strQuery.trim().length() > 0)
				{
					root = root+"<node name='"+classes.getSimpleName()+"' serviceid='"+serviceid+"' service='"+service+"' method='"+methodName+"' type='Parameter'>";
					root = root+""+strQuery;
					root = root + "</node>";
					log.info("root 5 "+root);
				}else{
					root = root +"<node name='"+classes.getName().toString()+"' serviceid='"+serviceid+"' service='"+service+"' method='"+methodName+"' type='Parameter'></node>";
				}

			}

			/*if(classArray.getName().equalsIgnoreCase("java.util.List"))
			{
				root = getEntityWithFieldsXML();
			}
			else if(classArray.getName().equalsIgnoreCase("java.util.Set"))
			{
				root = getEntityWithFieldsXML();
			}
			else if(classArray.getName() instanceof Object)
			{
				String strQuery = "";

				strQuery = getEntityFieldsXML(classArray.getName());

				if(strQuery.trim().length() > 0)
				{
					root = "<node name='"+classArray.getSimpleName()+"'>";
					root = root+""+strQuery;
					root = root + "</node>";
					log.info("root 1 "+root);
				}
				else
				{
					root = "<node name='Return Type'>";
					root = root + "<node name='"+classArray.getSimpleName()+"' type='ReturnType'/>";
					root = root + "</node>";
					log.info("root 2 " +root);
				}
			}*/
			System.err.println(classes);

		}
		log.info("root Final "+root);
		return root;
	}

	public String getEntityWithFieldsXML() throws Exception{
		setApplicationContext(WebApplicationContextUtils.getWebApplicationContext(getServletContext()));
		SessionFactoryImpl sessionFactoryImpl = (SessionFactoryImpl) getApplicationContext().getBean("sessionFactory");
		Map<?,?> entityMap = new TreeMap<>(sessionFactoryImpl.getAllClassMetadata());
		String root = "";
		if(entityMap != null){
			if(entityMap.size() > 0 ){
				root = "<node name='Entity'>";
				for (Map.Entry<?, ?> entry : entityMap.entrySet()) {
					try {
						Class<?> entityClass = (Class.forName(((String) entry.getKey())));
						root = root +"<node classname='"+entry.getKey() +"' name='"+entityClass.getSimpleName()+"' type='Entity'>";
						root = root +getEntityFieldsXML(entityClass.getName());
						root = root +"</node>";
					} catch (ClassNotFoundException e) {
						// TODO Auto-generated catch block
						throw e;
					}

				}
				root = root + "</node>";
			}
		}
		return root;
	}

	public String getEntityFieldsXML(String classname) throws ClassNotFoundException{
		String root = "";
		if(classname != null){
			if(classname != ""){
				Class<?> entityClass = Class.forName(classname);
				Field[] fields = entityClass.getDeclaredFields();

				for (Field field : fields) {
					Column column = field.getAnnotation(Column.class);
					if (column != null) {
						root = root +"<node parentclass='"+classname+"' classname = '"+classname+"' datatype='"+field.getType()+"' name='"+field.getName()+"' type='Field'></node>";
					}
				}
			}
		}
		return root;
	}

	public String getEntityFieldsXML(String classname,String service,String methodName,String serviceid) throws ClassNotFoundException{
		String root = "";
		if(classname != null){
			if(classname != ""){
				Class<?> entityClass = Class.forName(classname);
				Field[] fields = entityClass.getDeclaredFields();

				for (Field field : fields) {
					Column column = field.getAnnotation(Column.class);
					if (column != null) {
						root = root +"<node parentclass='"+classname+"' serviceid='"+serviceid+"' service='"+service+"' method='"+methodName+"' classname = '"+classname+"' datatype='"+field.getType()+"' name='"+field.getName()+"' type='Field'></node>";
					}
				}
			}
		}
		return root;
	}

	public String getEntityFieldsXMLWithIndex(String classname,String service,String methodName,int parameterCount,String serviceid) throws ClassNotFoundException{
		String root = "";
		if(classname != null){
			if(classname != ""){
				Class<?> entityClass = Class.forName(classname);
				Field[] fields = entityClass.getDeclaredFields();

				for (Field field : fields) {
					Column column = field.getAnnotation(Column.class);
					if (column != null) {
						root = root +"<node parentclass='"+classname+"' parameterindex='"+parameterCount+"' serviceid='"+serviceid+"' service='"+service+"' method='"+methodName+"' classname = '"+classname+"' datatype='"+field.getType()+"' name='"+field.getName()+"' type='Field'></node>";
					}
				}
			}
		}
		return root;
	}

	public String getEntityFieldsXML1(String classname) throws ClassNotFoundException{
		String root = "";
		if(classname != null){
			if(classname != ""){
				Class<?> entityClass = Class.forName(classname);
				Field[] fields = entityClass.getDeclaredFields();

				for (Field field : fields) {
					Column column = field.getAnnotation(Column.class);
					if (column != null) {
						root = root +"<node datatype='"+field.getType()+"' name='"+field.getName()+"' type='Field'/>";
					}
				}
			}
		}
		return root;
	}

	private void invoke(String servicename,String methodname,Class<?>[] parameter,Object[] obj) throws Exception{
		Object _instance = getServiceClass(servicename);
		Method myMethod = _instance.getClass().getDeclaredMethod(methodname, parameter);
		myMethod.invoke(_instance, obj);
	}

	private Object getServiceClass(String servicename) throws Exception  {

		setApplicationContext(WebApplicationContextUtils.getWebApplicationContext(getServletContext()));

		Object objServiceImpl = null;

		String className = "";
		Map<String,RemotingDestinationExporter> map = getApplicationContext().getBeansOfType(RemotingDestinationExporter.class, false, true);

		for(Map.Entry<String,RemotingDestinationExporter> entry : map.entrySet()) {
			Method method = null;

			method = entry.getValue().getClass().getSuperclass().getDeclaredMethod("getDestinationId",null);

			AbstractDestinationFactory objFactory= entry.getValue();
			method.setAccessible(true);
			String serviceId = null;

			serviceId = (String) method.invoke(entry.getValue(),(Object[]) null);

			if(serviceId.trim().toUpperCase().equalsIgnoreCase(servicename.trim().toUpperCase()))
			{
				Object obj = getApplicationContext().getBean(serviceId);
				objServiceImpl = getApplicationContext().getBean(obj.getClass());
				className = obj.getClass().getName();
				break;
			}
		}
		return objServiceImpl;
	}

	public void invokeTemplateMethod(String templateValues) throws Exception{
		DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();

		Document doc = documentBuilder.parse(new InputSource(new StringReader(templateValues))); 

		doc.getDocumentElement().normalize();

		String servicename = doc.getDocumentElement().getAttribute("servicename");
		String methodname = doc.getDocumentElement().getAttribute("methodname");

		NodeList parameterNodeList = doc.getElementsByTagName("parameter");

		log.info("parameterNodeList.getLength()--> "+parameterNodeList.getLength());

		Class<?> params[] = new Class[parameterNodeList.getLength()];
		Object obj[] = new Object[parameterNodeList.getLength()];

		for(int parameterIndex=0; parameterIndex<parameterNodeList.getLength(); parameterIndex++){

			Node parameterNode = parameterNodeList.item(parameterIndex);
			NodeList fieldNodeList = parameterNode.getChildNodes();

			if(parameterNode instanceof Element){
				Element parameterElement = (Element) parameterNode;
				String classname = parameterElement.getAttribute("sclassname");
				if(classname != null && classname.length() > 0)
				{
					Object object = Class.forName(classname).newInstance();

					for(int fieldIndex=0; fieldIndex<fieldNodeList.getLength(); fieldIndex++){
						Node fieldNode = fieldNodeList.item(fieldIndex);

						if(fieldNode instanceof Element){
							Element fieldElement = (Element) fieldNode;
							String value = fieldElement.getAttribute("value");
							String fieldname = fieldElement.getAttribute("sfieldname");

							getPrivateFields(object, fieldname, value);
						}
					}
					obj[parameterIndex] = object;
					params[parameterIndex] = object.getClass();
				}
			}
		}
		invoke(servicename,methodname,params,obj);
	}
}

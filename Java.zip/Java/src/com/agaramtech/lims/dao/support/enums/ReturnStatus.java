package com.agaramtech.lims.dao.support.enums;
/**
* @author Mani
*
*/
public enum ReturnStatus {
	SUCCESS("IDS_SUCCESS"),
	RECORD_ALREADY_EXISTS("IDS_RECORD_ALREADYEXISTS"),
	RECORD_ALREADY_DELETED("IDS_RECORD_ALREADYDELETED"),
	USERDELETED("IDS_USERDELETED"),
	PASSWORDUSED("IDS_PASSWORDUSED");

	private final String status;  

	private ReturnStatus(String status) {
		this.status = status;
	}

	public String getstatus(){  
		return this.status;  
	}
}

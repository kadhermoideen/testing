/**
  Licensed to the Agaram Technologies (AT) under one or more
  contributor license agreements.  See the NOTICE file distributed with
  this work for additional information regarding copyright ownership.
  The AT licenses this file to You under the Agaram Technologies License, Version 1.0
  (the "License"); you may not use this file except in compliance with
  the License.  You may obtain a copy of the License at

      http://www.agaramtech.com

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.

The contents of this file will be loaded for each web application  */
package com.agaramtech.lims.dao.support;

/**
 * @author Manikandan R
 *
 * 23-July-2014 09:51:20 PM
 *
 */

public class AgaramEntityMethods {
	
	private int methodcode;
	private String servicename;
	
	private String methodname;
	private String parametertypes;
	private String returntype;
	
	public int getmethodcode() {
		return methodcode;
	}
	public void setmethodcode(int methodcode) {
		this.methodcode = methodcode;
	}
	
	public String getservicename() {
		return servicename;
	}
	public void setservicename(String servicename) {
		this.servicename = servicename;
	}
	
	public String getmethodname() {
		return methodname;
	}
	public void setmethodname(String methodname) {
		this.methodname = methodname;
	}
	public String getparametertypes() {
		return parametertypes;
	}
	public void setparametertypes(String parametertypes) {
		this.parametertypes = parametertypes;
	}
	public String getreturntype() {
		return returntype;
	}
	public void setreturntype(String returntype) {
		this.returntype = returntype;
	}
	 
	
	
}

/**
 *
 *Kadher
 *
 * 23-Dec-2013
 *
 */
package com.agaramtech.lims.dao.support.enums;

/**
 * @author Kadher
 *
 */
public enum EntityMapper
{  

	MAPROW("mapRow"),
	ISACTIVEFILTER("isActiveFilter"),
	TABLENAME("stablename"),
	SEQUENCENO("nsequenceno");

	private EntityMapper(String mappername) {
		this.mappername = mappername;

	}
	private final String mappername;

	public String getmappername(){  
		return this.mappername;  
	}  
}
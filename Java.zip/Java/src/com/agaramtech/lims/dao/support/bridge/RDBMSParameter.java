package com.agaramtech.lims.dao.support.bridge;

import java.io.Serializable;

@SuppressWarnings("serial")
public class RDBMSParameter implements Serializable {
	
	private String sdatabasetype;

	public String getsdatabasetype() {
		return sdatabasetype;
	}

	public void setsdatabasetype(String sdatabasetype) {
		this.sdatabasetype = sdatabasetype;
	}


}

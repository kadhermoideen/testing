package com.agaramtech.lims.dao.support.enums;

public enum RDBMSEnum {

	DB_MYSQL("com.mysql.jdbc.Driver",1),
	DB_POSTGRESQL("org.postgresql.Driver",2),  
	DB_MICROSOFT_SQL_SERVER("com.microsoft.sqlserver.jdbc.SQLServerDriver",3),
	DB_ORACLE("oracle.jdbc.driver.OracleDriver",4);


	private RDBMSEnum(String dataBaseType, int type) {
		this.dataBaseType = dataBaseType;
		this.type = type;
	}
	private String dataBaseType; 
	private int type;

	public String getDataBaseType() {
		return dataBaseType;
	}
	public int getType() {
		return type;
	}



}


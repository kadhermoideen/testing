/**
 *
 *Kadher
 *
 * 27-Dec-2013
 *
 */
package com.agaramtech.lims.dao.support;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.persistence.Table;

import com.agaramtech.lims.dao.support.enums.EntityMapper;
import com.agaramtech.lims.enums.Tokens;

/**
 * @author Kadher
 *
 */
public class AgaramQueryCreater  {

	private final AgaramResultSetMapper<?> objAbastract = AgaramResultSetMapper.getInstance();

	protected List<Class<?>> classCollection = null;
	protected List<Object> objectCollection = null;
	private String whereCondition = null;

	public List<Object> getObjectCollection() {
		return objectCollection;
	}

	public List<Class<?>> getClassCollection() {
		return classCollection;
	}

	public String getEntityTableName(Class<?> classes){
		Table table = classes.getAnnotation(Table.class);
		return table.name().toLowerCase();
	}

	public String queryFormation(Class<?> ... multipleTables) throws ClassNotFoundException, NoSuchMethodException
	{
		classCollection= Arrays.asList(multipleTables);
		StringBuilder objBuilder = null;
		if(classCollection != null){
			if(classCollection.size() > 0){
				for(int i=0; i<classCollection.size();i++){
					if(objBuilder == null)
						objBuilder = new StringBuilder();
					whereCondition = invokeMethod(classCollection.get(i),objAbastract);
					objBuilder.append("Select * from "+getEntityTableName((classCollection.get(i)))+ " "+ (whereCondition != null ? whereCondition : "") +Tokens.SEMICOLON.gettokens());
				}
			}

		}
		return objBuilder == null?"":objBuilder.toString();
	}

	public String queryFormation(String multipleColumns,Class<?> ... multipleTables) throws ClassNotFoundException, NoSuchMethodException
	{
		StringBuilder objBuilder = null;
		if(multipleColumns != null){
			if(multipleColumns != ""){
				multipleColumns = multipleColumns.trim().endsWith(Tokens.SEMICOLON.gettokens())==true?multipleColumns.trim():multipleColumns.trim()+Tokens.SEMICOLON.gettokens();
				String query[] = multipleColumns.split(Tokens.SEMICOLON.gettokens());
				classCollection= Arrays.asList(multipleTables);
				if(query.length == classCollection.size()){
					if(classCollection != null){
						if(classCollection.size() > 0){
							for(int i=0; i<classCollection.size();i++){
								if(objBuilder == null)
									objBuilder = new StringBuilder();
								whereCondition = invokeMethod(classCollection.get(i),objAbastract);
								objBuilder.append("Select "+query[i]+" from "+getEntityTableName((classCollection.get(i)))+ " "+ (whereCondition != null ? whereCondition : "") +Tokens.SEMICOLON.gettokens());
							}
						}

					}
				}
			}
		}
		return objBuilder == null?"":objBuilder.toString();
	}

	public String queryFormation(String multipleColumns,String multipleWhereCondition,Class<?> ... multipleTables)
	{
		String columns[] = null;
		String condition[] = null;

		if(multipleColumns != null){
			if(multipleColumns == ""){
				multipleColumns = null;
			}else{
				multipleColumns = multipleColumns.trim().endsWith(Tokens.SEMICOLON.gettokens())==true?multipleColumns.trim():multipleColumns.trim()+Tokens.SEMICOLON.gettokens();
				columns = multipleColumns.split(Tokens.SEMICOLON.gettokens());
			}
		}
		if(multipleWhereCondition != null){
			if(multipleWhereCondition == ""){
				multipleWhereCondition = null;
			}else{
				multipleWhereCondition = multipleWhereCondition.trim().endsWith(Tokens.SEMICOLON.gettokens())==true?multipleWhereCondition.trim():multipleWhereCondition.trim()+Tokens.SEMICOLON.gettokens();
				condition = multipleWhereCondition.split(Tokens.SEMICOLON.gettokens());
			}
		}

		StringBuilder objBuilder = null;
		classCollection= Arrays.asList(multipleTables);
		if(columns.length == classCollection.size() && condition.length == classCollection.size()){
			if(classCollection != null){
				if(classCollection.size() > 0){
					for(int i=0; i<classCollection.size();i++){
						if(objBuilder == null)
							objBuilder = new StringBuilder();
						objBuilder.append("Select ");
						objBuilder.append(columns[i]+" from " );
						objBuilder.append(getEntityTableName((classCollection.get(i)))+" ");
						objBuilder.append(condition[i] +Tokens.SEMICOLON.gettokens());
					}
				}

			}
		}
		return objBuilder == null?"":objBuilder.toString();
	}

	public String multiPlainQueryFormation(String multipleplainSqlQuery,Class<?> ... multipleTables)
	{
		StringBuilder objBuilder = null;
		if(multipleplainSqlQuery != null){
			if(multipleplainSqlQuery != ""){
				multipleplainSqlQuery = multipleplainSqlQuery.trim().endsWith(Tokens.SEMICOLON.gettokens())==true?multipleplainSqlQuery.trim():multipleplainSqlQuery.trim()+Tokens.SEMICOLON.gettokens();
				String query[] = multipleplainSqlQuery.split(Tokens.SEMICOLON.gettokens());
				classCollection= Arrays.asList(multipleTables);
				if(query.length == classCollection.size()){
					if(classCollection != null){
						if(classCollection.size() > 0){
							for(int i=0; i<classCollection.size();i++){
								if(objBuilder == null)
									objBuilder = new StringBuilder();
								objBuilder.append(query[i] +Tokens.SEMICOLON.gettokens());
							}
						}

					}
				}
			}
		}
		return objBuilder == null?"":objBuilder.toString();
	}

	public String singlePlainQueryFormation(String singlePlainSqlQuery)
	{
		StringBuilder objBuilder = null;
		if(singlePlainSqlQuery != null){
			if(singlePlainSqlQuery != ""){
				singlePlainSqlQuery = singlePlainSqlQuery.trim().endsWith(Tokens.SEMICOLON.gettokens())==true?singlePlainSqlQuery.trim():singlePlainSqlQuery.trim()+Tokens.SEMICOLON.gettokens();
				String query[] = singlePlainSqlQuery.split(Tokens.SEMICOLON.gettokens());
				if(objBuilder == null)
					objBuilder = new StringBuilder();
				objBuilder.append(query[0] +Tokens.SEMICOLON.gettokens());
			}
		}
		return objBuilder == null?"":objBuilder.toString();
	}

	public String queryFormation(String plainSqlQuery,Class<?> args)
	{
		StringBuilder objBuilder = null;
		if(plainSqlQuery != null){
			if(plainSqlQuery != ""){
				classCollection= new ArrayList<Class<?>>();
				classCollection.add(args);
				if(classCollection != null){
					if(classCollection.size() > 0){
						for(int i=0; i<classCollection.size();i++){
							if(objBuilder == null)
								objBuilder = new StringBuilder();
							objBuilder.append(plainSqlQuery);
						}
					}

				}
			}
		}
		return objBuilder == null?"":objBuilder.toString();
	}

	public String queryFormation(String tableColumns,Class<?> args,String whereCondition)
	{
		if(tableColumns != null){
			if(tableColumns == ""){
				tableColumns = null;
			}
		}
		if(whereCondition != null){
			if(whereCondition == ""){
				whereCondition = null;
			}
		}
		StringBuilder objBuilder = null;
		classCollection= new ArrayList<Class<?>>();
		classCollection.add(args);
		if(classCollection != null){
			if(classCollection.size() > 0){
				for(int i=0; i<classCollection.size();i++){
					if(objBuilder == null)
						objBuilder = new StringBuilder();
					objBuilder.append("Select ");
					objBuilder.append(tableColumns = tableColumns == null ? "* " : tableColumns+" from " );
					objBuilder.append(getEntityTableName((classCollection.get(i)))+" ");
					objBuilder.append(whereCondition = whereCondition == null? "" :whereCondition +Tokens.SEMICOLON.gettokens());
				}
			}

		}
		return objBuilder == null?"":objBuilder.toString();
	}



	//Supporting Functions
	private String invokeMethod(Class<?> args,AgaramResultSetMapper<?> objAbastract) throws ClassNotFoundException, NoSuchMethodException{
		String joinQuery = "";

		Class<?> entityClass;
		Class<?>[] cArgs = new Class[1];
		cArgs[0] = AgaramResultSetMapper.class;

		Method lMethod;
		try {
			entityClass = (Class.forName(args.getName()));
			lMethod = entityClass.getDeclaredMethod(EntityMapper.ISACTIVEFILTER.getmappername(), cArgs);
			joinQuery =(String) lMethod.invoke(entityClass.newInstance(),objAbastract);
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			throw new ClassNotFoundException(e1.getLocalizedMessage() + e1.getMessage() + e1.getCause());
		}
		catch (NoSuchMethodException | SecurityException e) {
			// TODO Auto-generated catch block
			throw new NoSuchMethodException(e.getLocalizedMessage() + e.getMessage() + e.getCause());
		}
		catch (IllegalAccessException | IllegalArgumentException
				| InvocationTargetException | InstantiationException e) {
			// TODO Auto-generated catch block
			throw new IllegalArgumentException(e.getLocalizedMessage() + e.getMessage() + e.getCause());
		}

		return joinQuery;
	}

	public String getQuerys(Object args,String methodName){
		String query = "";
		try{
			Method lMethod  = args.getClass().getDeclaredMethod(methodName);
			query =(String) lMethod.invoke(args);
		}catch(Exception e){
			e.printStackTrace();
		}
		return query;
	}
}

package com.agaramtech.lims.dao.support.bridge;

import java.util.Iterator;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.agaramtech.lims.enums.Tokens;
import com.agaramtech.lims.queries.AgaramQueryLoader;

public class RDBMSBridge {

	public static int dataBaseType = 0;

	final static Log logger = LogFactory.getLog(RDBMSBridge.class);

	private static final int MYSQL = 1;
	private static final int POSTGRESQL = 2;
	private static final int MICROSOFT_SQL_SERVER = 3;
	private static final int ORACLE = 4; 

	//********************************Main function
	//NULL 
	public static String getNull()
	{
		switch(dataBaseType) {
		case MYSQL:
			return "ISNULL";
		case POSTGRESQL:
			return "ISNULL";
		case MICROSOFT_SQL_SERVER:
			return "ISNULL";
		case ORACLE:
			return "NVL";
		default:
			return "ISNULL";
		}
	}

	//CONCATENATION 
	public static String getConcodinate(List<String> lst)
	{
		switch(dataBaseType) {
		case MYSQL:
			return getConCat_MYSQL(lst);
		case POSTGRESQL:
			return getConCat_PosGray(lst);
		case MICROSOFT_SQL_SERVER:
			return getConCat_MsSql(lst);
		case ORACLE:
			return getConCat_Oracle(lst);
		default:
			return "ISNULL";
		}
	}

	//DATETIME-TO-DATE
	public static String getDateTimeToDate(String columname) {
		switch(dataBaseType) {
		case MYSQL:
			return getDateTimeToDate_Mysql(columname);
		case POSTGRESQL:
			return getDateTimeToDate_PosGray(columname);
		case MICROSOFT_SQL_SERVER:
			return getDateTimeToDate_MsSql(columname);
		case ORACLE:
			return getDateTimeToDate_Oracle(columname);
		default:
			return null;
		}
	}

	/*
	 * DATETIME-TO-DATE Field
	 */
	public static String getDateDisplayFieldFormat(String columname) {
		switch(dataBaseType) {
		case MYSQL:
			return null;
		case POSTGRESQL:
			return "TO_DATE("+columname+",  'DD-MM-YYYY')";
		case MICROSOFT_SQL_SERVER:
			return "CONVERT(DATETIME,CONVERT(VARCHAR(10), "+columname+", 120))";
		case ORACLE:
			return getDateTimeToDate_Oracle(columname);
		default:
			return "TO_DATE("+columname+",  'DD-MM-YYYY')";
		}
	}

	//DATETIME-TO-STRING
	public static String getDateTimeDisplayFormat(String columname) {
		switch(dataBaseType) {
		case MYSQL:
			return null;
		case POSTGRESQL:
			return "TO_DATE('"+columname+"',  'DD-MM-YYYY')";
		case MICROSOFT_SQL_SERVER:
			return "CONVERT(VARCHAR(10),CONVERT(DATE, "+columname+"),105)";
		case ORACLE:
			return getDateTimeToDate_Oracle(columname);
		default:
			return "TO_DATE('"+columname+"',  'DD-MM-YYYY')";
		}
	}

	//DATETIME-TO-DATE
	public static String getDateDisplayFormat(String columname) {
		switch(dataBaseType) {
		case MYSQL:
			return null;
		case POSTGRESQL:
			return "TO_DATE('"+columname+"',  'DD-MM-YYYY')";
		case MICROSOFT_SQL_SERVER:
			return "CONVERT(DATETIME,CONVERT(VARCHAR(10), "+columname+", 120))";
		case ORACLE:
			return getDateTimeToDate_Oracle(columname);
		default:
			return "TO_DATE('"+columname+"',  'DD-MM-YYYY')";
		}
	}

	//GivenDate + 1 Year - Magesh
	public static String getDatePlusOneYear(String columname) {
		switch(dataBaseType) {
		case MYSQL:
			return "date_add('"+columname+"',interval 1 year)";
		case POSTGRESQL:
			return "date '"+columname+"' + interval '1 year'";
		case MICROSOFT_SQL_SERVER:
			return "DATEADD(year, 1, "+columname+")";
		case ORACLE:
			return ""+columname+"'+interval'1' year from dual";
		default:
			return "date '"+columname+"' + interval '1 year'";
		}
	}		

	//DECODE STATEMENT FOR ORACLE , CASE WHEN STATEMENT FOR SQLSERVER
	public static String getCaseWhen_Decode()
	{
		switch(dataBaseType) {
		case MYSQL:
			return "CASE WHEN (";
		case POSTGRESQL:
			return "CASE WHEN (";
		case MICROSOFT_SQL_SERVER:
			return "CASE WHEN (";
		case ORACLE:
			return "DECODE(";
		default:
			return null;

		}
	}

	//FLEX DATE DISPLAY FORMAT
	public static String getFlexDateDisplayFormat(String columname) {
		switch(dataBaseType) {
		case MYSQL:
			return null;
		case POSTGRESQL:
			return "TO_DATE('"+columname+"',  'DD-MM-YYYY')";
		case MICROSOFT_SQL_SERVER:
			return "CONVERT(VARCHAR(10), "+columname+", 105)";
		case ORACLE:
			return getDateTimeToDate_Oracle(columname);
		default:
			return "TO_DATE('"+columname+"',  'DD-MM-YYYY')";
		}
	}

	//FLEX DATE DISPLAY FORMAT
	public static String getFlexDateTimeDisplayFormat(String columname) {
		switch(dataBaseType) {
		case MYSQL:
			return null;
		case POSTGRESQL:
			return "TO_DATE('"+columname+"',  'DD-MM-YYYY')";
		case MICROSOFT_SQL_SERVER:
			return "convert(varchar(20),"+columname+",105)+' '+ convert(varchar(20),"+columname+",108)"; 
		case ORACLE:
			return getDateTimeToDate_Oracle(columname);
		default:
			return "TO_DATE('"+columname+"',  'DD-MM-YYYY')";
		}
	}

	//********************************Sub function

	//CONCATENATION FOR MYSQL
	private static String getConCat_MYSQL(List<String> lst) {
		String query = "CONCAT(";
		Iterator<String> iterator =lst.iterator();
		while(iterator.hasNext()) {
			query = query+iterator.next()+",";
		}
		query = query.substring(0, query.length()-1) + ")";
		return query;
	}
	//CONCATENATION FOR POSGRAY
	private static String getConCat_PosGray(List<String> lst) {
		String query = "";
		Iterator<String> iterator =lst.iterator();
		while(iterator.hasNext()) {
			query = query+iterator.next() + "||";
		}
		query = query.substring(0, query.length()-2);
		return query;
	}
	//CONCATENATION FOR MSSQL
	private static String getConCat_MsSql(List<String> lst) {
		String query = "";
		Iterator<String> iterator =lst.iterator();
		while(iterator.hasNext()) {
			query = query+iterator.next() + "+";
		}
		query = query.substring(0, query.length()-1);
		return query;
	}
	//CONCATENATION FOR ORACLE
	private static String getConCat_Oracle(List<String> lst) {
		String query = "";
		Iterator<String> iterator =lst.iterator();
		while(iterator.hasNext()) {
			query = query+iterator.next() + "||";
		}
		query = query.substring(0, query.length()-2);
		return query;
	}


	//STRING-TO-DATE
	public static String getStringToDate(String parameter) {
		switch(dataBaseType) {
		case MYSQL:
			return getStringToDate_Mysql(parameter);
		case POSTGRESQL:
			return getStringToDate_PosGray(parameter);
		case MICROSOFT_SQL_SERVER:
			return getStringToDate_MsSql(parameter);
		case ORACLE:
			return getStringToDate_Oracle(parameter);
		default:
			return null;
		}
	}
	//DATETIME-TO-DATE CONVERSION MYSQL
	private static String getDateTimeToDate_Mysql(String columname) {
		return null;
	}
	//STRING-TO-DATE CONVERSION MYSQL
	private static String getStringToDate_Mysql(String parameter) {
		return null;
	}
	//DATETIME-TO-DATE CONVERSION ORACLE
	private static String getDateTimeToDate_Oracle(String columname) {
		return null;
	}
	//STRING-TO-DATE CONVERSION ORACLE
	private static String getStringToDate_Oracle(String parameter) {
		return null;
	}
	//DATETIME-TO-DATE CONVERSION POSGRAY
	private static String getDateTimeToDate_PosGray(String columname) {
		return "DATE("+columname+")";
	}
	//STRING-TO-DATE CONVERSION POSGRAY
	private static String getStringToDate_PosGray(String parameter) {
		return "TO_DATE('"+parameter+"',  'YYYY-MM-DD')";
	}
	//DATETIME-TO-DATE CONVERSION MSSQL
	private static String getDateTimeToDate_MsSql(String columname) {
		return "CONVERT(DATETIME,CONVERT(VARCHAR(10), "+columname+", 120))";
	}
	//STRING-TO-DATE CONVERSION MSSQL
	private static String getStringToDate_MsSql(String parameter) {
		return "CONVERT(DATETIME,CONVERT(VARCHAR(10), '"+parameter+"', 120))";
	}


	//CASEEQUAL 
	public static String getCaseEqual()
	{
		switch(dataBaseType) {
		case MYSQL:
			return "=";
		case POSTGRESQL:
			return "=";
		case MICROSOFT_SQL_SERVER:
			return "=";
		case ORACLE:
			return ",";
		default:
			return null;
		}
	}

	//THEN
	public static String getThen()
	{
		switch(dataBaseType) {
		case MYSQL:
			return ") then";
		case POSTGRESQL:
			return ") then";
		case MICROSOFT_SQL_SERVER:
			return ") then";
		case ORACLE:
			return ",";
		default:
			return null;

		}
	}

	//ELSE
	public static String getElse()
	{
		switch(dataBaseType) {
		case MYSQL:
			return "else";
		case POSTGRESQL:
			return "else";
		case MICROSOFT_SQL_SERVER:
			return "else";
		case ORACLE:
			return ",";
		default:
			return null;
		}
	}

	//END
	public static String getEnd()
	{
		switch(dataBaseType) {
		case MYSQL:
			return ")";
		case POSTGRESQL:
			return "end";
		case MICROSOFT_SQL_SERVER:
			return "end";
		case ORACLE:
			return ")";
		default:
			return null;
		}
	}

	public static String getSystemDate() {
		switch(dataBaseType) {
		case MYSQL:
			return "sysdate()";
		case POSTGRESQL:
			return "now()";
		case MICROSOFT_SQL_SERVER:
			return "getdate()";
		case ORACLE:
			return "sysdate()";
		default:
			return null;
		}
	}

	public static String getTableColumn() throws Exception{
		switch(dataBaseType) {
		case MYSQL:
			return null;
		case POSTGRESQL:
			return AgaramQueryLoader.getQuery(Tokens.TABLES_PSQL.gettokens());
		case MICROSOFT_SQL_SERVER:
			return AgaramQueryLoader.getQuery(Tokens.TABLES_MSSQL.gettokens());
		case ORACLE:
			return null;
		default:
			return null;
		}
	}
	public static String getLowerCase()
	{
		switch(dataBaseType) {
		case MYSQL:
			return "lower";
		case POSTGRESQL:
			return "lower";
		case MICROSOFT_SQL_SERVER:
			return "lower";
		case ORACLE:
			return "-";
		default:
			return null;

		}
	}
	public static String getIntegerToString(String columname)
	{
		switch(dataBaseType)
		{
		case MYSQL:
			return null;
		case POSTGRESQL:
			return "cast("+columname+" as character varying)";
		case MICROSOFT_SQL_SERVER:
			return "cast("+columname+" as varchar)";
		case ORACLE:
			return "cast("+columname+" as varchar2)";
		default:
			return "cast("+columname+" as varchar)";
		}
	}
	public static String getROUND(String columname)
	{
		switch(dataBaseType) {
		case MYSQL:
			return "ROUND";
		case POSTGRESQL:
			return "ROUND(cast("+columname+" as numeric),2)";   
		case MICROSOFT_SQL_SERVER:
			return "ROUND";
		case ORACLE:
			return "ROUND";
		default:
			return null;

		}
	}
	public static String getNull(String columname)
	{
		switch(dataBaseType) {
		case MYSQL:
			return "ISNULL("+columname+",0)";
		case POSTGRESQL:
			return "ISNULL";
		case MICROSOFT_SQL_SERVER:
			return "ISNULL("+columname+",0)";
		case ORACLE:
			return "NVL";
		default:
			return "ISNULL";
		}
	}

	public static String getxml(String query){
		switch(dataBaseType) {
		case MYSQL:
			return null;
		case POSTGRESQL:
			return "SELECT query_to_xml('"+query+"', true, false, '')";
		case MICROSOFT_SQL_SERVER:
			return ""+query+" FOR XML AUTO";
		case ORACLE:
			return null;
		default:
			return null;
		}
	}

}

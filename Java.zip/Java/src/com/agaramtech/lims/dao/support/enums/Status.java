/**
 *
 *Kadher
 *
 * 23-Dec-2013
 *
 */
package com.agaramtech.lims.dao.support.enums;

/**
 * @author Kadher
 *
 */
public enum Status
{  
	ACTIVE(1,"A"),
	DEACTIVE(0,"D");

	private Status(int status,String sstatus) {
		this.status = status;
		this.sstatus = sstatus;

	}
	private final int status;  
	private final String sstatus;


	public int getstatus(){  
		return this.status;  
	}  
	public String getsstatus(){  
		return this.sstatus;  
	}  
}
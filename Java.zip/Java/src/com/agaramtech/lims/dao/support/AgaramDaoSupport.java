/**
  Licensed to the Agaram Technologies (AT) under one or more
  contributor license agreements.  See the NOTICE file distributed with
  this work for additional information regarding copyright ownership.
  The AT licenses this file to You under the Agaram Technologies License, Version 1.0
  (the "License"); you may not use this file except in compliance with
  the License.  You may obtain a copy of the License at

      http://www.agaramtech.com

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.

The contents of this file will be loaded for each web application  */
package com.agaramtech.lims.dao.support;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ParameterMetaData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import javax.sql.DataSource;

import org.apache.commons.beanutils.BeanMap;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.LockMode;
import org.hibernate.metadata.ClassMetadata;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.CallableStatementCallback;
import org.springframework.jdbc.core.CallableStatementCreator;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.transaction.annotation.Transactional;

import com.agaramtech.lims.base.RunningMaker;
import com.agaramtech.lims.dao.support.bridge.RDBMSBridge;
import com.agaramtech.lims.dao.support.bridge.RDBMSParameter;
import com.agaramtech.lims.dao.support.enums.EntityMapper;
import com.agaramtech.lims.dao.support.enums.RDBMSEnum;
import com.agaramtech.lims.dao.support.global.AgaramtechGeneralfunction;
import com.agaramtech.lims.enums.EntityMethods;
import com.agaramtech.lims.enums.Tokens;
import com.agaramtech.lims.grid.GridColumnDesigner;
import com.agaramtech.lims.grid.GridColumnSqlQueryBuilder;
import com.agaramtech.lims.grid.GridSqlQueryMapping;
import com.agaramtech.lims.grid.GridSqlQueryMappingParam;
import com.agaramtech.lims.queries.AgaramQueryLoader;
import com.agaramtech.lims.support.AgaramQueryCreaterSupport;
import com.agaramtech.lims.support.AgaramResultSetConvertor;
import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Multimap;

/**
 * @author Kadher Moideen S
 *
 * 11-Dec-2013 1:26:20 PM
 *
 */
@SuppressWarnings("all")
@Transactional
public abstract class AgaramDaoSupport extends HibernateDaoSupport{


	private DataSource dataSource;
	private JdbcTemplate jdbcTemplate;
	private int formcode;
	private String tablename;
	private final AgaramResultSetMapper<?> objAbastract = AgaramResultSetMapper.getInstance();
	private final AgaramQueryCreaterSupport objQueryCreater = AgaramQueryCreaterSupport.getInstance();
	private final AgaramResultSetConvertor objResultSetConvertor = AgaramResultSetConvertor.getInstance();
	private Multimap<String, List<Object>> objMultimap = ArrayListMultimap.create();
	private int i = 0;
	private String query;

	private List listOfObject;
	private List<String> queryList = null;
	private Class<?> sequenceClass;
	private String fields;
	private BeanMap beanMap;
	private int seqRecord = 0;



	private final AgaramtechGeneralfunction objGeneral;
	private static int dataBaseType = 0;
	final Log logging = LogFactory.getLog(AgaramDaoSupport.class);
	public AgaramDaoSupport(RDBMSParameter objParameter,AgaramtechGeneralfunction objGeneral) {
		if(objParameter.getsdatabasetype().equals(RDBMSEnum.DB_MYSQL.getDataBaseType())) {
			dataBaseType = RDBMSEnum.DB_MYSQL.getType();
		} else if(objParameter.getsdatabasetype().equals(RDBMSEnum.DB_POSTGRESQL.getDataBaseType())) {
			dataBaseType = RDBMSEnum.DB_POSTGRESQL.getType();
		} else if(objParameter.getsdatabasetype().equals(RDBMSEnum.DB_MICROSOFT_SQL_SERVER.getDataBaseType())) {
			dataBaseType = RDBMSEnum.DB_MICROSOFT_SQL_SERVER.getType();
		} else if(objParameter.getsdatabasetype().equals(RDBMSEnum.DB_ORACLE.getDataBaseType())) {
			dataBaseType = RDBMSEnum.DB_ORACLE.getType();
		}
		logging.info("in constructor");
		this.objGeneral = objGeneral;
		this.objGeneral.setAgaramDaoSupport(this);
		RDBMSBridge.dataBaseType = dataBaseType;
	}

	public int getformcode() {
		return formcode;
	}

	public void setformcode(int formcode) {
		this.formcode = formcode;
	}
	public String getTablename() {
		return tablename;
	}

	public void setTablename(String tablename) {
		this.tablename = tablename;
	}

	public Multimap<String, List<Object>> getObjMultimap() {
		return objMultimap;
	}

	public void setObjMultimap(Multimap<String, List<Object>> objMultimap) {
		this.objMultimap = objMultimap;
	}
	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}
	public String getQuery() {
		return query;
	}

	public void setQuery(String query) {
		this.query = query;
	}

	public List getlistofobject() {
		return listOfObject;
	}

	public void setlistofobject(List listOfObject) {
		this.listOfObject = listOfObject;
	}
	public String getfields() {
		return fields;
	}

	public void setfields(String fields) {
		this.fields = fields;
	}

	public BeanMap getbeanmap() {
		return beanMap;
	}

	public void setbeanmap(BeanMap beanMap) {
		this.beanMap = beanMap;
	}
	public int getseqrecord() {
		return seqRecord;
	}

	public void setseqrecord(int seqRecord) {
		this.seqRecord = seqRecord;
	}
	//	private List<?> gridList = null;

	//Multiple Tables
	public Map<String,List<?>> findByMultiTables(Class<?> ... multipleTables)throws Exception{
		return executePlainProcedure(objQueryCreater.queryFormation(multipleTables),objQueryCreater.getClassCollection());
	}

	//Multiple Tables and Multiple Fields
	public Map<String,List<?>> findByMultiTablesField(String multipleColumns,Class<?> ... multipleTables)throws Exception{
		return executePlainProcedure(objQueryCreater.queryFormation(multipleColumns,multipleTables),objQueryCreater.getClassCollection());
	}

	//Multiple Tables and Multiple Fields and Multiple Where Condition
	public Map<String,List<?>> findByMultiTablesConditionalField(String multipleColumns,String multipleWhereCondition,Class<?> ... multipleTables)throws Exception{
		return executePlainProcedure(objQueryCreater.queryFormation(multipleColumns,multipleWhereCondition,multipleTables),objQueryCreater.getClassCollection());
	}

	//Multiple Tables and Multiple Plain Query 
	public Map<String,List<?>> findByMultiTablesPlainSql(String multiplePlainSqlQuery,Class<?> ... multipleTables)throws Exception{
		return executePlainProcedure(objQueryCreater.multiPlainQueryFormation(multiplePlainSqlQuery,multipleTables),objQueryCreater.getClassCollection());
	}

	//Single Tables and Single Plain Query
	public List<?> findBySinglePlainSql(String singlePlainQuery,Class<?> singleTable)throws Exception{
		return executeProcedureSinglePlainSql(objQueryCreater.queryFormation(singlePlainQuery,singleTable),objQueryCreater.getClassCollection());
	}

	//Single Tables and Multiple Fields and Multiple Where Condition
	public List<?> findBySingleConditionalField(String tableColumns,Class<?> args,String whereCondition)throws Exception{
		return executeProcedureSinglePlainSql(objQueryCreater.queryFormation(tableColumns,args,whereCondition),objQueryCreater.getClassCollection());
	}

	//Single Tables and Multiple Fields and Multiple Where Condition
	public Object findBySingleObjectConditionalField(String tableColumns,Class<?> args,String whereCondition)throws Exception{
		List<?> lst = executeProcedureSinglePlainSql(objQueryCreater.queryFormation(tableColumns,args,whereCondition),objQueryCreater.getClassCollection());
		return (lst.size() > 0) ? lst.get(0) : null;
	}

	//Single Tables and Single Plain Query
	public Object findBySingleObjectPlainSql(String singlePlainQuery,Class<?> singleTable)throws Exception{
		List<?> lst = executeProcedureSinglePlainSql(objQueryCreater.queryFormation(singlePlainQuery,singleTable),objQueryCreater.getClassCollection());
		return (lst.size() > 0) ? lst.get(0) : null;
	}
	
	//Multiple User Transaction Queue Formation
	public void begin(){
		Object object = null;
		String strEntityTableName = objQueryCreater.getEntityTableName(RunningMaker.class);
		try {
			List<?> lstSequence = findBySinglePlainSql("select * from "+strEntityTableName +" where "+getIdField(RunningMaker.class)+" = '"+strEntityTableName+"' ",RunningMaker.class);
			if(lstSequence != null && lstSequence.size() > 0) {
				object = lstSequence.get(0);
				getHibernateTemplate().update("sequencenumber", object, LockMode.PESSIMISTIC_READ);
//				getJdbcTemplate().execute("update "+strEntityTableName+" set sequencenumber = sequencenumber  where "+getIdField(RunningMaker.class)+" = '"+strEntityTableName+"'");
			}else{
				object = returnRunningRecord(RunningMaker.class,RunningMaker.class.getSimpleName(),"sequencenumber");
				getHibernateTemplate().update(RunningMaker.class.getSimpleName(), object, LockMode.PESSIMISTIC_READ);
//				getHibernateTemplate().update(entityName, entity, lockMode);
//				getJdbcTemplate().execute("update "+strEntityTableName+" set sequencenumber = sequencenumber  where "+getIdField(RunningMaker.class)+" = '"+strEntityTableName+"'");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	//Form Code Plain Sql
	public Multimap<String, List<Object>> findByFormCodePlainSql(int formcode)throws Exception{
		setformcode(formcode);
		executeFormProcedure(objQueryCreater.multiPlainQueryFormation(getMapCollection()),objQueryCreater.getObjectCollection());
		return getObjMultimap();
	}

	public Object insertObject(Object object,Class<?> sequenceClass,String seqColumn) throws Exception{
		String strEntityTableName = objQueryCreater.getEntityTableName(sequenceClass);
		setTablename(objQueryCreater.getEntityTableName(object.getClass()));
		List<?> lstSequence = findBySinglePlainSql("select "+seqColumn+" from "+strEntityTableName +" where "+getIdField(sequenceClass)+" = '"+getTablename()+"' ",sequenceClass);
		int seqRecord = 0;
		if(lstSequence != null && lstSequence.size() > 0) {
			getJdbcTemplate().execute("update "+strEntityTableName+" set "+seqColumn+" = "+seqColumn +" where "+getIdField(sequenceClass)+" = '"+getTablename()+"'");
			lstSequence = findBySinglePlainSql("select "+seqColumn+" from "+strEntityTableName +" where "+getIdField(sequenceClass)+" = '"+getTablename()+"'",sequenceClass);
			if(lstSequence.size() > 0) {
				seqRecord = (int) objGeneral.findColumnName(lstSequence.get(0),seqColumn);
				seqRecord =seqRecord+1;
			}
		} else {
			seqRecord = insertRunningRecord(sequenceClass,object.getClass().getSimpleName(),seqColumn);
		}
		setTablename(objQueryCreater.getEntityTableName(object.getClass()));
		assignField(object,seqRecord);
		setQuery(objQueryCreater.singlePlainQueryFormation(RDBMSBridge.getTableColumn())); 
		queryList = executeProcedure(getQuery(),getTablename());	
		setbeanmap(new BeanMap(object));
		setlistofobject(getObject(object));
		if(queryList != null){
			if(queryList.size() >0){
				batchInsert(queryList.get(0),getlistofobject());
			}
		}
		getJdbcTemplate().execute("update "+strEntityTableName+" set "+seqColumn+" = "+seqRecord +" where "+getIdField(sequenceClass)+" = '"+getTablename()+"'");
		return object;
	}

	public void insertObject(Object object) throws Exception{
		setTablename(objQueryCreater.getEntityTableName(object.getClass()));
		setQuery(objQueryCreater.singlePlainQueryFormation(RDBMSBridge.getTableColumn()));
		queryList = executeProcedure(getQuery(),getTablename());	
		setbeanmap(new BeanMap(object));
		setlistofobject(getObject(object));
		if(queryList != null){
			if(queryList.size() >0){
				batchInsert(queryList.get(0),getlistofobject());
			}
		}
	}

	public synchronized void insertQuery(String query) throws Exception{
		getJdbcTemplate().execute(query);
	}

	public void insertBatch(List<?> lstobject) throws Exception{
		if(lstobject != null){
			if(lstobject.size() > 0){
				setQuery(objQueryCreater.singlePlainQueryFormation(RDBMSBridge.getTableColumn()));
				setTablename(objQueryCreater.getEntityTableName(lstobject.get(0).getClass()));
				queryList = executeProcedure(getQuery(),getTablename());
				if(queryList != null){
					if(queryList.size() >0){
						batchInsert(queryList.get(0),lstobject,false);
					}
				}
			}
		}
	}

	public List<?> insertBatch(List<?> lstobject,Class<?> sequenceClass,String seqColumn) throws Exception{
		if(lstobject != null){
			if(lstobject.size() > 0){
				String strEntityTableName = objQueryCreater.getEntityTableName(sequenceClass);
				setTablename(objQueryCreater.getEntityTableName(lstobject.get(0).getClass()));
				List<?> lstSequence = findBySinglePlainSql("select "+seqColumn+" from "+strEntityTableName +" where "+getIdField(sequenceClass)+" = '"+getTablename()+"' ",sequenceClass);


				if(lstSequence != null && lstSequence.size() > 0) {
					getJdbcTemplate().execute("update "+strEntityTableName+" set "+seqColumn+" = "+seqColumn +" where "+getIdField(sequenceClass)+" = '"+getTablename()+"'");
					lstSequence = findBySinglePlainSql("select "+seqColumn+" from "+strEntityTableName +" where "+getIdField(sequenceClass)+" = '"+getTablename()+"'",sequenceClass);
					if(lstSequence.size() > 0) {
						setseqrecord((int) objGeneral.findColumnName(lstSequence.get(0),seqColumn));
					}
				} else {
					setseqrecord(insertRunningRecordBatch(sequenceClass,lstobject.get(0).getClass().getSimpleName(),seqColumn));
				}
				setQuery(objQueryCreater.singlePlainQueryFormation(RDBMSBridge.getTableColumn()));
				setTablename(objQueryCreater.getEntityTableName(lstobject.get(0).getClass()));
				queryList = executeProcedure(getQuery(),getTablename());
				if(queryList != null){
					if(queryList.size() >0){
						batchInsert(queryList.get(0),lstobject,true);
					}
				}
				getJdbcTemplate().execute("update "+strEntityTableName+" set "+seqColumn+" = "+seqRecord +" where "+getIdField(sequenceClass)+" = '"+getTablename()+"'");
			}
		}
		return getlistofobject();
	}

	private int insertRunningRecord(Class<?> sequenceClass,String tablename,String seqColumn) throws Exception{
		setTablename(objQueryCreater.getEntityTableName(sequenceClass));
		setQuery(objQueryCreater.singlePlainQueryFormation(RDBMSBridge.getTableColumn()));
		queryList = executeProcedure(getQuery(),getTablename());
		Object object = sequenceClass.newInstance();
		assignField(object,tablename);
		objGeneral.getPrivateFields(object,seqColumn,"1");
		setbeanmap(new BeanMap(object));
		setlistofobject(getObject(object));
		if(queryList != null){
			if(queryList.size() >0){
				batchInsert(queryList.get(0),getlistofobject());
			}

		}
		return 1;
	}
	
	private Object returnRunningRecord(Class<?> sequenceClass,String tablename,String seqColumn) throws Exception{
		setTablename(objQueryCreater.getEntityTableName(sequenceClass));
		setQuery(objQueryCreater.singlePlainQueryFormation(RDBMSBridge.getTableColumn()));
		queryList = executeProcedure(getQuery(),getTablename());
		Object object = sequenceClass.newInstance();
		assignField(object,tablename);
		objGeneral.getPrivateFields(object,seqColumn,"1");
		setbeanmap(new BeanMap(object));
		setlistofobject(getObject(object));
		if(queryList != null){
			if(queryList.size() >0){
				batchInsert(queryList.get(0),getlistofobject());
			}

		}
		return object;
	}

	private int insertRunningRecordBatch(Class<?> sequenceClass,String tablename,String seqColumn) throws Exception{
		setTablename(objQueryCreater.getEntityTableName(sequenceClass));
		setQuery(objQueryCreater.singlePlainQueryFormation(RDBMSBridge.getTableColumn()));
		queryList = executeProcedure(getQuery(),getTablename());
		Object object = sequenceClass.newInstance();
		assignField(object,tablename);
		objGeneral.getPrivateFields(object,seqColumn,"0");
		setbeanmap(new BeanMap(object));
		setlistofobject(getObject(object));
		if(queryList != null){
			if(queryList.size() >0){
				batchInsert(queryList.get(0),getlistofobject());
			}

		}
		return 0;
	}

	private List<Object> getObject(Object object){
		List<Object> lst= null;
		lst = new ArrayList<Object>();
		lst.add(object);
		return lst;
	}

	private synchronized void batchInsert(final String query,final List<?> lst,final boolean redirectFlag) throws Exception,ParseException{
		listOfObject = new ArrayList<>();
		getJdbcTemplate().batchUpdate(query, new BatchPreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement statement, int i) throws SQLException {
				Object object = lst.get(i);

				try {
					if(redirectFlag == true){
						setseqrecord((getseqrecord() + 1));
						assignField(object,getseqrecord());
						listOfObject.add(object);
					}
					setbeanmap(new BeanMap(object));
					setParameters(statement,getbeanmap());
				}catch(Exception e){
					throw new SQLException();
				}
			}
			@Override
			public int getBatchSize() {
				return lst.size();
			}
		});
	}

	private synchronized void batchInsert(final String query,final List<Object> lst) {
		getJdbcTemplate().batchUpdate(query, new BatchPreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement statement, int i) throws SQLException {

				try {
					setParameters(statement,getbeanmap());
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();


				}

			}
			@Override
			public int getBatchSize() {
				return lst.size();
			}
		});
	}


	/** Multiple Tables and Multiple Plain Query Start 
	 * @throws Exception **/

	private Map<String, List<?>> getMapCollection() throws Exception{
		return findByMultiTablesPlainSql(AgaramQueryLoader.getQuery(Tokens.QUERY_GRID_SQL_QUERY_MAPPING.gettokens())+
				AgaramQueryLoader.getQuery(Tokens.QUERY_GRID_SQL_QUERY_MAPPING_PARAM.gettokens())+
				AgaramQueryLoader.getQuery(Tokens.QUERY_GRID_COLUMN_SQL_QUERY_BUILDER.gettokens()),
				GridSqlQueryMapping.class,GridSqlQueryMappingParam.class,GridColumnSqlQueryBuilder.class);
	}


	/**	Multiple Tables and Multiple Plain Query End **/

	private synchronized Map<String,List<?>> executeFormProcedure(final String sql,final List<Object> lst) throws Exception
	{

		return getJdbcTemplate().execute(new CallableStatementCreator() {
			@Override
			public CallableStatement createCallableStatement(Connection connection) throws SQLException
			{
				return connection.prepareCall(sql);
			}
		}, new CallableStatementCallback<Map<String,List<?>>>() {
			@Override
			public Map<String,List<?>> doInCallableStatement(CallableStatement callableStatement) throws SQLException
			{
				//				Map<String, List<?>> rowMap = new TreeMap<String, List<?>>();
				Multimap<String, List<Object>> rowMultiMap=ArrayListMultimap.create();


				Class<?>[] cArgs = new Class[1];
				cArgs[0] = AgaramResultSetMapper.class;

				boolean resultsAvailable = callableStatement.execute();
				boolean checkEntity = false;
				String key = null;

				int j = 0;
				while (resultsAvailable)
				{
					ResultSet collectResult =callableStatement.getResultSet();
					Class<?> entityClass = null;
					Method lMethod = null;
					try {
						entityClass = (Class.forName(((Class<?>) lst.get(j).getClass()).getName()));
					} catch (ClassNotFoundException e) {
						throw new IllegalArgumentException("Class Not Found");
					}

					checkEntity = objQueryCreater.invokeEqualsMethod(entityClass);
					List<Object> listOfEntity = new ArrayList<Object>();

					if(checkEntity){
						objResultSetConvertor.resultSetToArrayList(collectResult,listOfEntity);
					}else {
						entityClass = GridColumnDesigner.class;
						try {
							lMethod = entityClass.getDeclaredMethod(EntityMapper.MAPROW.getmappername(), cArgs);
						} catch (NoSuchMethodException e) {
							throw new IllegalArgumentException(e);
						} catch (SecurityException e) {
							throw new IllegalArgumentException(e);
						}
						objAbastract.init(collectResult);
						while (objAbastract.resultSet.next()) {
							try {
								listOfEntity.add(lMethod.invoke(entityClass.newInstance(),objAbastract));
							} catch (IllegalAccessException e) {
								throw new IllegalArgumentException(e.getLocalizedMessage());
							} catch (IllegalArgumentException e) {
								throw new IllegalArgumentException(e.getLocalizedMessage());
							} catch (InvocationTargetException e) {
								throw new IllegalArgumentException(e.getLocalizedMessage());
							} catch (InstantiationException e) {
								throw new IllegalArgumentException(e.getLocalizedMessage());
							}
						}
					}					
					if(checkEntity){
						key = objQueryCreater.invokeMethod(lst.get(j),EntityMethods.GETDATAGRIDID.getmethodname());
						rowMultiMap.put(key, listOfEntity);

					}
					else{
						rowMultiMap.put(key, listOfEntity);
					}
					resultsAvailable = callableStatement.getMoreResults();
					objAbastract.availableColumns = null;
					j++;
				}

				if(rowMultiMap.size() > 0){
					setObjMultimap(rowMultiMap);
				}
				return null;
			}
		});
	}


	//	private Map<String,List<?>> executeProcedure(final String sql,final List<?> lst) throws Exception
	//	{
	//
	//		return getJdbcTemplate().execute(new CallableStatementCreator() {
	//			@Override
	//			public CallableStatement createCallableStatement(Connection connection) throws SQLException
	//			{
	//				return connection.prepareCall(sql);
	//			}
	//		}, new CallableStatementCallback<Map<String,List<?>>>() {
	//			@Override
	//			public Map<String,List<?>> doInCallableStatement(CallableStatement callableStatement) throws SQLException
	//			{
	//				Map<String, List<?>> rowMap = new TreeMap<String, List<?>>();
	//				try{
	//
	//					Class<?>[] cArgs = new Class[1];
	//					cArgs[0] = AgaramResultSetMapper.class;
	//
	//
	//					boolean resultsAvailable = callableStatement.execute();
	//
	//					int j = 0;
	//					while (resultsAvailable)
	//					{
	//						ResultSet collectResult =callableStatement.getResultSet();
	//						Class<?> entityClass = null;
	//						Method lMethod = null;
	//						entityClass = (Class.forName(((Class<?>) lst.get(j)).getName()));
	//
	//						List<Object> listOfEntity = new ArrayList<Object>();
	//
	//
	//						lMethod = entityClass.getDeclaredMethod(EntityMapper.MAPROW.getmappername(), cArgs);
	//						objAbastract.init(collectResult);
	//						while (objAbastract.resultSet.next()) {
	//							listOfEntity.add(lMethod.invoke(entityClass.newInstance(),objAbastract));
	//						}
	//
	//						rowMap.put(entityClass.getSimpleName(), listOfEntity);
	//						resultsAvailable = callableStatement.getMoreResults();
	//						objAbastract.availableColumns = null;
	//						j++;
	//					}
	//				}catch(Exception e){
	//					throw new SQLException(e.getLocalizedMessage());
	//				}
	//
	//				return rowMap;
	//			}
	//		});
	//	}

	private synchronized Map<String,List<?>> executePlainProcedure(final String sql,final List<?> lst) throws Exception
	{

		return getJdbcTemplate().execute(new CallableStatementCreator() {
			@Override
			public CallableStatement createCallableStatement(Connection connection) throws SQLException
			{
				return connection.prepareCall(sql);
			}
		}, new CallableStatementCallback<Map<String,List<?>>>() {
			@Override
			public Map<String,List<?>> doInCallableStatement(CallableStatement callableStatement) throws SQLException
			{
				Map<String, List<?>> rowMap = new TreeMap<String, List<?>>();
				try{

					Class<?>[] cArgs = new Class[1];
					cArgs[0] = AgaramResultSetMapper.class;

					boolean resultsAvailable = callableStatement.execute();

					int j = 0;
					while (resultsAvailable)
					{
						ResultSet collectResult =callableStatement.getResultSet();
						Class<?> entityClass = null;
						Method lMethod = null;
						entityClass = (Class.forName(((Class<?>) lst.get(j)).getName()));

						List<Object> listOfEntity = new ArrayList<Object>();


						lMethod = entityClass.getDeclaredMethod(EntityMapper.MAPROW.getmappername(), cArgs);
						objAbastract.init(collectResult);
						while (objAbastract.resultSet.next()) {
							listOfEntity.add(lMethod.invoke(entityClass.newInstance(),objAbastract));
						}

						rowMap.put(entityClass.getSimpleName(), listOfEntity);
						resultsAvailable = callableStatement.getMoreResults();
						objAbastract.availableColumns = null;
						j++;
					}
				}catch(Exception e){
					throw new SQLException(e.getLocalizedMessage());
				}

				return rowMap;
			}
		});
	}

	private synchronized Map<String,List<?>> executeProcedure(final String sql,final List<?> lst) throws Exception
	{

		return getJdbcTemplate().execute(new CallableStatementCreator() {
			@Override
			public CallableStatement createCallableStatement(Connection connection) throws SQLException
			{
				return connection.prepareCall(sql);
			}
		}, new CallableStatementCallback<Map<String,List<?>>>() {
			@Override
			public Map<String,List<?>> doInCallableStatement(CallableStatement callableStatement) throws SQLException
			{
				Map<String, List<?>> rowMap = new TreeMap<String, List<?>>();
				try{

					Class<?>[] cArgs = new Class[1];
					cArgs[0] = AgaramResultSetMapper.class;

					ParameterMetaData objParameterMetaData = callableStatement.getParameterMetaData();
					int paramCount = objParameterMetaData.getParameterCount();
					int count = paramCount;
					if(paramCount > 0){
						while(paramCount >0){
							paramCount--;
							setParameters(callableStatement,AgaramQueryLoader.getTokens(sql.split(Tokens.SEMICOLON.gettokens())[paramCount]),count,true);

						}
					}
					boolean resultsAvailable = callableStatement.execute();

					int j = 0;
					while (resultsAvailable)
					{
						ResultSet collectResult =callableStatement.getResultSet();
						Class<?> entityClass = null;
						Method lMethod = null;
						entityClass = (Class.forName(((Class<?>) lst.get(j)).getName()));

						List<Object> listOfEntity = new ArrayList<Object>();


						lMethod = entityClass.getDeclaredMethod(EntityMapper.MAPROW.getmappername(), cArgs);
						objAbastract.init(collectResult);
						while (objAbastract.resultSet.next()) {
							listOfEntity.add(lMethod.invoke(entityClass.newInstance(),objAbastract));
						}

						rowMap.put(entityClass.getSimpleName(), listOfEntity);
						resultsAvailable = callableStatement.getMoreResults();
						objAbastract.availableColumns = null;
						j++;
					}
				}catch(Exception e){
					throw new SQLException(e.getLocalizedMessage());
				}

				return rowMap;
			}
		});
	}

	private synchronized List<?> executeProcedurePlainSql(final String sql,final List<?> lst) throws Exception
	{
		return getJdbcTemplate().execute(new CallableStatementCreator() {
			@Override
			public CallableStatement createCallableStatement(Connection connection) throws SQLException
			{
				return connection.prepareCall(sql);
			}
		}, new CallableStatementCallback<List<?>>() {
			@Override
			public List<?>  doInCallableStatement(CallableStatement callableStatement) throws SQLException
			{
				List<Object> listOfEntity = null;
				try{
					listOfEntity = new ArrayList<Object>();
					Class<?>[] cArgs = new Class[1];
					cArgs[0] = AgaramResultSetMapper.class;

					ParameterMetaData objParameterMetaData = callableStatement.getParameterMetaData();
					int paramCount = objParameterMetaData.getParameterCount();
					int count = paramCount;
					if(paramCount > 0){
						while(paramCount >0){
							paramCount--;
							setParameters(callableStatement,AgaramQueryLoader.getTokens(sql.split(Tokens.SEMICOLON.gettokens())[paramCount]),count,true);
						}
					}

					boolean resultsAvailable = callableStatement.execute();

					int j = 0;
					while (resultsAvailable)
					{
						ResultSet collectResult =callableStatement.getResultSet();
						Class<?> entityClass = null;
						Method lMethod = null;
						entityClass = (Class.forName(((Class<?>) lst.get(j)).getName()));
						lMethod = entityClass.getDeclaredMethod(EntityMapper.MAPROW.getmappername(), cArgs);
						j++;

						objAbastract.init(collectResult);
						while (objAbastract.resultSet.next()) {
							listOfEntity.add(lMethod.invoke(entityClass.newInstance(),objAbastract));
						}
						resultsAvailable = callableStatement.getMoreResults();
						objAbastract.availableColumns = null;
					}
				}catch(Exception e){
					throw new SQLException(e.getLocalizedMessage());
				}
				return listOfEntity;
			}
		});
	}

	private synchronized List<?> executeProcedureSinglePlainSql(final String sql,final List<?> lst) throws Exception
	{
		return getJdbcTemplate().execute(new CallableStatementCreator() {
			@Override
			public CallableStatement createCallableStatement(Connection connection) throws SQLException
			{




				return connection.prepareCall(sql);



			}
		}, new CallableStatementCallback<List<?>>() {
			@Override
			public List<?>  doInCallableStatement(CallableStatement callableStatement) throws SQLException
			{
				List<Object> listOfEntity = null;
				try{


					listOfEntity = new ArrayList<Object>();
					Class<?>[] cArgs = new Class[1];
					cArgs[0] = AgaramResultSetMapper.class;




					boolean resultsAvailable = callableStatement.execute();



					int j = 0;
					while (resultsAvailable)
					{
						ResultSet collectResult =callableStatement.getResultSet();


						Class<?> entityClass = null;
						Method lMethod = null;

						entityClass = (Class.forName(((Class<?>) lst.get(j)).getName()));









						lMethod = entityClass.getDeclaredMethod(EntityMapper.MAPROW.getmappername(), cArgs);







						j++;


						objAbastract.init(collectResult);

						while (objAbastract.resultSet.next()) {


							listOfEntity.add(lMethod.invoke(entityClass.newInstance(),objAbastract));













						}
						resultsAvailable = callableStatement.getMoreResults();

						objAbastract.availableColumns = null;
					}
				}catch(Exception e){



					throw new SQLException(e.getLocalizedMessage());
				}


				return listOfEntity;
			}
		});
	}


	private synchronized List<String> executeProcedure(final String sql,final String tablename) throws Exception
	{

		return getJdbcTemplate().execute(new CallableStatementCreator() {
			@Override
			public CallableStatement createCallableStatement(Connection connection) throws SQLException
			{
				return connection.prepareCall(sql);
			}
		}, new CallableStatementCallback<List<String>>() {
			@Override
			public List<String> doInCallableStatement(CallableStatement callableStatement) throws SQLException
			{
				List<String> listOfEntity = new ArrayList<String>();
				try{

					ParameterMetaData objParameterMetaData = callableStatement.getParameterMetaData();
					int paramCount = objParameterMetaData.getParameterCount();
					i = 0;
					int count = paramCount;
					if(paramCount > 0){
						while(paramCount >0){
							paramCount--;
							setParameters(callableStatement,AgaramQueryLoader.getTokens(sql.split(Tokens.SEMICOLON.gettokens())[paramCount]),count,false);

						}
					}
					boolean resultsAvailable = callableStatement.execute();
					while (resultsAvailable)
					{
						ResultSet collectResult =callableStatement.getResultSet();
						while (collectResult.next()) {
							String results = collectResult.getString(1);
							results = results.trim().endsWith(Tokens.COMMA.gettokens())==true?results.trim():results.trim()+Tokens.COMMA.gettokens();
							setfields(objQueryCreater.replaceWithPattern(results, "","[\\s+]").toUpperCase());
							String questionMark = results.replaceAll("(.*?)(?:,)", ",?");
							questionMark = questionMark.substring(1,questionMark.length());
							results = results.substring(0,results.length()-1);
							listOfEntity.add("insert into "+tablename+" ("+results+") values("+questionMark+"); ");
						}

						resultsAvailable = callableStatement.getMoreResults();
						objAbastract.availableColumns = null;
					}
				}catch(Exception e){
					throw new SQLException(e.getLocalizedMessage());
				}

				return listOfEntity;
			}
		});
	}

	//Support Functions



	private void setParameters(CallableStatement callableStatement,Tokens tokens,int paramcount,boolean redirectflag) throws SQLException{

		switch(tokens){
		case QUERY_GRID_SQL_QUERY_MAPPING:
			i++;
			break;
		case QUERY_GRID_SQL_QUERY_MAPPING_PARAM:
			i++;
			break;
		case QUERY_GRID_COLUMN_SQL_QUERY_BUILDER:
			i++;
			break;
		case TABLES_PSQL:
			i++;
			break;
		case TABLES_MSSQL:
			i++;
			break;
		default:
			break;
		}
		if(i == paramcount){
			if(redirectflag){
				setParameter(callableStatement,i,1);//1 For FormCode
			}else{
				setParameter(callableStatement,i,2);//2 For Tablename
			}
		}
	}
	private void setParameter(CallableStatement callableStatement,int i,int redirect) throws SQLException{
		switch(i){
		case 1:
			if(redirect == 1)//Formcode assingn
				assignStatement(callableStatement,1, getformcode());
			else if(redirect == 2) //TableName assign
				assignStatement(callableStatement,1, getTablename().toLowerCase());
			break;
		case 2:
			if(redirect == 1){//Formcode assingn
				assignStatement(callableStatement,1, getformcode());
				assignStatement(callableStatement,2, getformcode());
			}
			else if(redirect == 2){//TableName assign
				assignStatement(callableStatement,1, getTablename().toLowerCase());
				assignStatement(callableStatement,2, getTablename().toLowerCase());
			}
			break;
		case 3:
			if(redirect == 1){//Formcode assingn
				assignStatement(callableStatement,1, getformcode());
				assignStatement(callableStatement,2, getformcode());
				assignStatement(callableStatement,3, getformcode());
			}
			else if(redirect == 2){//TableName assign
				assignStatement(callableStatement,1, getTablename().toLowerCase());
				assignStatement(callableStatement,2, getTablename().toLowerCase());
				assignStatement(callableStatement,3, getTablename().toLowerCase());
			}
			break;
		case 4:
			if(redirect == 1){//Formcode assingn
				assignStatement(callableStatement,1, getformcode());
				assignStatement(callableStatement,2, getformcode());
				assignStatement(callableStatement,3, getformcode());
				assignStatement(callableStatement,4, getformcode());
			}
			else if(redirect == 2){//TableName assign
				assignStatement(callableStatement,1, getTablename().toLowerCase());
				assignStatement(callableStatement,2, getTablename().toLowerCase());
				assignStatement(callableStatement,3, getTablename().toLowerCase());
				assignStatement(callableStatement,4, getTablename().toLowerCase());
			}
			break;
		}
	}


	public void assignField(Object object,int value) throws Exception{
		ClassMetadata classMetadata = getSessionFactory().getClassMetadata(object.getClass());
		String identifierPropertyName = classMetadata.getIdentifierPropertyName();
		Field fieldValue = object.getClass().getDeclaredField(identifierPropertyName);
		fieldValue.setAccessible(true);
		fieldValue.setInt(object,value);
	}


	public void assignField(Object object,String value) throws Exception{
		ClassMetadata classMetadata = getSessionFactory().getClassMetadata(object.getClass());
		String identifierPropertyName = classMetadata.getIdentifierPropertyName();
		Field fieldValue = object.getClass().getDeclaredField(identifierPropertyName);
		fieldValue.setAccessible(true);
		fieldValue.set(object,value);
	}

	public String getIdField(Object object) throws Exception{
		ClassMetadata classMetadata = getSessionFactory().getClassMetadata(object.getClass());
		String identifierPropertyName = classMetadata.getIdentifierPropertyName();
		return identifierPropertyName;
	}

	public String getIdField(Class<?> classes) throws Exception{
		ClassMetadata classMetadata = getSessionFactory().getClassMetadata(classes);
		String identifierPropertyName = classMetadata.getIdentifierPropertyName();
		return identifierPropertyName;
	}

	private void setDefaultParameters(PreparedStatement preparedStatement,BeanMap beanMap,String tablename) throws Exception{
		String values = getfields();

		List<String> lstindex = Arrays.asList(values.split(","));
		Set<Map.Entry<String, Integer>> entrySet = beanMap.entrySet();

		int k = 1;
		boolean successFlag = false;
		for(int j=0; j<lstindex.size(); j++){
			successFlag = false;
			Iterator<Map.Entry<String, Integer>> i = entrySet.iterator();
			while(i.hasNext()){
				Map.Entry<String, Integer> element = i.next();
				if(element.getKey().trim().toUpperCase().equals(lstindex.get(j).trim().toUpperCase())){
					Class classname = beanMap.getType(element.getKey());
					switch (classname.getSimpleName()) {
					case "int":
						assignStatement(preparedStatement, j + k, 0);
						break;
					case "String":
						assignStatement(preparedStatement, j + k, tablename != "" ? tablename : null );
						break;
					case "byte":
						assignStatement(preparedStatement, j + k, 0);
						break;
					case "byte[]":
						assignStatement(preparedStatement, j + k, (byte[])null);
						break;
					case "float":
						assignStatement(preparedStatement, j + k, 0.0f);
						break;
					case "double":
						assignStatement(preparedStatement, j + k, 0.0d);
						break;
					case "Date":
						assignStatement(preparedStatement, j + k, (Date)null);
						break;
					case "short":
						assignStatement(preparedStatement, j + k, 0);
						break;
					case "long":
						assignStatement(preparedStatement, j + k, 0l);
						break;

					default:
						break;
					}
					System.out.println("Key: "+element.getKey()+" ,value: "+element.getValue());
					successFlag = true;
				}
				if(successFlag)
					break;
			}
		}
	}

	public void setParameters(PreparedStatement preparedStatement,BeanMap beanMap) throws SQLException,ParseException{
		String values = getfields();

		List<String> lstindex = Arrays.asList(values.split(","));
		Set<Map.Entry<String, Integer>> entrySet = beanMap.entrySet();

		int k = 1;
		boolean successFlag = false;
		for(int j=0; j<lstindex.size(); j++){
			successFlag = false;
			Iterator<Map.Entry<String, Integer>> i = entrySet.iterator();
			while(i.hasNext()){
				Map.Entry<String, Integer> element = i.next();
				if(element.getKey().trim().toUpperCase().equals(lstindex.get(j).trim().toUpperCase())){
					Class classname = beanMap.getType(element.getKey());
					switch (classname.getSimpleName()) {
					case "int":
						assignStatement(preparedStatement, j + k, element.getValue().intValue());
						break;
					case "String":
						assignStatement(preparedStatement, j + k, element.getValue() != null ? String.valueOf(element.getValue()) : null);
						break;
					case "byte":
						assignStatement(preparedStatement, j + k, element.getValue().byteValue());
						break;
					case "byte[]":{
						Object object = element.getValue();
						Byte[] casting = (Byte[])object;
						byte[] bytes = new byte[casting.length];
						int b=0;
						for(Byte byt: casting)
							bytes[b++] = byt.byteValue();
						assignStatement(preparedStatement, j + k, bytes);

						assignStatement(preparedStatement, j + k, element.getValue().byteValue());
					}
					break;
					case "float":{
						Object object = element.getValue();
						Float casting = (Float)object;
						float value = casting.floatValue();
						assignStatement(preparedStatement, j + k, value);
					}
					break;
					case "double":{
						Object object = element.getValue();
						Double casting = (Double)object;
						double value = casting.doubleValue();
						assignStatement(preparedStatement, j + k, value);
					}
					break;
					case "Date":
					{
						if(element.getValue() != null)
						{
							Object inputDate = element.getValue();
							Date date = null;
							String s = inputDate.toString();
							date = new SimpleDateFormat("EEE MMM dd HH:mm:ss zzz yyyy").parse(s);
							assignStatement(preparedStatement, j + k, date);
						}else{
							assignStatement(preparedStatement, j + k, new Date());
						}
						break;
					}

					case "short":
						assignStatement(preparedStatement, j + k, element.getValue().shortValue());
						break;
					case "long":
						assignStatement(preparedStatement, j + k, element.getValue().longValue());
						break;

					default:
						break;
					}
					System.out.println("Key: "+element.getKey()+" ,value: "+element.getValue());
					successFlag = true;
				}
				if(successFlag)
					break;
			}
		}
	}

	public void assignStatement(CallableStatement callableStatement,int index,String value) throws SQLException{
		callableStatement.setString(index, value);
	}
	public void assignStatement(CallableStatement callableStatement,int index,int value) throws SQLException{
		callableStatement.setInt(index, value);
	}
	public void assignStatement(CallableStatement callableStatement,int index,boolean value) throws SQLException{
		callableStatement.setBoolean(index, value);
	}
	public void assignStatement(CallableStatement callableStatement,int index,byte[] value) throws SQLException{
		callableStatement.setBytes(index, value);
	}
	public void assignStatement(CallableStatement callableStatement,int index,byte value) throws SQLException{
		callableStatement.setByte(index, value);
	}
	public void assignStatement(CallableStatement callableStatement,int index,double value) throws SQLException{
		callableStatement.setDouble(index, value);
	}
	public void assignStatement(CallableStatement callableStatement,int index,float value) throws SQLException{
		callableStatement.setFloat(index, value);
	}
	public void assignStatement(CallableStatement callableStatement,int index,Date value) throws SQLException{
		callableStatement.setDate(index,new java.sql.Date(value.getTime()));
	}
	public void assignStatement(CallableStatement callableStatement,int index,short value) throws SQLException{
		callableStatement.setShort(index, value);
	}
	public void assignStatement(CallableStatement callableStatement,int index,long value) throws SQLException{
		callableStatement.setLong(index, value);
	}
	public void assignStatement(PreparedStatement prepardStatement,int index,String value) throws SQLException{
		prepardStatement.setString(index, value);
	}
	public void assignStatement(PreparedStatement prepardStatement,int index,int value) throws SQLException{
		prepardStatement.setInt(index, value);
	}
	public void assignStatement(PreparedStatement prepardStatement,int index,boolean value) throws SQLException{
		prepardStatement.setBoolean(index, value);
	}
	public void assignStatement(PreparedStatement prepardStatement,int index,byte[] value) throws SQLException{
		prepardStatement.setBytes(index, value);
	}
	public void assignStatement(PreparedStatement prepardStatement,int index,byte value) throws SQLException{
		prepardStatement.setByte(index, value);
	}
	public void assignStatement(PreparedStatement prepardStatement,int index,double value) throws SQLException{
		prepardStatement.setDouble(index, value);
	}
	public void assignStatement(PreparedStatement prepardStatement,int index,float value) throws SQLException{
		prepardStatement.setFloat(index, value);
	}
	public void assignStatement(PreparedStatement prepardStatement,int index,Date value) throws SQLException{
		prepardStatement.setDate(index,value != null ? new java.sql.Date(value.getTime()) : null);
	}
	public void assignStatement(PreparedStatement prepardStatement,int index,short value) throws SQLException{
		prepardStatement.setShort(index, value);
	}
	public void assignStatement(PreparedStatement prepardStatement,int index,long value) throws SQLException{
		prepardStatement.setLong(index, value);
	}



}

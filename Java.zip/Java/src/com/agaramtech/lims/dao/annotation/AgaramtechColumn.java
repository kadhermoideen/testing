/**
 * 
 */
package com.agaramtech.lims.dao.annotation;


/**
 * @author Kadher
 *
 */
//@Retention(RetentionPolicy.RUNTIME)
//@Target(ElementType.FIELD)
@java.lang.annotation.Target(value={java.lang.annotation.ElementType.METHOD,java.lang.annotation.ElementType.FIELD})
@java.lang.annotation.Retention(value=java.lang.annotation.RetentionPolicy.RUNTIME)
public @interface AgaramtechColumn {

}

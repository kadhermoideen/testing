/**
 * 
 */
package com.agaramtech.lims.dao.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import org.apache.cxf.ws.rm.v200702.SequenceAcknowledgement.None;

import com.agaramtech.lims.enums.DataTypes;

/**
 * @author Kadher
 *
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
public abstract @interface AgaramtechOneToMany {
	String parentkey() default "";
	String childkey() default "";
	String displayfield() default "";
	DataTypes datatype() default DataTypes.String;
	Class<?> childname() default None.class;
}

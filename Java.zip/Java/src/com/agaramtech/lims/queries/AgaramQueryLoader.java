/**
 *
 *Kadher
 *
 * 24-Dec-2013
 *
 */
package com.agaramtech.lims.queries;

import java.io.IOException;
import java.io.InputStream;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;
import java.util.Properties;

import com.agaramtech.lims.enums.Tokens;

/**
 * @author Kadher
 *
 */
public class AgaramQueryLoader {

	private static final String propFileName = "queries.properties";
	private static Properties props;



	private static Properties getQueries() throws SQLException {
		InputStream is = AgaramQueryLoader.class.getResourceAsStream("/com/agaramtech/lims/properties/" + propFileName);
		if (is == null){
			throw new SQLException("Unable to load property file: " + propFileName);
		}
		if(props == null){
			props = new Properties();
			try {
				props.load(is);
			} catch (IOException e) {
				throw new SQLException("Unable to load property file: " + propFileName + "\n" + e.getMessage());
			}			
		}
		return props;
	}

	public static String getQuery(String query) throws SQLException{
		return getQueries().getProperty(query);
	}
	public static List<String> getQuery(String tokens,int count)throws SQLException{
		List<String> queryList = null;
		if(tokens != null){
			if(tokens != ""){

				queryList= new ArrayList<String>();
				tokens = tokens.split("_")[1];

				Iterator<Entry<Object, Object>> innerIterator = getQueries().entrySet().iterator();
				while (innerIterator.hasNext()) {
					Entry<Object, Object> innerEntry = innerIterator.next();
					if(((String)innerEntry.getKey()).startsWith(tokens))
						queryList.add((String) innerEntry.getValue());
					if(queryList.size() == count)
						break;
				}
			}
		}
		return queryList;
	}

	private static String getKey(String value) throws SQLException{
		String key = "";
		Iterator<Entry<Object, Object>> innerIterator = getQueries().entrySet().iterator();
		while (innerIterator.hasNext()) {
			Entry<Object, Object> innerEntry = innerIterator.next();
			if(value.equalsIgnoreCase((String) innerEntry.getValue())){
				System.out.println("");
				key = (String)innerEntry.getKey();
				break;
			}
		}
		return key.toUpperCase();
	}
	public static Tokens getTokens(String value) throws SQLException{
		Tokens tokens = null ;
		if((getKey(value.trim()+Tokens.SEMICOLON.gettokens())).equalsIgnoreCase(Tokens.QUERY_GRID_SQL_QUERY_MAPPING.gettokens())){
			tokens = Tokens.QUERY_GRID_SQL_QUERY_MAPPING;
		}else if((getKey(value.trim()+Tokens.SEMICOLON.gettokens())).equalsIgnoreCase(Tokens.QUERY_GRID_SQL_QUERY_MAPPING_PARAM.gettokens())){
			tokens = Tokens.QUERY_GRID_SQL_QUERY_MAPPING_PARAM;
		}else if((getKey(value.trim()+Tokens.SEMICOLON.gettokens())).equalsIgnoreCase(Tokens.QUERY_GRID_COLUMN_SQL_QUERY_BUILDER.gettokens())){
			tokens = Tokens.QUERY_GRID_COLUMN_SQL_QUERY_BUILDER;
		}else if((getKey(value.trim()+Tokens.SEMICOLON.gettokens())).equalsIgnoreCase(Tokens.TABLES_PSQL.gettokens())){
			tokens = Tokens.TABLES_PSQL;
		}else if((getKey(value.trim()+Tokens.SEMICOLON.gettokens())).equalsIgnoreCase(Tokens.TABLES_MSSQL.gettokens())){
			System.out.println("");
			tokens = Tokens.TABLES_MSSQL;
		}
		return tokens;
	}

}

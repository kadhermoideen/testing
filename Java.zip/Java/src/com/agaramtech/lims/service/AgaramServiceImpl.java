/**
 *
 *Kadher
 *
 * 02-Jan-2014
 *
 */
package com.agaramtech.lims.service;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.agaramtech.lims.tree.AgaramTree;

/**
 * @author Kadher
 *
 */
public class AgaramServiceImpl implements AgaramService{

	final Log logger = LogFactory.getLog(AgaramServiceImpl.class);

	AgaramDAO objAgaramDAO;

	public AgaramDAO getObjAgaramDAO() {
		return objAgaramDAO;
	}

	public void setObjAgaramDAO(AgaramDAO objAgaramDAO) {
		this.objAgaramDAO = objAgaramDAO;
	}

	@Override
	public AgaramTree getTree(int nPrimaryId,int nSiteCode,String viewName){
		try{
			return objAgaramDAO.getTree(nPrimaryId,nSiteCode,viewName);
		}
		catch(Exception e)
		{
			logger.error(e.getMessage());
			logger.error(e.getCause());
			logger.error(e.getLocalizedMessage());
			return null;
		}
	}


	@Override
	public AgaramTree copyOrCutTreeNode(int nParentCode,int nChildCode,int nType,int nTableCode,String sViewName,boolean masterNode){
		try{

			int rtnId = objAgaramDAO.copyOrCutTreeNode(nParentCode,nChildCode,nType,nTableCode,sViewName,masterNode);
			return objAgaramDAO.getTree(rtnId,sViewName,nTableCode);

		}
		catch(Exception e)
		{
			logger.error(e.getMessage());
			logger.error(e.getCause());
			logger.error(e.getLocalizedMessage());
			return null;
		}
	}
}

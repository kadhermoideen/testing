package com.agaramtech.lims.service.controls;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.HibernateException;
import org.hibernate.LockMode;
import org.hibernate.Session;
import org.hibernate.transform.Transformers;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.transaction.annotation.Transactional;

import com.agaramtech.lims.base.RunningMaker;
import com.agaramtech.lims.controls.ComponentMaster;
import com.agaramtech.lims.controls.CustomLinkTable;
import com.agaramtech.lims.controls.DesignMaster;
import com.agaramtech.lims.controls.DesignMasterJoins;
import com.agaramtech.lims.controls.DynamicFieldDatas;
import com.agaramtech.lims.controls.ExistingLinkTable;
import com.agaramtech.lims.controls.ExportSampleType;
import com.agaramtech.lims.controls.SampleType;
import com.agaramtech.lims.controls.TableColumnNames;
import com.agaramtech.lims.controls.TableColumns;
import com.agaramtech.lims.controls.TableFields;
import com.agaramtech.lims.controls.TableNames;
import com.agaramtech.lims.dao.support.AgaramDaoSupport;
import com.agaramtech.lims.dao.support.bridge.RDBMSBridge;
import com.agaramtech.lims.dao.support.bridge.RDBMSParameter;
import com.agaramtech.lims.dao.support.enums.RDBMSEnum;
import com.agaramtech.lims.dao.support.enums.ReturnStatus;
import com.agaramtech.lims.dao.support.enums.Status;
import com.agaramtech.lims.dao.support.global.AgaramtechGeneralfunction;
import com.agaramtech.lims.support.AgaramControlSupport;
import com.agaramtech.lims.tree.AgaramTree;
import com.agaramtech.lims.tree.TableNamesSub;

import flex.messaging.io.amf.ASObject;



@SuppressWarnings({"rawtypes","unchecked","unused","deprecation"})
@Transactional
public class AgaramtechControlsDAOImpl extends AgaramDaoSupport implements AgaramtechControlsDAO
{

	private final AgaramtechGeneralfunction objGeneral;
	private static int dataBaseType = 0;
	final Log logging = LogFactory.getLog(AgaramtechControlsDAOImpl.class);
	public AgaramtechControlsDAOImpl(RDBMSParameter objParameter,AgaramtechGeneralfunction objGeneral) {
		super(objParameter,objGeneral);
		if(objParameter.getsdatabasetype().equals(RDBMSEnum.DB_MYSQL.getDataBaseType())) {
			dataBaseType = RDBMSEnum.DB_MYSQL.getType();
		} else if(objParameter.getsdatabasetype().equals(RDBMSEnum.DB_POSTGRESQL.getDataBaseType())) {
			dataBaseType = RDBMSEnum.DB_POSTGRESQL.getType();
		} else if(objParameter.getsdatabasetype().equals(RDBMSEnum.DB_MICROSOFT_SQL_SERVER.getDataBaseType())) {
			dataBaseType = RDBMSEnum.DB_MICROSOFT_SQL_SERVER.getType();
		} else if(objParameter.getsdatabasetype().equals(RDBMSEnum.DB_ORACLE.getDataBaseType())) {
			dataBaseType = RDBMSEnum.DB_ORACLE.getType();
		}
		logging.info("in constructor");
		this.objGeneral = objGeneral;
		RDBMSBridge.dataBaseType = dataBaseType;
	}


	@Override
	public List<SampleType> getSampleType()
	{ 
		// FOR DEMO MANI
		//	return getHibernateTemplate().find(" from SampleType where sStatus = 'A' order by norderno ");

		final String query="select st.nsampletypecode,st.dcreateddate,st.dmodifieddate, " +
				" st.nconcodinate,st.norderno,st.nscreentype,st.screatedby,st.sdescription,st.sdisplaysamptype,st.smodifiedby, " +
				" st.sprefix,st.ssamptype,st.sseqtable,st.sstatus ,isnull(tn.ntablecode,0) as ntablecode from sampletype st " +
				" left outer join tablenames tn on tn.nformcode = st.nscreentype where st.sStatus = 'A' order by st.norderno ";

		logger.info("query  "+query);

		return getHibernateTemplate().execute(new HibernateCallback<List<SampleType>>() {

			@Override
			public List<SampleType> doInHibernate(Session sess) throws HibernateException, SQLException {
				return sess.createSQLQuery(query).setResultTransformer(Transformers.aliasToBean(SampleType.class)).list();	


			}
		});



	}
	@Override
	public List<ExportSampleType> getExportSampleType(int nSampleTypeCode){
		return getHibernateTemplate().find("from ExportSampleType where nsampletypecode="+nSampleTypeCode+"");
	}
	@Override
	public void insertUpdateTableFields(TableFields objDynamicFields){
		if(objDynamicFields.getnfieldscode() == 0)
		{
			RunningMaker objRunningMaker = getHibernateTemplate().get(RunningMaker.class, "TableFields", LockMode.PESSIMISTIC_WRITE);
			int running = objRunningMaker.getsequencenumber();
			running = running + 1;

			logger.info("running--------------->" + running);
			objDynamicFields.setnfieldscode(running);
			objDynamicFields.setdcreateddate(objGeneral.getdDateTime());
			objDynamicFields.setdmodifieddate(objGeneral.getdDateTime());
			getHibernateTemplate().save(objDynamicFields);
			logger.info("getHibernateTemplate().save(objOutSourceOrder)---------------> Completed" );
			getHibernateTemplate().evict(objRunningMaker);
			getHibernateTemplate().bulkUpdate("update RunningMaker set sequencenumber="+running+" " +
					" where tablename='"+objRunningMaker.gettablename()+"'");
		}
		else if(objDynamicFields.getnfieldscode() != 0 && objDynamicFields.getnstatus() == 0)
		{
			logger.info("Delete Working--------------->");
			objDynamicFields.setdmodifieddate(objGeneral.getdDateTime());
			getHibernateTemplate().update(objDynamicFields);
		}else if(objDynamicFields.getnfieldscode() != 0 && objDynamicFields.getnstatus() == 1){
			objDynamicFields.setdmodifieddate(objGeneral.getdDateTime());
			getHibernateTemplate().update(objDynamicFields);
		}
	}




	/** * @author Kadher Moideen S * * Aug 10, 2012 5:19:04 PM */

	@Override
	public List<DesignMaster> getFormDesign(int nSampleTypeCode){

		// FOR DEMO MANI
		//return getHibernateTemplate().find("from DesignMaster where nStatus = 1 and nRegistrationTypeCode="+nSampleTypeCode+" order by nDesingCode");




		final String query="select dm.nDesingCode,dm.nControlCode,dm.nLinkTableCode,dm.nLinkType,dm.nMandatry,dm.nRegistrationTypeCode,dm.nSize, " +
				" case when dm.nMandatry = '1' then 'Yes' else 'No' end smandatary, " + 
				" dm.nStatus,dm.ntablecode,dm.sCriteria, dm.sDataType,dm.sDisplayName,dm.sFieldName,dm.ntreenodecode,cm.sControlName,st.ssamptype " +
				" from DesignMaster dm left outer join ComponentMaster cm on cm.nControlCode = dm.nControlCode " +
				" left outer join sampletype st on st.nscreentype = dm.nRegistrationTypeCode " +
				" where dm.nStatus = 1 and dm.nRegistrationTypeCode="+nSampleTypeCode+" order by dm.nDesingCode";

		logger.info("query  "+query);

		return getHibernateTemplate().execute(new HibernateCallback<List<DesignMaster>>() {

			@Override
			public List<DesignMaster> doInHibernate(Session sess) throws HibernateException, SQLException {
				return sess.createSQLQuery(query).setResultTransformer(Transformers.aliasToBean(DesignMaster.class)).list();	


			}
		});
	}

	@Override
	public List<ComponentMaster> getComponents(){
		logging.info("in getcomponents");
		return getHibernateTemplate().find("from ComponentMaster");
	}

	@Override
	public List<ExistingLinkTable> getExistingTablesName(){

		return getHibernateTemplate().find("from ExistingLinkTable  where nStatus = 1");
	}
	@Override
	public Map<String,Map<String, List>> getExistingLinkQuerys(List<DesignMasterJoins> lstExistsLink){

		Map<String, List>  loadmap = null;
		Map<String,Map<String, List>> returnMap=new TreeMap<String, Map<String,List>>();

		if(lstExistsLink != null)
		{
			if(lstExistsLink.size() > 0)
			{
				for (DesignMasterJoins objDesignMasterJoins : lstExistsLink) {
					if(objDesignMasterJoins.getsLabelField() != null){
						Iterator<ExistingLinkTable> iterator = getHibernateTemplate().find("from ExistingLinkTable where nStatus = 1 and nExistingCode="+objDesignMasterJoins.getnLinkTableCode()+"").iterator();
						logger.info("Process is done");
						while(iterator.hasNext())
						{
							loadmap =  new TreeMap<String, List>();
							ExistingLinkTable objLinkTable = iterator.next();
							logger.info("Process is done" + objLinkTable.getsExistingClassName());
							try {
								loadmap.put(objDesignMasterJoins.getsFieldName(), getHibernateTemplate().find("from "+objLinkTable.getsExistingTableName()+" where "+objDesignMasterJoins.getsLabelField()+""));
								returnMap.put(objLinkTable.getsDisplayMember()+"$"+objLinkTable.getsValueMember(), loadmap);
							} catch (Exception e) {
								logger.error(e.getMessage());
								logger.error(e.getCause());
							}
						}
					}
				}
			}
		}

		return returnMap;
	}

	@Override
	public Map<String,Map<Integer, List>> getExistingLinkTables(String sExistsLinkCode){
		if(sExistsLinkCode != null)
		{
			if(sExistsLinkCode != "")
			{
				sExistsLinkCode = sExistsLinkCode.substring(1,sExistsLinkCode.length());
			}
		}
		List<ExistingLinkTable> lst = getHibernateTemplate().find("from ExistingLinkTable where nStatus = 1 and nExistingCode in("+sExistsLinkCode+")");

		Iterator<ExistingLinkTable> iterator = lst.iterator();
		Map<Integer, List>  loadmap = null;
		Map<String,Map<Integer, List>> returnMap=new TreeMap<String, Map<Integer,List>>();
		while(iterator.hasNext())
		{
			loadmap =  new TreeMap<Integer, List>();
			ExistingLinkTable objLinkTable = iterator.next();

			//				Class c = Class.forName(objLinkTable.getsExistingClassName());
			loadmap.put(objLinkTable.getnExistingCode(), getHibernateTemplate().find(objLinkTable.getsExistingClassName()));
			returnMap.put(objLinkTable.getsDisplayMember(), loadmap);

		}
		return returnMap;
	}
	@Override
	public Map<String,Map<Integer, List>> getExistingLinkTables(String sExistsLinkCode,int nsampletype,int nexportsampletype){
		if(sExistsLinkCode != null)
		{
			if(sExistsLinkCode != "")
			{
				sExistsLinkCode = sExistsLinkCode.substring(1,sExistsLinkCode.length());
			}
		}
		List<ExistingLinkTable> lst = getHibernateTemplate().find("from ExistingLinkTable where nStatus = 1 and nExistingCode in("+sExistsLinkCode+")");
		Iterator<ExistingLinkTable> iterator = lst.iterator();
		Map<Integer, List>  loadmap = null;
		Map<String,Map<Integer, List>> returnMap=new TreeMap<String, Map<Integer,List>>();
		String query = "";

		while(iterator.hasNext())
		{
			loadmap =  new TreeMap<Integer, List>();
			ExistingLinkTable objLinkTable = iterator.next();
			switch(objLinkTable.getsValueMember()){
			case "sARNo":
				query = objLinkTable.getsExistingClassName()+" and nSampleType="+nsampletype+" and nSubSampId="+nexportsampletype+"";
				break;
			case "nsampletypecode":
				query = objLinkTable.getsExistingClassName()+" and nsampletypecode="+nsampletype+"";
				break;
			default:
				query = objLinkTable.getsExistingClassName();
				break;
			}
			//				Class c = Class.forName(objLinkTable.getsExistingClassName());
			loadmap.put(objLinkTable.getnExistingCode(), getHibernateTemplate().find(query));
			returnMap.put(objLinkTable.getsDisplayMember(), loadmap);

		}
		return returnMap;
	}

	@Override
	public List<CustomLinkTable>getCustomLinkTables(String sDesignCode){
		if(sDesignCode != null)
		{
			if(sDesignCode != "")
			{
				sDesignCode = sDesignCode.substring(1,sDesignCode.length());
			}
		}
		return getHibernateTemplate().find("from CustomLinkTable where nStatus = 1 and nDesingCode in("+sDesignCode+")");
	}

	@Override
	public List<DesignMasterJoins> getDynamicDesignFields(int nSampleTypeCode,int nTreeNodeCode){
		if(nTreeNodeCode > 0 && nSampleTypeCode > 0)
		{
			return getHibernateTemplate().find("from DesignMasterJoins where ntreenodecode = '"+nTreeNodeCode+"' and  nRegistrationTypeCode="+nSampleTypeCode+"");	
		}
		else if(nTreeNodeCode > 0 && nSampleTypeCode<= 0)
		{
			return getHibernateTemplate().find("from DesignMasterJoins where ntreenodecode = "+nTreeNodeCode);	
		}
		else if(nTreeNodeCode <= 0 && nSampleTypeCode > 0)
		{
			return getHibernateTemplate().find("from DesignMasterJoins where nRegistrationTypeCode="+nSampleTypeCode+"");
		}
		else
		{
			return null;
		}
	}
	@Override
	public void insertFormDesign(List<DesignMaster> lstDesignMasters,List<CustomLinkTable> lstCustomLinkTables){
		if(lstDesignMasters != null){
			if(lstDesignMasters.size() > 0)
			{
				RunningMaker objSG_1 = getHibernateTemplate().get(RunningMaker.class,"DesignMaster" , LockMode.PESSIMISTIC_WRITE );
				int sSqn1 = objSG_1.getsequencenumber();
				RunningMaker objSG_2 = getHibernateTemplate().get(RunningMaker.class,"CustomLinkTable" , LockMode.PESSIMISTIC_WRITE );
				int sSqn2 = objSG_2.getsequencenumber();
				for(DesignMaster objDesignMaster : lstDesignMasters)
				{
					sSqn1 = sSqn1 +1;
					objDesignMaster.setnDesingCode(sSqn1);
					getHibernateTemplate().save(objDesignMaster);
					objSG_1.setsequencenumber(sSqn1);
					getHibernateTemplate().update(objSG_1);

					logger.info("-----------Insert objDesignMaster is Success--------");
					if(lstCustomLinkTables != null){
						if(lstCustomLinkTables.size() > 0){
							for(CustomLinkTable objCustomLinkTable : lstCustomLinkTables)
							{
								if(objDesignMaster.getnRunningNumber() == objCustomLinkTable.getnRunningNumber()) {
									sSqn2 = sSqn2 +1;
									objCustomLinkTable.setnDesingCode(objDesignMaster.getnDesingCode());
									objCustomLinkTable.setnCustomCode(sSqn2);
									getHibernateTemplate().save(objCustomLinkTable);

									objSG_2.setsequencenumber(sSqn2);
									getHibernateTemplate().update(objSG_2);
									logger.info("-----------Insert objCustomLinkTable is Success--------");
								}
							}
						}
					}
				}
			}
		}
	}

	@Override
	public List<TableFields> getTableFields(int nTableCode){
		// FOR DEMO MANI

		StringBuffer sb = new StringBuffer();

		if(nTableCode == -1)
			sb.append("tf.nstatus="+Status.ACTIVE.getstatus());
		else
			sb.append("tf.ntablecode = "+nTableCode+" and tf.nstatus="+Status.ACTIVE.getstatus());


		final String query="select tf.nfieldscode,tf.dcreateddate,tf.dmodifieddate,tf.ncreatedby,tf.nmodifiedby,tf.nstatus,tf.ntablecode,tf.sdisplayname, " +
				" tf.sfieldname,tn.stablename from tablefields tf left outer join tablenames tn on tn.ntablecode = tf.ntablecode " +
				" where "+sb.toString()+" order by tf.nfieldscode ";

		logger.info("query  "+query);

		return getHibernateTemplate().execute(new HibernateCallback<List<TableFields>>() {

			@Override
			public List<TableFields> doInHibernate(Session sess) throws HibernateException, SQLException {
				return sess.createSQLQuery(query).setResultTransformer(Transformers.aliasToBean(TableFields.class)).list();	


			}
		});
	}
	@Override
	public List<TableNames> getTableNames(){
		//		TableNames objNames=(TableNames) getHibernateTemplate().find("from TableNames where nstatus="+Status.ACTIVE.getstatus()+" order by ntablecode").get(0);
		//		try{
		//		//	insertObject(objNames);
		//		}catch(Exception e){
		//			e.printStackTrace();
		//		}
		return getHibernateTemplate().find("from TableNames where nstatus="+Status.ACTIVE.getstatus()+" order by ntablecode");
	}

	@Override
	public Map<String,Object> insertDynamicFields(List<flex.messaging.io.amf.ASObject> lstObjects,flex.messaging.io.amf.ASObject objPrimary,int nprimarycode,int nsecondarycode,int nregistercode) throws Exception{
		Map<String,Object> objMap = new HashMap<String,Object>();
		if(objPrimary != null){
			if(lstObjects != null){
				if(lstObjects.size() > 0){
					lstObjects.add(objPrimary);
					ASObject objAsObject = lstObjects.get(0);
					String value = objAsObject.get("ndesigncode").toString();
					List<TableNames> lstTableNames = (List<TableNames>) findBySinglePlainSql("select * from tablenames where ntablecode = (select ntablecode from DesignMaster where nDesingCode= "+value+") ", TableNames.class);

					int primaryTableNo = 0;
					if(lstTableNames != null && lstTableNames.size() > 0)
					{
						if(lstTableNames.get(0).getnhassub() > 0)
						{
							List<TableNamesSub> lstTableNamesSubs = (List<TableNamesSub>) findBySinglePlainSql("select * from tablenamessub where nsubtablecode = "+lstTableNames.get(0).getnsubtablecode(), TableNamesSub.class);
							if(lstTableNamesSubs != null && lstTableNamesSubs.size() > 0)
							{
								AgaramTree objAgaramTree = getTreeObjectToSave(lstTableNames,lstTableNamesSubs,objGeneral,lstObjects);
								if(objAgaramTree.getrtnList() != null)
								{
									for(Object obj : objAgaramTree.getrtnList())
									{
										getHibernateTemplate().save(obj);
									}

									logging.info("nsecondarycode  "+nsecondarycode);
									if(nsecondarycode != 0)
									{
										lstObjects.remove(lstObjects.indexOf(objPrimary));
										insertDynamicFields(lstObjects,nprimarycode,nsecondarycode,nregistercode,objAgaramTree.getnprimaryid());
									}
								}
								objMap.put("tree", objAgaramTree);
							}
						}
					}
				}
			}

		}else{
			insertDynamicFields(lstObjects,nprimarycode,nsecondarycode,nregistercode,0);
		}
		return objMap;
	}

	private  void insertDynamicFields(List<flex.messaging.io.amf.ASObject> lstObjects,int nprimarycode,int nsecondarycode,int nregistercode,int nmastercode) throws Exception
	{
		if(lstObjects != null){
			logger.info("lstObjects.size()------------------> = "+lstObjects.size());  
			if(lstObjects.size() > 0){
				RunningMaker objGenerator1 = getHibernateTemplate().get(RunningMaker.class, "DynamicFieldDatas", LockMode.PESSIMISTIC_WRITE);
				int count = objGenerator1.getsequencenumber();

				for(flex.messaging.io.amf.ASObject obj:lstObjects){
					Set<String> e = obj.keySet();
					for (Iterator<String> iterator = e.iterator(); iterator.hasNext();) {

						DynamicFieldDatas objFields = new DynamicFieldDatas();
						count = count +1 ;
						String keys = iterator.next();
						String designkeys = iterator.next();

						logger.info("key------------------> = "+keys); 
						logger.info("designkeys------------------> = "+designkeys); 

						if(designkeys.equals("ndesigncode")){
							objFields.setndesigncode(Integer.parseInt(obj.get(designkeys).toString()));
						}else{
							objFields.setscolumnname(designkeys);
							objFields.setscolumnvalue(obj.get(designkeys).toString());
						}if(keys.equals("ndesigncode")){
							objFields.setndesigncode(Integer.parseInt(obj.get(keys).toString()));
						}else{
							objFields.setscolumnname(keys);
							objFields.setscolumnvalue(obj.get(keys).toString());
						}
						objFields.setnfieldscode(count);
						objFields.setnpreregno(nregistercode);
						objFields.setnprimarytypecode(nprimarycode);
						objFields.setnsecondarytypecode(nsecondarycode);
						objFields.setnmastercode(nmastercode);
						getHibernateTemplate().save(objFields);
						//									logger.info("key------------------> = "+keys); 
						logger.info("objFields.getscolumnvalue()------------------> = "+objFields.getscolumnvalue()); 
					}
				}

				logger.info("count = "+count);  

				logger.info("getHibernateTemplate().save(DynamicFieldDatas) = "+"Completed"); 

				getHibernateTemplate().bulkUpdate("update RunningMaker set sequencenumber = "+count+" where tablename='DynamicFieldDatas'");
			}
		}
	}

	@Override
	public void insertDynamicFields(List<flex.messaging.io.amf.ASObject> lstObjects,String strmaster) throws Exception
	{
		if(lstObjects != null){
			logger.info("lstObjects.size()------------------> = "+lstObjects.size());  
			if(lstObjects.size() > 0){
				RunningMaker objGenerator1 = getHibernateTemplate().get(RunningMaker.class, "DynamicFieldDatas", LockMode.PESSIMISTIC_WRITE);
				int count = objGenerator1.getsequencenumber();
				List<DesignMaster> lstDesignMasters = null;
				String[] arrayMaster = strmaster.split(",");
				for(String str : arrayMaster)
				{
					for(flex.messaging.io.amf.ASObject obj:lstObjects){
						Set<String> e = obj.keySet();
						for (Iterator<String> iterator = e.iterator(); iterator.hasNext();) {

							DynamicFieldDatas objFields = new DynamicFieldDatas();
							count = count +1 ;
							String keys = iterator.next();
							String designkeys = iterator.next();

							logger.info("key------------------> = "+keys); 
							logger.info("designkeys------------------> = "+designkeys); 

							if(designkeys.equals("ndesigncode")){
								objFields.setndesigncode(Integer.parseInt(obj.get(designkeys).toString()));
								if(lstDesignMasters == null)
								{
									lstDesignMasters = new ArrayList<DesignMaster>();
									lstDesignMasters = getHibernateTemplate().find("from DesignMaster where nDesingCode = "+Integer.parseInt(obj.get(keys).toString()));
								}
							}else{
								objFields.setscolumnname(designkeys);
								objFields.setscolumnvalue(obj.get(designkeys).toString());
							}if(keys.equals("ndesigncode")){
								if(lstDesignMasters == null)
								{
									lstDesignMasters = new ArrayList<DesignMaster>();
									lstDesignMasters = getHibernateTemplate().find("from DesignMaster where nDesingCode = "+Integer.parseInt(obj.get(keys).toString()));
								}
								objFields.setndesigncode(Integer.parseInt(obj.get(keys).toString()));
							}else{
								objFields.setscolumnname(keys);
								objFields.setscolumnvalue(obj.get(keys).toString());
							}
							objFields.setnfieldscode(count);
							objFields.setnpreregno(Integer.parseInt(str));
							if(lstDesignMasters != null && lstDesignMasters.size() > 0)
							{
								objFields.setnprimarytypecode(lstDesignMasters.get(0).getnRegistrationTypeCode());
								objFields.setnsecondarytypecode(lstDesignMasters.get(0).getntreenodecode());
								objFields.setnmastercode(0);

							}
							getHibernateTemplate().save(objFields);
							//									logger.info("key------------------> = "+keys); 
							logger.info("objFields.getscolumnvalue()------------------> = "+objFields.getscolumnvalue()); 
						}
					}
				}
				logger.info("count = "+count);  

				logger.info("getHibernateTemplate().save(DynamicFieldDatas) = "+"Completed"); 

				getHibernateTemplate().bulkUpdate("update RunningMaker set sequencenumber = "+count+" where tablename='DynamicFieldDatas'");
			}
		}
	}

	private AgaramTree getTreeObjectToSave(List<TableNames> lstTableNames,List<TableNamesSub> lstTableNamesSubs,AgaramtechGeneralfunction objGeneral,List<flex.messaging.io.amf.ASObject> lstObjects) throws Exception
	{
		AgaramTree objAgaramTree = null;
		objAgaramTree = new AgaramTree();
		objAgaramTree.setsrtnerrmsg(ReturnStatus.SUCCESS.getstatus());
		List<Object> lst = null;
		boolean bFlag = true;
		String uniqueColumn = null;
		final Log logging = LogFactory.getLog(AgaramControlSupport.class);
		int primaryTableNo = 0;
		int nMasterTableCode = 0;
		Object classTableName = Class.forName(lstTableNames.get(0).getsclassname()).newInstance();
		Object classTableNameSub = Class.forName(lstTableNamesSubs.get(0).getssubclassname()).newInstance();
		List<Object> lstFirst = getHibernateTemplate().find("from "+classTableNameSub.getClass().getSimpleName()+" where "+ lstTableNamesSubs.get(0).getschildcolumn()+" <> 0");
		logging.info("1---> "+lstTableNames.size());
		if(lstTableNames.get(0).getsprimarycolumn() != null){
			if(lstTableNames.get(0).getsprimarycolumn() != ""){
				uniqueColumn = lstTableNames.get(0).getsuniquecolumn();
				primaryTableNo = objGeneral.getRunningCode(classTableName);
				nMasterTableCode = primaryTableNo;
				objGeneral.getPrivateFields(classTableName,lstTableNames.get(0).getsprimarycolumn(),String.valueOf(primaryTableNo));
				objAgaramTree.setnprimaryid(primaryTableNo); // this is the return object
				if(lstFirst.size() == 0)// && lstFirst.get(0).getClass().getnuserchildrolecode() == 0)
				{
					List<?> lstClassTableSub = findBySinglePlainSql( "select "+lstTableNamesSubs.get(0).getschildcolumn()+" from "+classTableNameSub.getClass().getSimpleName()+" where "+lstTableNamesSubs.get(0).getschildcolumn()+" <> 0", classTableNameSub.getClass());
					if(lstClassTableSub.size() <= 0 )
					{
						bFlag = false;
						getHibernateTemplate().bulkUpdate("update "+classTableNameSub.getClass().getSimpleName()+" set "+lstTableNamesSubs.get(0).getschildcolumn()+" = "+primaryTableNo);
					}
				}
				else 
				{
					objGeneral.getPrivateFields(classTableNameSub,lstTableNamesSubs.get(0).getschildcolumn(),String.valueOf(primaryTableNo));
				}
			}
		}

		if(lstTableNamesSubs.get(0).getsprimarycolumn() != null){
			if(lstTableNamesSubs.get(0).getsprimarycolumn() != ""){
				if(bFlag)
				{
					primaryTableNo = objGeneral.getRunningCode(classTableNameSub);
					objGeneral.getPrivateFields(classTableNameSub,lstTableNamesSubs.get(0).getsprimarycolumn(),String.valueOf(primaryTableNo));
				}
			}
		}

		String sMasterName = null;
		String sUniqueNumber = null;
		String sSecondaryValue = null;
		boolean bFlagBreak = false;
		List<TableColumns> lstColumns = (List<TableColumns>) findBySinglePlainSql("select stablecolumnname,ntablecolumncode from tablecolumns where nstatus = "+Status.ACTIVE.getstatus()+" and ntablecode = "+lstTableNames.get(0).getntablecode(), TableColumns.class);

		for(flex.messaging.io.amf.ASObject obj:lstObjects)
		{
			System.out.println(obj);
			if(lst == null)
			{
				lst = new ArrayList<Object>();
			}
			Set<String> columnname = obj.keySet();
			TableColumns objTableColumns = new TableColumns();

			for (Iterator<String> iterator = columnname.iterator(); iterator.hasNext();) 
			{

				String keys = iterator.next();
				objTableColumns.setstablecolumnname(keys);

				//System.out.println(objTableColumns.indexOf(lstColumns, objTableColumns));
				if(lstColumns.contains(objTableColumns))
				{
					System.out.println(lstColumns.indexOf(objTableColumns));
					lstObjects.remove(obj);
				}
				if(!keys.equals("ndesigncode")){
					if(keys.trim().toUpperCase().equals("masterName".trim().toUpperCase()) && obj.get(keys) != null && obj.get(keys).toString().trim().length() > 0)
					{
						List<SampleType> lstSampleTypes = (List<SampleType>) findBySingleConditionalField("nsampletypecode,ssamptype",SampleType.class,"where ssamptype = '"+obj.get(keys).toString()+"'");
						int sampleTypeCount = 0;
						if(lstSampleTypes.size() <= 0)
						{
							getHibernateTemplate().bulkUpdate("Update RunningMaker set sequencenumber=sequencenumber+1 where tablename='"+SampleType.class.getSimpleName()+"'");
							RunningMaker objSampleTypeGenerator = (RunningMaker) getHibernateTemplate().find("from RunningMaker where tablename='"+SampleType.class.getSimpleName()+"'").get(0);
							sampleTypeCount = objSampleTypeGenerator.getsequencenumber();
							SampleType objSampleType= new SampleType();
							objSampleType.setnsampletypecode(sampleTypeCount);
							objSampleType.setdcreateddate(objGeneral.getdDateTime());
							objSampleType.setdmodifieddate(objGeneral.getdDateTime());
							objSampleType.setnconcodinate(1);
							objSampleType.setnorderno(1);
							objSampleType.setnscreentype(lstTableNames.get(0).getnformcode());
							objSampleType.setsdisplaysamptype(obj.get(keys).toString());
							objSampleType.setssamptype(obj.get(keys).toString());
							objSampleType.setsseqtable(obj.get(keys).toString());
							objSampleType.setsstatus("A");
							lst.add(objSampleType);
						}
						else 
						{
							sampleTypeCount = lstSampleTypes.get(0).getnsampletypecode();
						}
						getHibernateTemplate().bulkUpdate("Update RunningMaker set sequencenumber=sequencenumber+1 where tablename='"+ExportSampleType.class.getSimpleName()+"'");
						RunningMaker objExportSampleTypeGenerator = (RunningMaker) getHibernateTemplate().find("from RunningMaker where tablename='"+ExportSampleType.class.getSimpleName()+"'").get(0);

						ExportSampleType objExportSampleType = new ExportSampleType();
						objExportSampleType.setnexporttypeno(objExportSampleTypeGenerator.getsequencenumber());
						objExportSampleType.setnsampletypecode(sampleTypeCount);
						objExportSampleType.setscountryname(sMasterName);
						objExportSampleType.setnstatus(Status.ACTIVE.getstatus());
						objExportSampleType.setnsitecode(0);
						objExportSampleType.setnorderno(0);
						objExportSampleType.setsdisplaycountryname(sMasterName);
						objExportSampleType.setntreemastercode(nMasterTableCode);
						lst.add(objExportSampleType);
					}
					else if(obj.get(keys) != null)
					{						
						if(!lstTableNames.get(0).getsprimarycolumn().equalsIgnoreCase(keys)){

							if(uniqueColumn != null && uniqueColumn.trim().toUpperCase().equals(keys.toString().trim().toUpperCase()))
							{								
								List<?> lstClassTableSub = findBySinglePlainSql( "select "+lstTableNames.get(0).getsuniquecolumn()+" from "+classTableName.getClass().getSimpleName()+" where "+lstTableNames.get(0).getsuniquecolumn()+" = '"+obj.get(keys)+"'", classTableName.getClass());								
								if(lstClassTableSub.size() > 0 )
								{
									bFlagBreak = true;
									logger.info("inner break");
									objAgaramTree.setsrtnerrmsg(ReturnStatus.RECORD_ALREADY_EXISTS.getstatus()); // this is the return object
									break;
								}
								else
								{
									sMasterName = obj.get(keys).toString();
									objGeneral.getPrivateFields(classTableName,keys,obj.get(keys).toString());
									objAgaramTree.setsvalue(sMasterName); // this is the return object	
									logging.info("objAgaramTree.setsvalue1  "+objAgaramTree.getsvalue());
								}
							}
							else
							{								
								sMasterName = obj.get(keys).toString();
								objGeneral.getPrivateFields(classTableName,keys,obj.get(keys).toString());
								if(lstTableNames.get(0).getssecondarycolumn() != null)
								{
									if(keys.trim().toUpperCase().equals(lstTableNames.get(0).getssecondarycolumn().trim().toUpperCase())){
										sSecondaryValue = obj.get(keys).toString();
									}
								}
								//objAgaramTree.setsvalue(sMasterName); // this is the return object	
							}
						}
						if(!lstTableNamesSubs.get(0).getsprimarycolumn().equalsIgnoreCase(keys)){
							if(!lstTableNamesSubs.get(0).getschildcolumn().equalsIgnoreCase(keys)){								
								if(bFlag)
								{
									objGeneral.getPrivateFields(classTableNameSub,keys,obj.get(keys).toString());
								}
							}
						}
					}
				}
			}
			if(bFlagBreak)
			{
				logger.info("outer break");
				break;
			}
		}
		if(bFlagBreak != true)
		{
			lst.add(classTableName);
			if(bFlag)
			{
				lst.add(classTableNameSub);
			}
		}
		if(sSecondaryValue != null && sSecondaryValue.length() > 0)
		{
			objAgaramTree.setnsecondid(Integer.parseInt(sSecondaryValue)); // this is the return object	
		}
		objAgaramTree.setrtnList(lst);
		return objAgaramTree;
	}


	@Override
	public List<TableColumnNames> getTableColumns(String sTableName) {
		final String query="select COLUMN_NAME as scolumname,DATA_TYPE as sdatatype from INFORMATION_SCHEMA.COLUMNS " +
				" where TABLE_NAME='"+sTableName+"'";

		logger.info("query  "+query);

		return getHibernateTemplate().execute(new HibernateCallback<List<TableColumnNames>>() {

			@Override
			public List<TableColumnNames> doInHibernate(Session sess) throws HibernateException, SQLException {
				return sess.createSQLQuery(query).setResultTransformer(Transformers.aliasToBean(TableColumnNames.class)).list();	


			}
		});
	}
}
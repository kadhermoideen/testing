package com.agaramtech.lims.service.controls;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.agaramtech.lims.controls.ComponentMaster;
import com.agaramtech.lims.controls.CustomLinkTable;
import com.agaramtech.lims.controls.DesignMaster;
import com.agaramtech.lims.controls.DesignMasterJoins;
import com.agaramtech.lims.controls.ExistingLinkTable;
import com.agaramtech.lims.controls.ExportSampleType;
import com.agaramtech.lims.controls.SampleType;
import com.agaramtech.lims.controls.TableColumnNames;
import com.agaramtech.lims.controls.TableFields;
import com.agaramtech.lims.controls.TableNames;


@SuppressWarnings({"serial","rawtypes","unchecked"})
public class AgaramtechControlsServiceImpl implements Serializable,AgaramtechControlsService{

	final Log logging = LogFactory.getLog(AgaramtechControlsServiceImpl.class);

	AgaramtechControlsDAO objAgaramtechControlsDAO;

	public AgaramtechControlsDAO getObjAgaramtechControlsDAO() {
		return objAgaramtechControlsDAO;
	}

	public void setObjAgaramtechControlsDAO(
			AgaramtechControlsDAO objAgaramtechControlsDAO) {
		this.objAgaramtechControlsDAO = objAgaramtechControlsDAO;
	}


	@Override
	public List<SampleType> getSampleType() 
	{
		try{
			return objAgaramtechControlsDAO.getSampleType();
		}catch(Exception e){
			logging.error(e.getMessage());
			logging.error(e.getCause());
			logging.error(e.getLocalizedMessage());
			return null;
		}

	}

	@Override
	public List<ExportSampleType> getExportSampleType(int nSampleTypeCode){
		return objAgaramtechControlsDAO.getExportSampleType(nSampleTypeCode);
	}

	/** * @author Kadher Moideen S * * Aug 10, 2012 5:19:04 PM */

	@Override
	public List<DesignMaster> getFormDesign(int nSampleTypeCode){
		List<DesignMaster> lst = null ;
		try{
			lst= objAgaramtechControlsDAO.getFormDesign(nSampleTypeCode);
		}catch(Exception e){
			logging.error(e.getMessage());
			logging.error(e.getCause());
			logging.error(e.getLocalizedMessage());

		}
		return lst;
	}
	@Override
	public List<ComponentMaster> getComponents(){
		List<ComponentMaster> lst = null ;
		try{
			lst=  objAgaramtechControlsDAO.getComponents();
		}catch(Exception e){
			logging.error(e.getMessage());
			logging.error(e.getCause());
			logging.error(e.getLocalizedMessage());

		}
		return lst;
	}

	@Override
	public List<ExistingLinkTable> getExistingTablesName(){
		List<ExistingLinkTable> lst = null ;
		try{
			lst=  objAgaramtechControlsDAO.getExistingTablesName();
		}catch(Exception e){
			logging.error(e.getMessage());
			logging.error(e.getCause());
			logging.error(e.getLocalizedMessage());

		}
		return lst;
	}
	@Override
	public Map<String,Map<Integer, List>> getExistingLinkTables(String sExistsLinkCode){
		Map<String,Map<Integer, List>> lst = null ;
		try{
			lst=  objAgaramtechControlsDAO.getExistingLinkTables(sExistsLinkCode);
		}catch(Exception e){
			logging.error(e.getMessage());
			logging.error(e.getCause());
			logging.error(e.getLocalizedMessage());

		}
		return lst;
	}
	@Override
	public Map<String,Map<Integer, List>> getExistingLinkTables(String sExistsLinkCode,int nsampletype,int nexportsampletype){
		Map<String,Map<Integer, List>> lst = null ;
		try{
			lst=  objAgaramtechControlsDAO.getExistingLinkTables(sExistsLinkCode,nsampletype,nexportsampletype);
		}catch(Exception e){
			logging.error(e.getMessage());
			logging.error(e.getCause());
			logging.error(e.getLocalizedMessage());

		}
		return lst;
	}
	@Override
	public Map<String,Map<String, List>> getExistingLinkQuerys(List<DesignMasterJoins> lstExistsLink){
		Map<String,Map<String, List>> lst = null ;
		try{
			lst=  objAgaramtechControlsDAO.getExistingLinkQuerys(lstExistsLink);
		}catch(Exception e){
			logging.error(e.getMessage());
			logging.error(e.getCause());
			logging.error(e.getLocalizedMessage());

		}
		return lst;
	}
	@Override
	public List<CustomLinkTable>getCustomLinkTables(String sDesignCode){
		List<CustomLinkTable> lst = null ;
		try{
			lst=  objAgaramtechControlsDAO.getCustomLinkTables(sDesignCode);
		}catch(Exception e){
			logging.error(e.getMessage());
			logging.error(e.getCause());
			logging.error(e.getLocalizedMessage());

		}
		return lst;
	}

	@Override
	public List<DesignMaster> insertFormDesign(List<DesignMaster> lstDesignMasters,List<CustomLinkTable> lstCustomLinkTables,int nSampleTypeCode){

		List<DesignMaster> lst = null ;
		try{
			objAgaramtechControlsDAO.insertFormDesign(lstDesignMasters, lstCustomLinkTables);
			lst= objAgaramtechControlsDAO.getFormDesign(nSampleTypeCode);
		}catch(Exception e){
			logging.error(e.getMessage());
			logging.error(e.getCause());
			logging.error(e.getLocalizedMessage());

		}
		return lst;
	}

	@Override
	public List<TableFields> getTableFields(int nTableCode){
		List<TableFields> lst = null ;
		try{
			lst=  objAgaramtechControlsDAO.getTableFields(nTableCode);
		}catch(Exception e){
			logging.error("getJasperDynamicFields e.getMessage() ------------>"+e.getMessage());
			logging.error("getJasperDynamicFields e.getCause() ------------>"+e.getCause());
			logging.error("getJasperDynamicFields e.getLocalizedMessage() ------------>"+e.getLocalizedMessage());

		}
		return lst;
	}
	@Override
	public List<TableFields> insertUpdateTableFields(TableFields objDynamicFields){
		List<TableFields> lst = null ;
		try{
			objAgaramtechControlsDAO.insertUpdateTableFields(objDynamicFields);
			lst=  objAgaramtechControlsDAO.getTableFields(objDynamicFields.getntablecode());
		}catch(Exception e){
			logging.error(e.getMessage());
			logging.error(e.getCause());
			logging.error(e.getLocalizedMessage());

		}
		return lst;
	}

	@Override
	public List<DesignMasterJoins> getDynamicDesignFields(int nSampleTypeCode,int nTreeNodeCode){
		List<DesignMasterJoins> lst = null ;
		try{
			lst=  objAgaramtechControlsDAO.getDynamicDesignFields(nSampleTypeCode,nTreeNodeCode);
		}catch(Exception e){
			logging.error(e.getMessage());
			logging.error(e.getCause());
			logging.error(e.getLocalizedMessage());

		}
		return lst;
	}

	@Override
	public List<TableNames> getTableNames(){
		List<TableNames> lst = null ;
		try{
			lst=  objAgaramtechControlsDAO.getTableNames();
		}catch(Exception e){
			logging.error(e.getMessage());
			logging.error(e.getCause());
			logging.error(e.getLocalizedMessage());

		}
		return lst;
	}

	@Override
	public Map<String,Object> insertDynamicFields(List<flex.messaging.io.amf.ASObject> lObjects,flex.messaging.io.amf.ASObject objPrimary,int nprimarycode,int nsecondarycode,int nregistercode)throws Exception{

		try{
			return objAgaramtechControlsDAO.insertDynamicFields(lObjects,objPrimary,nprimarycode,nsecondarycode,nregistercode);
		}catch(Exception e){
			logging.error(e.getMessage());
			logging.error(e.getCause());
			logging.error(e.getLocalizedMessage());
			return  null;
		}		

	}

	@Override
	public List<TableColumnNames> getTableColumns(String sTableName) {
		try{
			return objAgaramtechControlsDAO.getTableColumns(sTableName);
		}catch(Exception e){
			logging.error(e.getMessage());
			logging.error(e.getCause());
			logging.error(e.getLocalizedMessage());
			return  null;
		}	
	}
}

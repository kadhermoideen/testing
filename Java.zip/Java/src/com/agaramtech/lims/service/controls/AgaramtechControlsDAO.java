package com.agaramtech.lims.service.controls;

import java.util.List;
import java.util.Map;

import com.agaramtech.lims.controls.ComponentMaster;
import com.agaramtech.lims.controls.CustomLinkTable;
import com.agaramtech.lims.controls.DesignMaster;
import com.agaramtech.lims.controls.DesignMasterJoins;
import com.agaramtech.lims.controls.ExistingLinkTable;
import com.agaramtech.lims.controls.ExportSampleType;
import com.agaramtech.lims.controls.SampleType;
import com.agaramtech.lims.controls.TableColumnNames;
import com.agaramtech.lims.controls.TableFields;
import com.agaramtech.lims.controls.TableNames;
@SuppressWarnings("rawtypes")
public interface AgaramtechControlsDAO {
	/** * @author Kadher Moideen S * * Aug 10, 2012 5:19:04 PM */



	public List<SampleType> getSampleType();
	public List<ExportSampleType> getExportSampleType(int nSampleTypeCode);
	public List<DesignMaster> getFormDesign(int nSampleTypeCode);
	public List<DesignMasterJoins> getDynamicDesignFields(int nSampleTypeCode,int nTreeNodeCode);
	public List<ComponentMaster> getComponents();
	public Map<String,Map<Integer, List>> getExistingLinkTables(String sExistsLinkCode);
	public Map<String,Map<Integer, List>> getExistingLinkTables(String sExistsLinkCode,int nsampletype,int nexportsampletype);
	public Map<String,Map<String, List>> getExistingLinkQuerys(List<DesignMasterJoins> lstExistsLink);
	public List<ExistingLinkTable> getExistingTablesName();
	public List<CustomLinkTable> getCustomLinkTables(String sDesignCode);
	public void insertFormDesign(List<DesignMaster> lstDesignMasters,List<CustomLinkTable> lstCustomLinkTables);
	public List<TableFields> getTableFields(int nTableCode);
	public void insertUpdateTableFields(TableFields objDynamicFields);
	public List<TableNames> getTableNames();
	public Map<String,Object> insertDynamicFields(List<flex.messaging.io.amf.ASObject> lObjects,flex.messaging.io.amf.ASObject objPrimary,int nprimarycode,int nsecondarycode,int nregistercode)throws Exception;
	public List<TableColumnNames> getTableColumns(String sTableName);
	
	public void insertDynamicFields(List<flex.messaging.io.amf.ASObject> lstObjects,String strmaster) throws Exception;
}

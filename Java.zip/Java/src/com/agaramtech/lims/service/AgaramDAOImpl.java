/**
 *
 *Kadher
 *
 * 02-Jan-2014
 *
 */
package com.agaramtech.lims.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.transaction.annotation.Transactional;

import com.agaramtech.lims.controls.TableNames;
import com.agaramtech.lims.dao.support.AgaramDaoSupport;
import com.agaramtech.lims.dao.support.bridge.RDBMSBridge;
import com.agaramtech.lims.dao.support.bridge.RDBMSParameter;
import com.agaramtech.lims.dao.support.enums.RDBMSEnum;
import com.agaramtech.lims.dao.support.enums.Status;
import com.agaramtech.lims.dao.support.global.AgaramtechGeneralfunction;
import com.agaramtech.lims.tree.AgaramTree;
import com.agaramtech.lims.tree.TableNamesSub;

/**
 * @author Kadher
 *
 */
@Transactional
public class AgaramDAOImpl extends AgaramDaoSupport implements AgaramDAO{
	final Log logging = LogFactory.getLog(AgaramDAOImpl.class);

	private static int dataBaseType = 0;
	private final AgaramtechGeneralfunction objGeneral;

	public AgaramDAOImpl(RDBMSParameter objParameter,AgaramtechGeneralfunction objGeneral) {
		super(objParameter,objGeneral);
		if(objParameter.getsdatabasetype().equals(RDBMSEnum.DB_MYSQL.getDataBaseType())) {
			dataBaseType = RDBMSEnum.DB_MYSQL.getType();
		} else if(objParameter.getsdatabasetype().equals(RDBMSEnum.DB_POSTGRESQL.getDataBaseType())) {
			dataBaseType = RDBMSEnum.DB_POSTGRESQL.getType();
		} else if(objParameter.getsdatabasetype().equals(RDBMSEnum.DB_MICROSOFT_SQL_SERVER.getDataBaseType())) {
			dataBaseType = RDBMSEnum.DB_MICROSOFT_SQL_SERVER.getType();
		} else if(objParameter.getsdatabasetype().equals(RDBMSEnum.DB_ORACLE.getDataBaseType())) {
			dataBaseType = RDBMSEnum.DB_ORACLE.getType();
		}

		this.objGeneral = objGeneral;
		RDBMSBridge.dataBaseType = dataBaseType;
	}

	private String formTreeNode(List<AgaramTree> lst){
		String st;

		String stXml="";

		AgaramTree item1 = new AgaramTree();
		AgaramTree item2 = new AgaramTree();

		int j = 0;

		while(j < lst.size() )
		{
			item1=lst.get(j);

			if ((j+item1.getnparent()-1)<lst.size())
			{
				item2=lst.get(j+item1.getnparent()-1);

				if(item1.getnrank()==1)
				{
					st = "</node>" + item2.getsclose();
					item2.setsclose(st);
				}

				lst.set(j+item1.getnparent()-1,item2);
			}

			j++;

			if(item1.getschild() == null || item1.getschild().compareToIgnoreCase("") == 0) {
				stXml = stXml + item1.getsparent() + item1.getsclose();
			} else {
				stXml = stXml + item1.getsparent() + item1.getschild() + item1.getsclose();
			}
		}

		return stXml;
	}
	@Override
	public AgaramTree getTree(int nPrimaryId,int nSiteCode,String viewName) throws Exception
	{

		AgaramTree ag = new AgaramTree();
		List<AgaramTree> lst = (List<AgaramTree>) findBySinglePlainSql("select nchild,nparent,sparent,schild,sclose,nrank from "+viewName+"  order by nrownum",AgaramTree.class);

		ag.setsxml(formTreeNode(lst));
		return ag;
	}

	@Override
	public AgaramTree getTree(int nPrimaryId,String viewName,int nTableCode) throws Exception
	{
		AgaramTree ag = new AgaramTree();
		List<AgaramTree> lst = (List<AgaramTree>) findBySinglePlainSql("select nchild,nparent,sparent,schild,sclose,nrank from "+viewName+"  order by nrownum",AgaramTree.class);

		List<TableNamesSub> lstTableNamesSubs = (List<TableNamesSub>) findBySinglePlainSql("select * from tablenamessub where nsubtablecode in( select nsubtablecode from tablenames where ntablecode = "+nTableCode+")", TableNamesSub.class);
		if(lstTableNamesSubs != null && lstTableNamesSubs.size() > 0)
		{

			List<AgaramTree> lstTreeChild = (List<AgaramTree>) findBySinglePlainSql("select * from "+viewName+" where "+lstTableNamesSubs.get(0).getschildcolumn()+" = "+nPrimaryId,AgaramTree.class);
			if(lstTreeChild != null && lstTreeChild.size() > 0)
			{
				int rowNum = lstTreeChild.get(0).getnrownum();
				if(lstTreeChild.get(0).getnchild() >= 1 )
				{
					int topCount = lstTreeChild.get(0).getnchild()+1;

					if(lstTreeChild.get(0).getschild() == null || lstTreeChild.get(0).getschild().equals(""))
					{
						rowNum ++;
						topCount--;
					}
					String str  = "select  top "+topCount+" * from "+viewName+" where nrownum >= "+rowNum+" order by nrownum";
					List<AgaramTree> lstTreeChildHierarchy = (List<AgaramTree>) findBySinglePlainSql(str,AgaramTree.class) ;
					if(lstTreeChildHierarchy != null && lstTreeChildHierarchy.size() > 0)
					{
						ag.setsxml(formTreeNode(lstTreeChildHierarchy));
					}
				}
				else  if(lstTreeChild.get(0).getnchild() == 0 )
				{
					//	ag.setsxml(formTreeNode(lstTreeChild));
					if(lstTreeChild.size() == 1 )
					{
						ag.setsxml(lstTreeChild.get(0).getschild());	
					}
					else
					{
						ag.setsxml(formTreeNode(lstTreeChild));
					}
				}
			}
		}

		return ag;
	}

	@Override
	public int copyOrCutTreeNode(int nParentCode,int nChildCode,int nType,int nTableCode,String sViewName,boolean masterNode) throws Exception
	{
		int rtnId = 0;
		if(nType == 0)/////If nType == 0 it is cut
		{
			rtnId = cutTreeNode(nParentCode,nChildCode,nTableCode,masterNode);
		}
		else if(nType > 0)/////If nType >0 it is copy
		{
			rtnId = copyTreeNode(nParentCode,nChildCode,nTableCode,sViewName);
		}
		else if(nType == -1)/////If nType == -1 it is delete
		{
			rtnId = removeTreeNode(nParentCode,nChildCode,nTableCode,sViewName);
		}

		return rtnId;
	}

	private int removeTreeNode(int nParentCode,int nChildCode,int nTableCode,String sViewName) throws Exception
	{
		StringBuffer sbMaster = null;
		StringBuffer sbLevelParent = new StringBuffer();
		StringBuffer sbLevelChild = new StringBuffer();

		List<TableNames> lstTableNames = (List<TableNames>) findBySinglePlainSql("select * from tablenames where ntablecode = "+nTableCode, TableNames.class);
		if(lstTableNames != null && lstTableNames.size() > 0 && lstTableNames.get(0).getnhassub() > 0)
		{
			List<TableNamesSub> lstTableNamesSubs = (List<TableNamesSub>) findBySinglePlainSql("select * from tablenamessub where nsubtablecode = "+lstTableNames.get(0).getnsubtablecode(), TableNamesSub.class);
			if(lstTableNamesSubs != null && lstTableNamesSubs.size() > 0)
			{
				Object classTableName = Class.forName(lstTableNames.get(0).getsclassname()).newInstance();
				Object classTableNameSub = Class.forName(lstTableNamesSubs.get(0).getssubclassname()).newInstance();
				if(classTableName != null && classTableNameSub != null)
				{
					List<AgaramTree> lstTreeChild = (List<AgaramTree>) findBySinglePlainSql("select * from "+sViewName+" where "+lstTableNamesSubs.get(0).getschildcolumn()+" = "+nChildCode,AgaramTree.class);
					if(lstTreeChild != null && lstTreeChild.size() > 0)
					{
						//String str = "select  top "+lstTreeChild.get(0).getnchild()+" "+lstTableNamesSubs.get(0).getschildcolumn()+" as nchildcode, "+lstTableNamesSubs.get(0).getsparentcolumn()+" as nparentcode from "+sViewName+" where "+lstTableNamesSubs.get(0).getsparentcolumn()+" >= "+nChildCode+" order by nrownum";
						int topCount = lstTreeChild.get(0).getnchild()+1;
						String str = "select  top "+topCount+" "+lstTableNamesSubs.get(0).getschildcolumn()+" as nchildcode, "+lstTableNamesSubs.get(0).getsparentcolumn()+" as nparentcode from "+sViewName+" where "+lstTableNamesSubs.get(0).getschildcolumn()+" >= "+nChildCode+" order by nrownum desc";
						List<AgaramTree> lstTreeChildHierarchy = (List<AgaramTree>) findBySinglePlainSql(str,AgaramTree.class) ;

						if(lstTreeChildHierarchy != null && lstTreeChildHierarchy.size() > 0)
						{
							for(AgaramTree obj : lstTreeChildHierarchy)
							{
								if(sbMaster == null)
								{
									sbMaster = new StringBuffer();
									sbMaster.append(",");
									sbMaster.append(obj.getnparentcode());
								}

								sbMaster.append(",");
								sbMaster.append(obj.getnchildcode());
								sbLevelParent.append(",");
								sbLevelChild.append(",");
								sbLevelParent.append(obj.getnparentcode());
								sbLevelChild.append(obj.getnchildcode());
							}
						}
						else if(lstTreeChildHierarchy != null && lstTreeChildHierarchy.size() == 0)
						{
							String strChildUpdate = "update "+lstTableNamesSubs.get(0).getssubclassname() +" set nstatus = "+Status.DEACTIVE.getstatus()+" where nstatus = "+Status.ACTIVE.getstatus()+" and "+lstTableNamesSubs.get(0).getschildcolumn()+" = "+nChildCode;
							getHibernateTemplate().bulkUpdate(strChildUpdate);

							String strParentUpdate = "update "+lstTableNames.get(0).getsclassname() +" set nstatus = "+Status.DEACTIVE.getstatus()+" where nstatus = "+Status.ACTIVE.getstatus()+" and "+lstTableNames.get(0).getsprimarycolumn()+" = "+nChildCode;
							getHibernateTemplate().bulkUpdate(strParentUpdate);
						}
						String strMaster = "";
						if(sbMaster != null)
						{		
							strMaster = sbMaster.toString();
						}
						String strLevelParent = sbLevelParent.toString();
						String strLevelChild = sbLevelChild.toString();

						if(strMaster != null && strMaster.trim().length() > 0 && strLevelParent.trim().length() > 0 && strLevelChild.trim().length() > 0) 
						{
							strMaster = strMaster.substring(1,strMaster.length());
							strLevelParent = strLevelParent.substring(1,strLevelParent.length());
							strLevelChild = strLevelChild.substring(1,strLevelChild.length());
							String strUpdate = "update "+lstTableNamesSubs.get(0).getssubclassname() +" set nstatus = "+Status.DEACTIVE.getstatus()+" where nstatus = "+Status.ACTIVE.getstatus()+" and "+lstTableNamesSubs.get(0).getsparentcolumn()+" in ("+strLevelParent+") and "+lstTableNamesSubs.get(0).getschildcolumn()+" in ("+strLevelChild+")";
							getHibernateTemplate().bulkUpdate(strUpdate);

							String strMasterUpdate = "update "+lstTableNames.get(0).getsclassname() +" set nstatus = "+Status.DEACTIVE.getstatus()+" where nstatus = "+Status.ACTIVE.getstatus()+" and "+lstTableNames.get(0).getsprimarycolumn()+" in ("+strMaster+")";
							getHibernateTemplate().bulkUpdate(strMasterUpdate);
						}
					}
				}
			}
		}
		return 0;
	}
	private int cutTreeNode(int nParentCode,int nChildCode,int nTableCode,boolean masterNode) throws Exception
	{
		List<TableNames> lstTableNames = (List<TableNames>) findBySinglePlainSql("select * from tablenames where ntablecode = "+nTableCode, TableNames.class);
		if(lstTableNames != null && lstTableNames.size() > 0 && lstTableNames.get(0).getnhassub() > 0)
		{
			if(masterNode)
			{
//				insertUpdateSubTables(nParentCode,nChildCode,lstTableNames);
			}
			else
			{
				List<TableNamesSub> lstTableNamesSubs = (List<TableNamesSub>) findBySinglePlainSql("select * from tablenamessub where nsubtablecode = "+lstTableNames.get(0).getnsubtablecode(), TableNamesSub.class);
				if(lstTableNamesSubs != null && lstTableNamesSubs.size() > 0)
				{
					Object classTableNameSub = Class.forName(lstTableNamesSubs.get(0).getssubclassname()).newInstance();

					List<?> lstLevel = getHibernateTemplate().find("from "+classTableNameSub.getClass().getSimpleName()+" where "+lstTableNamesSubs.get(0).getschildcolumn()+" = "+nChildCode+" and nstatus = "+Status.ACTIVE.getstatus());
					if(lstLevel.size() > 0 && lstTableNamesSubs.get(0).getsprimarycolumn() != null){
						for(Object objLevel : lstLevel){
							int primaryValue = (int) (AgaramtechGeneralfunction.findColumnName(objLevel,lstTableNamesSubs.get(0).getsprimarycolumn()));
							getHibernateTemplate().bulkUpdate("update "+classTableNameSub.getClass().getSimpleName()+" set "+lstTableNamesSubs.get(0).getsparentcolumn()+" = "+nParentCode+" where "+lstTableNamesSubs.get(0).getsprimarycolumn()+" = "+primaryValue);
						}
					}
					else{
						//	return Enumerations.RETURNSTATUS.RECORD_ALREADY_DELETED.getstatus();
					}
				}
			}

		}
		return nChildCode;
	}


	@SuppressWarnings("unchecked")
	private int copyTreeNode(int nParentCode,int nChildCode,int nTableCode,String sViewName) throws Exception
	{
		logging.info("nParentCode "+nParentCode);
		logging.info("nChildCode "+nChildCode);

		List<Object> lstFinalClassTable = null;
		int rtnId = 0;
		if(sViewName != null)
		{
			List<TableNames> lstTableNames = (List<TableNames>) findBySinglePlainSql("select * from tablenames where ntablecode = "+nTableCode, TableNames.class);
			if(lstTableNames != null && lstTableNames.size() > 0)
			{
				List<TableNamesSub> lstTableNamesSubs = (List<TableNamesSub>) findBySinglePlainSql("select * from tablenamessub where nsubtablecode = "+lstTableNames.get(0).getnsubtablecode(), TableNamesSub.class);

				if(lstTableNamesSubs != null && lstTableNamesSubs.size() > 0)
				{
					Object classTableName = Class.forName(lstTableNames.get(0).getsclassname()).newInstance();
					Object classTableNameSub = Class.forName(lstTableNamesSubs.get(0).getssubclassname()).newInstance();

					List<AgaramTree> lstTreeChild = (List<AgaramTree>) findBySinglePlainSql("select * from "+sViewName+" where "+lstTableNamesSubs.get(0).getschildcolumn()+" = "+nChildCode,AgaramTree.class);
					if(lstTreeChild != null && lstTreeChild.size() > 0)
					{
						int seqClassTableNo = 0;
						seqClassTableNo = objGeneral.lockRunningMaker(classTableName);
						seqClassTableNo++;

						int seqClassTableSubNo = objGeneral.lockRunningMaker(classTableNameSub);
						seqClassTableSubNo++;

						rtnId = seqClassTableSubNo;

						List<?> lstObject = getHibernateTemplate().find("from "+lstTableNames.get(0).getsclassname()+" where "+lstTableNames.get(0).getsprimarycolumn()+" = "+nChildCode);
						objGeneral.setPrivateFieldsMultiple(classTableName,lstTableNames.get(0).getsprimarycolumn(),String.valueOf(seqClassTableNo),lstTableNames.get(0).getsuniquecolumn(),lstObject,objGeneral);

						objGeneral.setPrivateFieldsTreeSub(classTableNameSub,lstTableNamesSubs.get(0).getsprimarycolumn(),String.valueOf(seqClassTableSubNo),lstTableNamesSubs.get(0).getsparentcolumn(),String.valueOf(nParentCode),lstTableNamesSubs.get(0).getschildcolumn(),String.valueOf(seqClassTableNo),objGeneral);

						if(lstFinalClassTable == null)
							lstFinalClassTable = new ArrayList<Object>();

						lstFinalClassTable.add(classTableName);
						lstFinalClassTable.add(classTableNameSub);

						if(lstTreeChild.get(0).getnchild() > 0)
						{
							List<AgaramTree> lstTreeChildHierarchy = (List<AgaramTree>) findBySinglePlainSql("select  top "+lstTreeChild.get(0).getnchild()+" * from "+sViewName+" where "+lstTableNamesSubs.get(0).getsparentcolumn()+" >= "+nChildCode+" order by nrownum",AgaramTree.class) ;
							if(lstTreeChildHierarchy != null)
							{
								for(AgaramTree obj : lstTreeChildHierarchy)
								{
									//lstObject = getHibernateTemplate().find("from "+lstTableNames.get(0).getsclassname()+" where "+lstTableNames.get(0).getsprimarycolumn()+" in( select "+lstTableNames.get(0).getsprimarycolumn()+" from "+lstTableNames.get(0).getsclassname()+" where "+lstTableNames.get(0).getsprimarycolumn()+" = "+obj.getnrownum()+")");

									lstTreeChild = (List<AgaramTree>) findBySinglePlainSql("select "+lstTableNamesSubs.get(0).getschildcolumn()+" as nsecondid from "+sViewName+" where nrownum = "+obj.getnrownum(),AgaramTree.class) ;
									if(lstTreeChild.size() > 0)
									{			
										lstObject = getHibernateTemplate().find("from "+lstTableNames.get(0).getsclassname()+" where "+lstTableNames.get(0).getsprimarycolumn()+" = "+lstTreeChild.get(0).getnsecondid());

										if(lstObject.size() > 0)
										{
											classTableName = Class.forName(lstTableNames.get(0).getsclassname()).newInstance();
											classTableNameSub = Class.forName(lstTableNamesSubs.get(0).getssubclassname()).newInstance();

											seqClassTableSubNo++;

											objGeneral.setPrivateFieldsTreeSub(classTableNameSub,lstTableNamesSubs.get(0).getsprimarycolumn(),String.valueOf(seqClassTableSubNo),lstTableNamesSubs.get(0).getsparentcolumn(),String.valueOf(seqClassTableNo),lstTableNamesSubs.get(0).getschildcolumn(),String.valueOf(seqClassTableNo+1),objGeneral);
											seqClassTableNo++;

											objGeneral.setPrivateFieldsMultiple(classTableName,lstTableNames.get(0).getsprimarycolumn(),String.valueOf(seqClassTableNo),lstTableNames.get(0).getsuniquecolumn(),lstObject,objGeneral);

											//	objGeneral.setPrivateFieldsTreeSub(classTableNameSub,lstTableNamesSubs.get(0).getsprimarycolumn(),String.valueOf(seqClassTableNo),lstTableNamesSubs.get(0).getsparentcolumn(),String.valueOf(seqClassTableNo),lstTableNamesSubs.get(0).getschildcolumn(),String.valueOf(seqClassTableNo),objGeneral);
											lstFinalClassTable.add(classTableName);
											lstFinalClassTable.add(classTableNameSub);
										}
									}
								}

								//	insertUpdateSubTables(nParentCode,nChildCode,lstTableNames);
							}
						}
						objGeneral.updateRunningMaker(seqClassTableNo,classTableName);
						objGeneral.updateRunningMaker(seqClassTableSubNo,classTableNameSub);

						if(lstFinalClassTable.size() > 0)
						{
							for(Object obj : lstFinalClassTable)
							{
								getHibernateTemplate().save(obj);
							}
						}
					}
				}
			}
		}
		return rtnId;
	}

//	private void insertUpdateSubTables(int nParentCode,int nChildCode,List<TableNames> lstTableNames) throws Exception
//	{
//
//		List<StorageMaster> lstStorageMasters = getHibernateTemplate().find("from StorageMaster where nmastercode = "+nChildCode);
//
//		String queryBatch = "select * from storagemaster where nunitcode in (select nunitcode from batchsamplemapping bsm1 where exists "
//				+ " (select 1 from batchsamplemapping bsm2 where bsm1.nbatchcode = bsm2.nbatchcode and nunitcode = "+lstStorageMasters.get(0).getnunitcode()+"))";
//
//		List<StorageMaster> lstStorageMaster = (List<StorageMaster>) findBySinglePlainSql(queryBatch, StorageMaster.class);
//		StringBuffer sbUnitCode = null;
//		if(lstStorageMaster != null && lstStorageMaster.size() > 0)
//		{
//
//
//
//			//Code in unit inventory to change the container and well starts
//			for(StorageMaster objStorageMaster : lstStorageMaster){
//				if(sbUnitCode == null)
//				{
//					sbUnitCode = new StringBuffer();
//					sbUnitCode.append(objStorageMaster.getnunitcode());
//				}
//				else
//				{
//					sbUnitCode.append(",");
//					sbUnitCode.append(objStorageMaster.getnunitcode());
//				}
//			}
//			List<UnitInventory> lstUnitInventories = getHibernateTemplate().find("from UnitInventory where nunitcode in ("+sbUnitCode.toString()+")");
//
//			List<StorageMaster> lstMasters =  (List<StorageMaster>) findBySinglePlainSql("select ncontainercode from storagemaster where nmastercode = "+nParentCode, StorageMaster.class);
//
//			if(lstUnitInventories != null && lstUnitInventories.size() > 0 && lstMasters != null && lstMasters.size() > 0)
//			{
//				List<StorageUnitMapping> lstStorageUnitMappings = getHibernateTemplate().find("from StorageUnitMapping where nlastcontainercode = "+lstMasters.get(0).getncontainercode());	
//				if(lstStorageUnitMappings != null && lstStorageUnitMappings.size() > 0 )
//				{
//					List<LabwareFormatDetail> lstFormatDetails =  (List<LabwareFormatDetail>) findBySinglePlainSql("select nlabwareformatdetailcode,nserialno from labwareformatdetail where nserialno > "+lstStorageUnitMappings.get(0).getnlastposition()+" and nlabwareformatcode = "+lstStorageUnitMappings.get(0).getnlabwareformatcode(), LabwareFormatDetail.class);
//
//					if(lstFormatDetails.size() >= lstUnitInventories.size())
//					{
//						int position  = 0;
//						for(int index=0;index<lstUnitInventories.size();index++)
//						{
//							getHibernateTemplate().bulkUpdate("update UnitInventory set ncontainercode = "+lstMasters.get(0).getncontainercode()+", nposition = "+lstFormatDetails.get(index).getnserialno()+" where nunitcode = "+lstUnitInventories.get(index).getnunitcode());
//							position = lstFormatDetails.get(index).getnserialno();;
//						}
//
//						getHibernateTemplate().bulkUpdate("update StorageUnitMapping set nlastposition = "+position+" where nstorageunitmappingcode = "+lstStorageUnitMappings.get(0).getnstorageunitmappingcode());
//
//						if(position == lstFormatDetails.get(lstFormatDetails.size()-1).getnserialno())
//						{
//							getHibernateTemplate().bulkUpdate("update ContainerMaster set ncontainerstatus = "+Enumerations.TransactionStatus.USED_CONTAINER+" where ncontainercode = "+lstMasters.get(0).getncontainercode());
//						}
//
//
//						//Moving unit in container starts
//						for(StorageMaster objStorageMaster : lstStorageMaster){
//							List<TableNamesSub> lstTableNamesSubs = (List<TableNamesSub>) findBySinglePlainSql("select * from tablenamessub where nsubtablecode = "+lstTableNames.get(0).getnsubtablecode(), TableNamesSub.class);
//							if(lstTableNamesSubs != null && lstTableNamesSubs.size() > 0)
//							{
//								Object classTableNameSub = Class.forName(lstTableNamesSubs.get(0).getssubclassname()).newInstance();
//
//								List<?> lstLevel = getHibernateTemplate().find("from "+classTableNameSub.getClass().getSimpleName()+" where "+lstTableNamesSubs.get(0).getschildcolumn()+" = "+objStorageMaster.getnmastercode()+" and nstatus = "+Enumerations.Status.STATUS_ACTIVE.status());
//								if(lstLevel.size() > 0 && lstTableNamesSubs.get(0).getsprimarycolumn() != null){
//									for(Object objLevel : lstLevel){
//										int primaryValue = (int) (AgaramtechGeneralfunction.findColumnName(objLevel,lstTableNamesSubs.get(0).getsprimarycolumn()));
//										getHibernateTemplate().bulkUpdate("update "+classTableNameSub.getClass().getSimpleName()+" set "+lstTableNamesSubs.get(0).getsparentcolumn()+" = "+nParentCode+" where "+lstTableNamesSubs.get(0).getsprimarycolumn()+" = "+primaryValue);
//									}
//								}
//								else{
//									//	return Enumerations.RETURNSTATUS.RECORD_ALREADY_DELETED.getstatus();
//								}
//							}
//
//
//						}
//						//Moving unit in container starts
//					}
//				}
//			}
//			//Code in unit inventory to change the container and well ends
//		}
//	}
}

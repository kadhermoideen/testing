/**
 *
 *Kadher
 *
 * 02-Jan-2014
 *
 */
package com.agaramtech.lims.service;

import com.agaramtech.lims.tree.AgaramTree;

/**
 * @author Kadher
 *
 */
public interface AgaramService {
	public AgaramTree getTree(int nPrimaryId,int nSiteCode,String viewName);
	public AgaramTree copyOrCutTreeNode(int nParentCode,int nChildCode,int nType,int nTableCode,String sViewName,boolean masterNode);
}

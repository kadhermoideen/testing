/**
 *
 *Kadher
 *
 * 02-Jan-2014
 *
 */
package com.agaramtech.lims.service;

import com.agaramtech.lims.tree.AgaramTree;

/**
 * @author Kadher
 *
 */
public interface AgaramDAO {
	public AgaramTree getTree(int nPrimaryId,int nSiteCode,String viewName) throws Exception;
	public AgaramTree getTree(int nPrimaryId,String viewName,int nTableCode) throws Exception;
	public int copyOrCutTreeNode(int nParentCode,int nChildCode,int nType,int nTableCode,String sViewName,boolean masterNode) throws Exception;
}

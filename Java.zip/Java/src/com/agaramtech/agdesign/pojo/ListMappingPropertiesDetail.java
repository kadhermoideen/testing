package com.agaramtech.agdesign.pojo;

import java.io.Serializable;
import java.sql.SQLException;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.agaramtech.lims.dao.support.AgaramResultSetMapper;
import com.agaramtech.lims.dao.support.AgaramRowMapper;

@Entity
@Table(name="listmappingpropertiesdetail")
@SuppressWarnings("serial")
public class ListMappingPropertiesDetail implements Serializable ,AgaramRowMapper<ListMappingPropertiesDetail> {

	@Id
	@Column(name = "nlistmappingpropertiesdetailcode")private int nlistmappingpropertiesdetailcode;
	@Column(name = "ntemplatecomponentdetaillcode")private int ntemplatecomponentdetaillcode; 
	@Column(name = "ntemplatesubcomponentdetailcode")private int ntemplatesubcomponentdetailcode;
	@Column(name = "ntemplatecomponenteventdetailcode")private int ntemplatecomponenteventdetailcode;
	@Column(name = "npropertiescode")private int npropertiescode;
	@Column(name = "spropertiesvalue")private String spropertiesvalue;
	@Column(name = "nstatus")private int nstatus;
	

	public int getnlistmappingpropertiesdetailcode() {
		return nlistmappingpropertiesdetailcode;
	}

	public void setnlistmappingpropertiesdetailcode(
			int nlistmappingpropertiesdetailcode) {
		this.nlistmappingpropertiesdetailcode = nlistmappingpropertiesdetailcode;
	}

	public int getntemplatecomponentdetaillcode() {
		return ntemplatecomponentdetaillcode;
	}

	public void setntemplatecomponentdetaillcode(int ntemplatecomponentdetaillcode) {
		this.ntemplatecomponentdetaillcode = ntemplatecomponentdetaillcode;
	}

	public int getntemplatesubcomponentdetailcode() {
		return ntemplatesubcomponentdetailcode;
	}

	public void setntemplatesubcomponentdetailcode(
			int ntemplatesubcomponentdetailcode) {
		this.ntemplatesubcomponentdetailcode = ntemplatesubcomponentdetailcode;
	}

	public int getntemplatecomponenteventdetailcode() {
		return ntemplatecomponenteventdetailcode;
	}

	public void setntemplatecomponenteventdetailcode(
			int ntemplatecomponenteventdetailcode) {
		this.ntemplatecomponenteventdetailcode = ntemplatecomponenteventdetailcode;
	}

	public int getnpropertiescode() {
		return npropertiescode;
	}

	public void setnpropertiescode(int npropertiescode) {
		this.npropertiescode = npropertiescode;
	}

	public String getspropertiesvalue() {
		return spropertiesvalue;
	}

	public void setspropertiesvalue(String spropertiesvalue) {
		this.spropertiesvalue = spropertiesvalue;
	}

	public int getnstatus() {
		return nstatus;
	}

	public void setnstatus(int nstatus) {
		this.nstatus = nstatus;
	}

	@Override
	public String isActiveFilter(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {
		objMapper.setfield("nstatus");
		objMapper.setvalue(1);
		return objMapper.toString();

	}

	@Override
	public ListMappingPropertiesDetail mapRow(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {
		ListMappingPropertiesDetail objListMappingPropertiesDetail = new ListMappingPropertiesDetail();
		objListMappingPropertiesDetail.setnlistmappingpropertiesdetailcode(objMapper.getInteger("nlistmappingpropertiesdetailcode"));
		objListMappingPropertiesDetail.setntemplatecomponentdetaillcode(objMapper.getInteger("ntemplatecomponentdetaillcode"));
		objListMappingPropertiesDetail.setntemplatesubcomponentdetailcode(objMapper.getInteger("ntemplatesubcomponentdetailcode"));
		objListMappingPropertiesDetail.setnpropertiescode(objMapper.getInteger("npropertiescode"));
		objListMappingPropertiesDetail.setspropertiesvalue(objMapper.getString("spropertiesvalue"));
		objListMappingPropertiesDetail.setntemplatecomponenteventdetailcode(objMapper.getInteger("ntemplatecomponenteventdetailcode"));
		objListMappingPropertiesDetail.setnstatus(objMapper.getInteger("nstatus"));

		return objListMappingPropertiesDetail;
	}
	
}

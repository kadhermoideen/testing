package com.agaramtech.agdesign.pojo;

import java.io.Serializable;
import java.sql.SQLException;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.agaramtech.lims.dao.support.AgaramResultSetMapper;
import com.agaramtech.lims.dao.support.AgaramRowMapper;

@Entity
@Table(name="conditionalargument")
@SuppressWarnings("serial")
public class ConditionalArgument implements Serializable ,AgaramRowMapper<ConditionalArgument> {

	@Id
    @Column(name = "nconditionalcode")private int nconditionalcode;
    @Column(name = "sconditionalname")private String sconditionalname;	   
    @Column(name = "nstatus")private int nstatus;
	
    public int getnconditionalcode() {
		return nconditionalcode;
	}
	public void setnconditionalcode(int nconditionalcode) {
		this.nconditionalcode = nconditionalcode;
	}
	public String getsconditionalname() {
		return sconditionalname;
	}
	public void setsconditionalname(String sconditionalname) {
		this.sconditionalname = sconditionalname;
	}
	public int getnstatus() {
		return nstatus;
	}
	public void setnstatus(int nstatus) {
		this.nstatus = nstatus;
	}
    
	
	@Override
	public String isActiveFilter(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {
		objMapper.setfield("nstatus");
		objMapper.setvalue(1);
		return objMapper.toString();
	 
	}

	@Override
	public ConditionalArgument mapRow(AgaramResultSetMapper<Object> objMapper) throws SQLException 
	{
		ConditionalArgument objConditionalArgument = new ConditionalArgument();
		
		objConditionalArgument.setnconditionalcode(objMapper.getInteger("nconditionalcode"));
		objConditionalArgument.setsconditionalname(objMapper.getString("sconditionalname"));
		objConditionalArgument.setnstatus(objMapper.getInteger("nstatus"));
		
		return objConditionalArgument;
	}
    
    
    
    

}

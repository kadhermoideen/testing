package com.agaramtech.agdesign.pojo;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;



@SuppressWarnings("serial")
public class ComponentNodeMapping implements Serializable,Comparable<ComponentNodeMapping> {

	private String id;
	private String name;
	private String classname;
	private String parameterindex;
	private String service;
	private String method;
	private String javaclass;
	private String datatype;
	private String fieldname;
	private String valuemember;
	private String displaymember;
	private String parentclass;
	private String propertiescode;
	private String componentdetailcode;
	private String serviceid;
	private String componentname;
	private String templatecode;
	
	
	public String gettemplatecode() {
		return templatecode;
	}
	public void settemplatecode(String templatecode) {
		this.templatecode = templatecode;
	}
	public String getcomponentname() {
		return componentname;
	}
	public void setcomponentname(String componentname) {
		this.componentname = componentname;
	}
	public String getserviceid() {
		return serviceid;
	}
	public void setserviceid(String serviceid) {
		this.serviceid = serviceid;
	}
	public String getcomponentdetailcode() {
		return componentdetailcode;
	}
	public void setcomponentdetailcode(String componentdetailcode) {
		this.componentdetailcode = componentdetailcode;
	}
	public String getpropertiescode() {
		return propertiescode;
	}
	public void setpropertiescode(String propertiescode) {
		this.propertiescode = propertiescode;
	}

	private ComponentSubNodeMapping objSubNodeMapping;
	public Set<ComponentSubNodeMapping> objSet = new HashSet<ComponentSubNodeMapping>();
	
	public Set<ComponentSubNodeMapping> getObjSet() {
		return objSet;
	}
	public void setObjSet(ComponentSubNodeMapping objSetMapping) {
		this.objSet.add(objSetMapping);
	}
	public String getparentclass() {
		return parentclass;
	}
	public void setparentclass(String parentclass) {
		this.parentclass = parentclass;
	}
	public ComponentSubNodeMapping getobjsubnodemapping() {
		return objSubNodeMapping;
	}
	public void setobjsubnodemapping(ComponentSubNodeMapping objSubNodeMapping) {
		this.objSubNodeMapping = objSubNodeMapping;
	}
	public String getvaluemember() {
		return valuemember;
	}
	public void setvaluemember(String valuemember) {
		this.valuemember = valuemember;
	}
	public String getdisplaymember() {
		return displaymember;
	}
	public void setdisplaymember(String displaymember) {
		this.displaymember = displaymember;
	}
	public String getid() {
		return id;
	}
	public void setid(String id) {
		this.id = id;
	}
	public String getname() {
		return name;
	}
	public void setname(String name) {
		this.name = name;
	}
	public String getclassname() {
		return classname;
	}
	public void setclassname(String classname) {
		this.classname = classname;
	}
	public String getparameterindex() {
		return parameterindex;
	}
	public void setparameterindex(String parameterindex) {
		this.parameterindex = parameterindex;
	}
	public String getservice() {
		return service;
	}
	public void setservice(String service) {
		this.service = service;
	}
	public String getmethod() {
		return method;
	}
	public void setmethod(String method) {
		this.method = method;
	}
	public String getjavaclass() {
		return javaclass;
	}
	public void setjavaclass(String javaclass) {
		this.javaclass = javaclass;
	}
	public String getdatatype() {
		return datatype;
	}
	public void setdatatype(String datatype) {
		this.datatype = datatype;
	}
	public String getfieldname() {
		return fieldname;
	}
	public void setfieldname(String fieldname) {
		this.fieldname = fieldname;
	}
	@Override
	public int compareTo(ComponentNodeMapping o) {
		// TODO Auto-generated method stub
		return 0;
	}



}

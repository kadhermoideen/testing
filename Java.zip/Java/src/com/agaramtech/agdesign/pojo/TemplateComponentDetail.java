/**
 * @author M.Arunkumar
 * @Date 12-Aug-2014
 * @time 12:26:15 PM
 */
package com.agaramtech.agdesign.pojo;

import java.io.Serializable;
import java.sql.SQLException;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.agaramtech.lims.dao.support.AgaramResultSetMapper;
import com.agaramtech.lims.dao.support.AgaramRowMapper;

@Entity
@Table(name="templatecomponentdetail")
@SuppressWarnings("serial")
public class TemplateComponentDetail implements Serializable ,AgaramRowMapper<TemplateComponentDetail> {

	@Id
	@Column(name = "ntemplatecomponentdetailcode")private int ntemplatecomponentdetailcode;
	@Column(name = "ntemplatecomponentgroupdetailcode")private int ntemplatecomponentgroupdetailcode;
	@Column(name = "ncomponentcode")private int ncomponentcode;
	@Column(name = "scomponentid")private String scomponentid;
	@Column(name = "nstatus")private int nstatus;

	transient private int componentdetailcode;
	transient private String scontainerid;
	transient private int nnoofcontrols;
	transient private String sclassname;
	transient private String scomponentname;
	
	public String getscomponentname() {
		return scomponentname;
	}
	public void setscomponentname(String scomponentname) {
		this.scomponentname = scomponentname;
	}
	public int getcomponentdetailcode() {
		return componentdetailcode;
	}
	public void setcomponentdetailcode(int componentdetailcode) {
		this.componentdetailcode = componentdetailcode;
	}

	
	public int getntemplatecomponentdetailcode() {
		return ntemplatecomponentdetailcode;
	}
	public void setntemplatecomponentdetailcode(int ntemplatecomponentdetailcode) {
		this.ntemplatecomponentdetailcode = ntemplatecomponentdetailcode;
	}
	public int getntemplatecomponentgroupdetailcode() {
		return ntemplatecomponentgroupdetailcode;
	}
	public void setntemplatecomponentgroupdetailcode(
			int ntemplatecomponentgroupdetailcode) {
		this.ntemplatecomponentgroupdetailcode = ntemplatecomponentgroupdetailcode;
	}
	public int getncomponentcode() {
		return ncomponentcode;
	}
	public void setncomponentcode(int ncomponentcode) {
		this.ncomponentcode = ncomponentcode;
	}
	public String getscomponentid() {
		return scomponentid;
	}
	public void setscomponentid(String scomponentid) {
		this.scomponentid = scomponentid;
	}
	public int getnstatus() {
		return nstatus;
	}
	public void setnstatus(int nstatus) {
		this.nstatus = nstatus;
	}

	public String getscontainerid() {
		return scontainerid;
	}
	public void setscontainerid(String scontainerid) {
		this.scontainerid = scontainerid;
	}
	public int getnnoofcontrols() {
		return nnoofcontrols;
	}
	public void setnnoofcontrols(int nnoofcontrols) {
		this.nnoofcontrols = nnoofcontrols;
	}
	
	public String getsclassname() {
		return sclassname;
	}
	public void setsclassname(String sclassname) {
		this.sclassname = sclassname;
	}
	@Override
	public TemplateComponentDetail mapRow(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {

		TemplateComponentDetail objTemplateComponentDetail = new TemplateComponentDetail();
		objTemplateComponentDetail.setntemplatecomponentdetailcode(objMapper.getInteger("ntemplatecomponentdetailcode"));
		objTemplateComponentDetail.setntemplatecomponentgroupdetailcode(objMapper.getInteger("ntemplatecomponentgroupdetailcode"));
		objTemplateComponentDetail.setncomponentcode(objMapper.getInteger("ncomponentcode"));
		objTemplateComponentDetail.setscomponentid(objMapper.getString("scomponentid"));
		objTemplateComponentDetail.setnstatus(objMapper.getInteger("nstatus"));
		objTemplateComponentDetail.setscontainerid(objMapper.getString("scontainerid"));
		objTemplateComponentDetail.setnnoofcontrols(objMapper.getInteger("nnoofcontrols"));
		objTemplateComponentDetail.setsclassname(objMapper.getString("sclassname"));
		objTemplateComponentDetail.setscomponentname(objMapper.getString("scomponentname"));
		return objTemplateComponentDetail;
	}
	@Override
	public String isActiveFilter(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}
}


/**
 * @author R.Manikandan
 * @Date 04-Aug-2014
 * @time 05:01:15 PM
 */
package com.agaramtech.agdesign.pojo;

import java.io.Serializable;
import java.sql.SQLException;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.agaramtech.lims.dao.support.AgaramResultSetMapper;
import com.agaramtech.lims.dao.support.AgaramRowMapper;

@Entity
@Table(name="templateproperties")
@SuppressWarnings("serial")
public class TemplateProperties implements Serializable ,AgaramRowMapper<TemplateProperties> {

	@Id
	@Column(name = "ntemplatepropertycode")private int ntemplatepropertycode;
	@Column(name = "ncategorycode")private int ncategorycode;
	@Column(name = "ntemplatecode")private int ntemplatecode;
	@Column(name = "npropertiescode")private int npropertiescode;
	@Column(name = "sdefaultvalue",length = 100)private String sdefaultvalue;	   
	@Column(name = "nstatus")private int nstatus;


	transient
	private int npropertytypecode;

	transient
	private String spropertyname;

	public int getntemplatecode() {
		return ntemplatecode;
	}

	public void setntemplatecode(int ntemplatecode) {
		this.ntemplatecode = ntemplatecode;
	}
	public int getntemplatepropertycode() {
		return ntemplatepropertycode;
	}
	public void setntemplatepropertycode(int ntemplatepropertycode) {
		this.ntemplatepropertycode = ntemplatepropertycode;
	}
	public int getncategorycode() {
		return ncategorycode;
	}
	public void setncategorycode(int ncategorycode) {
		this.ncategorycode = ncategorycode;
	}
	public int getnpropertiescode() {
		return npropertiescode;
	}
	public void setnpropertiescode(int npropertiescode) {
		this.npropertiescode = npropertiescode;
	}
	public String getsdefaultvalue() {
		return sdefaultvalue;
	}
	public void setsdefaultvalue(String sdefaultvalue) {
		this.sdefaultvalue = sdefaultvalue;
	}
	public int getnstatus() {
		return nstatus;
	}
	public void setnstatus(int nstatus) {
		this.nstatus = nstatus;
	}
	public int getnpropertytypecode() {
		return npropertytypecode;
	}
	public void setnpropertytypecode(int npropertytypecode) {
		this.npropertytypecode = npropertytypecode;
	}
	public String getspropertyname() {
		return spropertyname;
	}
	public void setspropertyname(String spropertyname) {
		this.spropertyname = spropertyname;
	}

	@Override
	public TemplateProperties mapRow(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {

		TemplateProperties objtemplateProperties = new TemplateProperties();
		objtemplateProperties.setntemplatepropertycode(objMapper.getInteger("ntemplatepropertycode"));
		objtemplateProperties.setsdefaultvalue(objMapper.getString("sdefaultvalue"));
		objtemplateProperties.setnstatus(objMapper.getInteger("nstatus"));
		objtemplateProperties.setncategorycode(objMapper.getInteger("ncategorycode"));
		objtemplateProperties.setntemplatecode(objMapper.getInteger("ntemplatecode"));
		objtemplateProperties.setnpropertiescode(objMapper.getInteger("npropertiescode"));
		
		objtemplateProperties.setnpropertytypecode(objMapper.getInteger("npropertytypecode"));
		objtemplateProperties.setspropertyname(objMapper.getString("spropertyname"));

		return objtemplateProperties;
	}
	@Override
	public String isActiveFilter(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}




}

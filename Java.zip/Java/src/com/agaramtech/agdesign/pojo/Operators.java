package com.agaramtech.agdesign.pojo;

import java.io.Serializable;
import java.sql.SQLException;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.agaramtech.lims.dao.support.AgaramResultSetMapper;
import com.agaramtech.lims.dao.support.AgaramRowMapper;

@Entity
@Table(name="operators")
@SuppressWarnings("serial")
public class Operators implements Serializable ,AgaramRowMapper<Operators> {

	@Id
    @Column(name = "noperatorscode")private int noperatorscode;
    @Column(name = "soperatorsname")private String soperatorsname;
    @Column(name = "ssyntax")private String ssyntax;
    @Column(name = "nstatus")private int nstatus;

    public int getnoperatorscode() {
		return noperatorscode;
	}
	public void setnoperatorscode(int noperatorscode) {
		this.noperatorscode = noperatorscode;
	}
	public String getsoperatorsname() {
		return soperatorsname;
	}
	public void setsoperatorsname(String soperatorsname) {
		this.soperatorsname = soperatorsname;
	}
	public String getssyntax() {
		return ssyntax;
	}
	public void setssyntax(String ssyntax) {
		this.ssyntax = ssyntax;
	}
	public int getnstatus() {
		return nstatus;
	}
	public void setnstatus(int nstatus) {
		this.nstatus = nstatus;
	}
    
    
	@Override
	public String isActiveFilter(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {
		objMapper.setfield("nstatus");
		objMapper.setvalue(1);
		return objMapper.toString();
	 
	}

	@Override
	public Operators mapRow(AgaramResultSetMapper<Object> objMapper) throws SQLException
	{
		Operators objOperators = new Operators();
		
		objOperators.setnoperatorscode(objMapper.getInteger("noperatorscode"));
		objOperators.setsoperatorsname(objMapper.getString("soperatorsname"));
		objOperators.setssyntax(objMapper.getString("ssyntax"));
		objOperators.setnstatus(objMapper.getInteger("nstatus"));
		
		return objOperators;
	}
    


}

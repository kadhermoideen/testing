package com.agaramtech.agdesign.pojo;

import java.io.Serializable;
import java.sql.SQLException;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.agaramtech.lims.dao.support.AgaramResultSetMapper;
import com.agaramtech.lims.dao.support.AgaramRowMapper;

@Entity
@Table(name="templatecomponenteventpropertiesdetail")
@SuppressWarnings("serial")
public class TemplateComponentEventPropertiesDetail implements Serializable ,AgaramRowMapper<TemplateComponentEventPropertiesDetail> {

	@Id
	@Column(name = "ntemplatecomponenteventpropertiesdetailcode")private int ntemplatecomponenteventpropertiesdetailcode;
	@Column(name = "ntemplatecomponenteventdetailcode")private int ntemplatecomponenteventdetailcode;
	@Column(name = "npropertiescode")private int npropertiescode;
	@Column(name = "spropertiesvalue")private String spropertiesvalue;
	@Column(name = "nstatus")private int nstatus;
	
	
	public int getntemplatecomponenteventpropertiesdetailcode() {
		return ntemplatecomponenteventpropertiesdetailcode;
	}
	public void setntemplatecomponenteventpropertiesdetailcode(
			int ntemplatecomponenteventpropertiesdetailcode) {
		this.ntemplatecomponenteventpropertiesdetailcode = ntemplatecomponenteventpropertiesdetailcode;
	}
	public int getntemplatecomponenteventdetailcode() {
		return ntemplatecomponenteventdetailcode;
	}
	public void setntemplatecomponenteventdetailcode(
			int ntemplatecomponenteventdetailcode) {
		this.ntemplatecomponenteventdetailcode = ntemplatecomponenteventdetailcode;
	}
	public int getnpropertiescode() {
		return npropertiescode;
	}
	public void setnpropertiescode(int npropertiescode) {
		this.npropertiescode = npropertiescode;
	}
	public String getspropertiesvalue() {
		return spropertiesvalue;
	}
	public void setspropertiesvalue(String spropertiesvalue) {
		this.spropertiesvalue = spropertiesvalue;
	}
	public int getnstatus() {
		return nstatus;
	}
	public void setnstatus(int nstatus) {
		this.nstatus = nstatus;
	}
	
	
	
	@Override
	public TemplateComponentEventPropertiesDetail mapRow(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {

		TemplateComponentEventPropertiesDetail objTemplateComponentEventPropertiesDetail = new TemplateComponentEventPropertiesDetail();
		objTemplateComponentEventPropertiesDetail.setntemplatecomponenteventpropertiesdetailcode(objMapper.getInteger("ntemplatecomponenteventpropertiesdetailcode"));
		objTemplateComponentEventPropertiesDetail.setntemplatecomponenteventdetailcode(objMapper.getInteger("ntemplatecomponenteventdetailcode"));
		objTemplateComponentEventPropertiesDetail.setnpropertiescode(objMapper.getInteger("npropertiescode"));
		objTemplateComponentEventPropertiesDetail.setspropertiesvalue(objMapper.getString("spropertiesvalue"));
		objTemplateComponentEventPropertiesDetail.setnstatus(objMapper.getInteger("nstatus"));

		return objTemplateComponentEventPropertiesDetail;
	}
	@Override
	public String isActiveFilter(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	
	
	

}

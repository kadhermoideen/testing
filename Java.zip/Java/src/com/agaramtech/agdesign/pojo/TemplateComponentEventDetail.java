package com.agaramtech.agdesign.pojo;

import java.io.Serializable;
import java.sql.SQLException;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import com.agaramtech.lims.dao.support.AgaramResultSetMapper;
import com.agaramtech.lims.dao.support.AgaramRowMapper;

@Entity
@Table(name="templatecomponenteventdetail")
@SuppressWarnings("serial")
public class TemplateComponentEventDetail implements Serializable ,AgaramRowMapper<TemplateComponentEventDetail> {

	@Id
	@Column(name = "ntemplatecomponenteventdetailcode")private int ntemplatecomponenteventdetailcode;
	@Column(name = "ntemplatecomponentdetailcode")private int ntemplatecomponentdetailcode;
	@Column(name = "npropertiescode")private int npropertiescode;
	@Column(name = "nstatus")private int nstatus;
	
	
	public int getntemplatecomponenteventdetailcode() {
		return ntemplatecomponenteventdetailcode;
	}
	public void setntemplatecomponenteventdetailcode(
			int ntemplatecomponenteventdetailcode) {
		this.ntemplatecomponenteventdetailcode = ntemplatecomponenteventdetailcode;
	}
	public int getntemplatecomponentdetailcode() {
		return ntemplatecomponentdetailcode;
	}
	public void setntemplatecomponentdetailcode(int ntemplatecomponentdetailcode) {
		this.ntemplatecomponentdetailcode = ntemplatecomponentdetailcode;
	}
	public int getnpropertiescode() {
		return npropertiescode;
	}
	public void setnpropertiescode(int npropertiescode) {
		this.npropertiescode = npropertiescode;
	}
	public int getnstatus() {
		return nstatus;
	}
	public void setnstatus(int nstatus) {
		this.nstatus = nstatus;
	}
	
	
	@Override
	public TemplateComponentEventDetail mapRow(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {

		TemplateComponentEventDetail objTemplateComponentEventDetail = new TemplateComponentEventDetail();
		objTemplateComponentEventDetail.setntemplatecomponenteventdetailcode(objMapper.getInteger("ntemplatecomponenteventdetailcode"));
		objTemplateComponentEventDetail.setntemplatecomponentdetailcode(objMapper.getInteger("ntemplatecomponentdetailcode"));
		objTemplateComponentEventDetail.setnpropertiescode(objMapper.getInteger("npropertiescode"));
		objTemplateComponentEventDetail.setnstatus(objMapper.getInteger("nstatus"));

		return objTemplateComponentEventDetail;
	}
	@Override
	public String isActiveFilter(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}
	
	

}

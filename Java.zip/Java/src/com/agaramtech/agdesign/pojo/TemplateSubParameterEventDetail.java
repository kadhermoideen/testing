package com.agaramtech.agdesign.pojo;

import java.io.Serializable;
import java.sql.SQLException;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.agaramtech.lims.dao.support.AgaramResultSetMapper;
import com.agaramtech.lims.dao.support.AgaramRowMapper;

@Entity
@Table(name="templatesubparametereventdetail")
@SuppressWarnings("serial")
public class TemplateSubParameterEventDetail implements Serializable ,AgaramRowMapper<TemplateSubParameterEventDetail> {

	@Id
	@Column(name = "ntemplatesubparametereventdetailcode")private int ntemplatesubparametereventdetailcode;
	@Column(name = "ntemplateparametereventdetailcode")private int ntemplateparametereventdetailcode; 
	@Column(name = "sfieldname")private String sfieldname;
	@Column(name = "ntemplatecomponentdetailcode")private int ntemplatecomponentdetailcode;
	@Column(name = "nstatus")private int nstatus;

	
	public int getntemplatesubparametereventdetailcode() {
		return ntemplatesubparametereventdetailcode;
	}
	public void setntemplatesubparametereventdetailcode(
			int ntemplatesubparametereventdetailcode) {
		this.ntemplatesubparametereventdetailcode = ntemplatesubparametereventdetailcode;
	}
	public int getntemplateparametereventdetailcode() {
		return ntemplateparametereventdetailcode;
	}
	public void setntemplateparametereventdetailcode(
			int ntemplateparametereventdetailcode) {
		this.ntemplateparametereventdetailcode = ntemplateparametereventdetailcode;
	}
	public int getntemplatecomponentdetailcode() {
		return ntemplatecomponentdetailcode;
	}
	public void setntemplatecomponentdetailcode(int ntemplatecomponentdetailcode) {
		this.ntemplatecomponentdetailcode = ntemplatecomponentdetailcode;
	}
	public String getsfieldname() {
		return sfieldname;
	}
	public void setsfieldname(String sfieldname) {
		this.sfieldname = sfieldname;
	}
	
	public int getnstatus() {
		return nstatus;
	}
	public void setnstatus(int nstatus) {
		this.nstatus = nstatus;
	}
	
	
	
	@Override
	public TemplateSubParameterEventDetail mapRow(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {

		TemplateSubParameterEventDetail objTemplateSubParameterEventDetail = new TemplateSubParameterEventDetail();
		objTemplateSubParameterEventDetail.setntemplatesubparametereventdetailcode(objMapper.getInteger("ntemplatesubparametereventdetailcode"));
		objTemplateSubParameterEventDetail.setntemplateparametereventdetailcode(objMapper.getInteger("ntemplateparametereventdetailcode"));
		objTemplateSubParameterEventDetail.setsfieldname(objMapper.getString("sfieldname"));
		objTemplateSubParameterEventDetail.setntemplatecomponentdetailcode(objMapper.getInteger("ntemplatecomponentdetailcode"));
		objTemplateSubParameterEventDetail.setnstatus(objMapper.getInteger("nstatus"));
		
		return objTemplateSubParameterEventDetail;
	}
	@Override
	public String isActiveFilter(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}
	
	

}

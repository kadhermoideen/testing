/**
 * @author C.Manikandan
 * @Date 22-May-2014
 * @time 11:25:15 AM
 */
package com.agaramtech.agdesign.pojo;

import java.io.Serializable;
import java.sql.SQLException;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.agaramtech.lims.dao.support.AgaramResultSetMapper;
import com.agaramtech.lims.dao.support.AgaramRowMapper;

@Entity
@Table(name="propertiesscreen")
@SuppressWarnings("serial")
public class PropertiesScreen implements Serializable ,AgaramRowMapper<PropertiesScreen> {

	@Id
	@Column(name = "npropertiesscreencode")private int npropertiesscreencode;
	@Column(name = "sclassname")private String sclassname; 
	@Column(name = "sname")private String sname;
	@Column(name = "nstatus")private int nstatus;


	public int getnpropertiesscreencode() {
		return npropertiesscreencode;
	}

	public void setnpropertiesscreencode(int npropertiesscreencode) {
		this.npropertiesscreencode = npropertiesscreencode;
	}

	public String getsclassname() {
		return sclassname;
	}

	public void setsclassname(String sclassname) {
		this.sclassname = sclassname;
	}

	public String getsname() {
		return sname;
	}

	public void setsname(String sname) {
		this.sname = sname;
	}

	public int getnstatus() {
		return nstatus;
	}

	public void setnstatus(int nstatus) {
		this.nstatus = nstatus;
	}

	@Override
	public String isActiveFilter(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {
		objMapper.setfield("nstatus");
		objMapper.setvalue(1);
		return objMapper.toString();

	}

	@Override
	public PropertiesScreen mapRow(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {
		PropertiesScreen objPropertiesScreen = new PropertiesScreen();

		objPropertiesScreen.setnpropertiesscreencode(objMapper.getInteger("npropertiesscreencode"));
		objPropertiesScreen.setsclassname(objMapper.getString("sclassname"));
		objPropertiesScreen.setsname(objMapper.getString("sname"));
		objPropertiesScreen.setnstatus(objMapper.getInteger("nstatus"));

		return objPropertiesScreen;
	}

}

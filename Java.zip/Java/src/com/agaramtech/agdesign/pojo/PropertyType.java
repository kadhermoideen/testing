/**
 * @author C.Manikandan
 * @Date 22-May-2014
 * @time 11:25:15 AM
 */
package com.agaramtech.agdesign.pojo;

import java.io.Serializable;
import java.sql.SQLException;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.agaramtech.lims.dao.support.AgaramResultSetMapper;
import com.agaramtech.lims.dao.support.AgaramRowMapper;

@Entity
@Table(name="propertytype")
@SuppressWarnings("serial")
public class PropertyType implements Serializable ,AgaramRowMapper<PropertyType> {

	@Id
	@Column(name = "npropertytypecode")private int npropertytypecode;
	@Column(name = "spropertytype")private String spropertytype; 
	@Column(name = "nstatus")private int nstatus;

	public int getnpropertytypecode() {
		return npropertytypecode;
	}

	public void setnpropertytypecode(int npropertytypecode) {
		this.npropertytypecode = npropertytypecode;
	}

	public String getspropertytype() {
		return spropertytype;
	}

	public void setspropertytype(String spropertytype) {
		this.spropertytype = spropertytype;
	}

	public int getnstatus() {
		return nstatus;
	}

	public void setnstatus(int nstatus) {
		this.nstatus = nstatus;
	}

	@Override
	public String isActiveFilter(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {
		objMapper.setfield("nstatus");
		objMapper.setvalue(1);
		return objMapper.toString();

	}

	@Override
	public PropertyType mapRow(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {
		PropertyType objPropertyType = new PropertyType();
		objPropertyType.setspropertytype(objMapper.getString("spropertytype"));
		objPropertyType.setnpropertytypecode(objMapper.getInteger("npropertytypecode"));
		objPropertyType.setnstatus(objMapper.getInteger("nstatus"));

		return objPropertyType;
	}

}

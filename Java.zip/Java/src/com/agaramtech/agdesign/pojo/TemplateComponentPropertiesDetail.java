package com.agaramtech.agdesign.pojo;

import java.io.Serializable;
import java.sql.SQLException;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.agaramtech.lims.dao.support.AgaramResultSetMapper;
import com.agaramtech.lims.dao.support.AgaramRowMapper;

@Entity
@Table(name="templatecomponentpropertiesdetail")
@SuppressWarnings("serial")
public class TemplateComponentPropertiesDetail implements Serializable ,AgaramRowMapper<TemplateComponentPropertiesDetail> {

	@Id
	@Column(name = "ntemplatecomponentpropertiesdetailcode")private int ntemplatecomponentpropertiesdetailcode;
	@Column(name = "ntemplatecomponentdetailcode")private int ntemplatecomponentdetailcode; 
	@Column(name = "npropertiescode")private int npropertiescode;
	@Column(name = "spropertiesvalue")private String spropertiesvalue;
	@Column(name = "nstatus")private int nstatus;
	
	
	
	public int getntemplatecomponentpropertiesdetailcode() {
		return ntemplatecomponentpropertiesdetailcode;
	}
	public void setntemplatecomponentpropertiesdetailcode(
			int ntemplatecomponentpropertiesdetailcode) {
		this.ntemplatecomponentpropertiesdetailcode = ntemplatecomponentpropertiesdetailcode;
	}
	public int getntemplatecomponentdetailcode() {
		return ntemplatecomponentdetailcode;
	}
	public void setntemplatecomponentdetailcode(int ntemplatecomponentdetailcode) {
		this.ntemplatecomponentdetailcode = ntemplatecomponentdetailcode;
	}
	public int getnpropertiescode() {
		return npropertiescode;
	}
	public void setnpropertiescode(int npropertiescode) {
		this.npropertiescode = npropertiescode;
	}
	public String getspropertiesvalue() {
		return spropertiesvalue;
	}
	public void setspropertiesvalue(String spropertiesvalue) {
		this.spropertiesvalue = spropertiesvalue;
	}
	
	
	public int getnstatus() {
		return nstatus;
	}
	public void setnstatus(int nstatus) {
		this.nstatus = nstatus;
	}
	
	@Override
	public String isActiveFilter(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {
		objMapper.setfield("nstatus");
		objMapper.setvalue(1);
		return objMapper.toString();

	}

	@Override
	public TemplateComponentPropertiesDetail mapRow(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {
		TemplateComponentPropertiesDetail objTemplateComponentPropertiesDetail = new TemplateComponentPropertiesDetail();
		objTemplateComponentPropertiesDetail.setntemplatecomponentpropertiesdetailcode(objMapper.getInteger("ntemplatecomponentpropertiesdetailcode"));
		objTemplateComponentPropertiesDetail.setntemplatecomponentdetailcode(objMapper.getInteger("ntemplatecomponentdetailcode"));
		objTemplateComponentPropertiesDetail.setnpropertiescode(objMapper.getInteger("npropertiescode"));
		objTemplateComponentPropertiesDetail.setspropertiesvalue(objMapper.getString("spropertiesvalue"));
		objTemplateComponentPropertiesDetail.setnstatus(objMapper.getInteger("nstatus"));

		return objTemplateComponentPropertiesDetail;
	}
}

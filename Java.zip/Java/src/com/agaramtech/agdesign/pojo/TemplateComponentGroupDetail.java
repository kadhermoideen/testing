/**
 * @author M.Arunkumar
 * @Date 12-Aug-2014
 * @time 12:17:15 PM
 */
package com.agaramtech.agdesign.pojo;

import java.io.Serializable;
import java.sql.SQLException;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.agaramtech.lims.dao.support.AgaramResultSetMapper;
import com.agaramtech.lims.dao.support.AgaramRowMapper;

@Entity
@Table(name="templatecomponentgroupdetail")
@SuppressWarnings("serial")
public class TemplateComponentGroupDetail implements Serializable ,AgaramRowMapper<TemplateComponentGroupDetail> {

	@Id
	@Column(name = "ntemplatecomponentgroupdetailcode")private int ntemplatecomponentgroupdetailcode;
	@Column(name = "scontainerid",length = 100)private String scontainerid;
	@Column(name = "ntemplatedetailcode")private int ntemplatedetailcode;
	@Column(name = "nnoofcontrols")private int nnoofcontrols;
	@Column(name = "nstatus")private int nstatus;
	
	transient private int ntemplatetype;
	
	
	public int getntemplatetype() {
		return ntemplatetype;
	}
	public void setntemplatetype(int ntemplatetype) {
		this.ntemplatetype = ntemplatetype;
	}
	public int getntemplatecomponentgroupdetailcode() {
		return ntemplatecomponentgroupdetailcode;
	}
	public void setntemplatecomponentgroupdetailcode(
			int ntemplatecomponentgroupdetailcode) {
		this.ntemplatecomponentgroupdetailcode = ntemplatecomponentgroupdetailcode;
	}
	public int getntemplatedetailcode() {
		return ntemplatedetailcode;
	}
	public void setntemplatedetailcode(int ntemplatedetailcode) {
		this.ntemplatedetailcode = ntemplatedetailcode;
	}
	public String getscontainerid() {
		return scontainerid;
	}
	public void setscontainerid(String scontainerid) {
		this.scontainerid = scontainerid;
	}
	
	public int getnnoofcontrols() {
		return nnoofcontrols;
	}
	public void setnnoofcontrols(int nnoofcontrols) {
		this.nnoofcontrols = nnoofcontrols;
	}
	public int getnstatus() {
		return nstatus;
	}
	public void setnstatus(int nstatus) {
		this.nstatus = nstatus;
	}
	
	@Override
	public TemplateComponentGroupDetail mapRow(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {

		TemplateComponentGroupDetail objtemplatecomponentgroupdetail = new TemplateComponentGroupDetail();
		objtemplatecomponentgroupdetail.setntemplatecomponentgroupdetailcode(objMapper.getInteger("ntemplatecomponentgroupdetailcode"));
		objtemplatecomponentgroupdetail.setscontainerid(objMapper.getString("scontainerid"));
		objtemplatecomponentgroupdetail.setntemplatedetailcode(objMapper.getInteger("ntemplatedetailcode"));
		objtemplatecomponentgroupdetail.setnnoofcontrols(objMapper.getInteger("nnoofcontrols"));
		objtemplatecomponentgroupdetail.setnstatus(objMapper.getInteger("nstatus"));

		return objtemplatecomponentgroupdetail;
	}
	@Override
	public String isActiveFilter(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}




}

/**
 * @author C.Manikandan
 * @Date 22-May-2014
 * @time 11:25:15 AM
 */
package com.agaramtech.agdesign.pojo;

import java.io.Serializable;
import java.sql.SQLException;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.agaramtech.lims.dao.support.AgaramResultSetMapper;
import com.agaramtech.lims.dao.support.AgaramRowMapper;

@Entity
@Table(name="components")
@SuppressWarnings("serial")
public class Components implements Serializable ,AgaramRowMapper<Components> {

	@Id
    @Column(name = "ncomponentcode")private int ncomponentcode;
    @Column(name = "scomponentname")private String scomponentname;
    @Column(name = "sicon")private String sicon;
    @Column(name = "ncomponenttype")private int ncomponenttype;
    @Column(name = "sclassname",length=100)private String sclassname;	   
    @Column(name = "nstatus")private int nstatus;
  	

	public String getsicon() {
		return sicon;
	}

	public void setsicon(String sicon) {
		this.sicon = sicon;
	}

	public int getncomponentcode() {
		return ncomponentcode;
	}

	public void setncomponentcode(int ncomponentcode) {
		this.ncomponentcode = ncomponentcode;
	}

	public String getscomponentname() {
		return scomponentname;
	}

	public void setscomponentname(String scomponentname) {
		this.scomponentname = scomponentname;
	}

	public int getncomponenttype() {
		return ncomponenttype;
	}

	public void setncomponenttype(int ncomponenttype) {
		this.ncomponenttype = ncomponenttype;
	}

	public String getsclassname() {
		return sclassname;
	}

	public void setsclassname(String sclassname) {
		this.sclassname = sclassname;
	}

	public int getnstatus() {
		return nstatus;
	}

	public void setnstatus(int nstatus) {
		this.nstatus = nstatus;
	}

	@Override
	public String isActiveFilter(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {
		objMapper.setfield("nstatus");
		objMapper.setvalue(1);
		return objMapper.toString();
	 
	}

	@Override
	public Components mapRow(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {
		Components objComponents = new Components();
		objComponents.setncomponentcode(objMapper.getInteger("ncomponentcode"));
		 objComponents.setnstatus(objMapper.getInteger("nstatus"));
		 objComponents.setsclassname(objMapper.getString("sclassname"));
		 objComponents.setsicon(objMapper.getString("sicon"));
		 objComponents.setscomponentname(objMapper.getString("scomponentname"));
		 objComponents.setncomponenttype(objMapper.getInteger("ncomponenttype"));

		return objComponents;
	}

}

package com.agaramtech.agdesign.pojo;

import java.io.Serializable;
import java.sql.SQLException;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.agaramtech.lims.dao.support.AgaramResultSetMapper;
import com.agaramtech.lims.dao.support.AgaramRowMapper;

@Entity
@Table(name="templatesubcomponentdetail")
@SuppressWarnings("serial")
public class TemplateSubComponentDetail implements Serializable ,AgaramRowMapper<TemplateSubComponentDetail> {

	@Id
	@Column(name = "ntemplatesubcomponentdetailcode")private int ntemplatesubcomponentdetailcode;
	@Column(name = "ntemplatecomponentdetailcode")private int ntemplatecomponentdetailcode;
	@Column(name = "ncolumncode")private int ncolumncode;
	@Column(name = "norderby")private int norderby;
	@Column(name = "nstatus")private int nstatus;

	
	 
	public int getntemplatesubcomponentdetailcode() {
		return ntemplatesubcomponentdetailcode;
	}
	public void setntemplatesubcomponentdetailcode(
			int ntemplatesubcomponentdetailcode) {
		this.ntemplatesubcomponentdetailcode = ntemplatesubcomponentdetailcode;
	}
	public int getntemplatecomponentdetailcode() {
		return ntemplatecomponentdetailcode;
	}
	public void setntemplatecomponentdetailcode(int ntemplatecomponentdetailcode) {
		this.ntemplatecomponentdetailcode = ntemplatecomponentdetailcode;
	}
	public int getNcolumncode() {
		return ncolumncode;
	}
	public void setNcolumncode(int ncolumncode) {
		this.ncolumncode = ncolumncode;
	}
	public int getNorderby() {
		return norderby;
	}
	public void setNorderby(int norderby) {
		this.norderby = norderby;
	}
	public int getNstatus() {
		return nstatus;
	}
	public void setNstatus(int nstatus) {
		this.nstatus = nstatus;
	}
	public int getncolumncode() {
		return ncolumncode;
	}
	public void setncolumncode(int ncolumncode) {
		this.ncolumncode = ncolumncode;
	}
	public int getnorderby() {
		return norderby;
	}
	public void setnorderby(int norderby) {
		this.norderby = norderby;
	}
	public int getnstatus() {
		return nstatus;
	}
	public void setnstatus(int nstatus) {
		this.nstatus = nstatus;
	}
	
	
	@Override
	public TemplateSubComponentDetail mapRow(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {

		TemplateSubComponentDetail objTemplateSubComponentDetail = new TemplateSubComponentDetail();
		objTemplateSubComponentDetail.setntemplatesubcomponentdetailcode(objMapper.getInteger("ntemplatesubcomponentdetailcode"));
		objTemplateSubComponentDetail.setntemplatecomponentdetailcode(objMapper.getInteger("ntemplatecomponentdetailcode"));
		objTemplateSubComponentDetail.setnorderby(objMapper.getInteger("norderby"));
		objTemplateSubComponentDetail.setnstatus(objMapper.getInteger("nstatus"));
		
		return objTemplateSubComponentDetail;
	}
	@Override
	public String isActiveFilter(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}
	

}

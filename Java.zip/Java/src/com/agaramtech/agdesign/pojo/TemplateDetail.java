/**
 * @author M.Arunkumar
 * @Date 12-Aug-2014
 * @time 12:08:00 PM
 */
package com.agaramtech.agdesign.pojo;

import java.io.Serializable;
import java.sql.SQLException;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.agaramtech.lims.dao.support.AgaramResultSetMapper;
import com.agaramtech.lims.dao.support.AgaramRowMapper;

@Entity
@Table(name="templatedetail")
@SuppressWarnings("serial")
public class TemplateDetail implements Serializable ,AgaramRowMapper<TemplateDetail> {

	@Id
	@Column(name = "ntemplatedetailcode")private int ntemplatedetailcode;
	@Column(name = "stitlename",length = 200)private String stitlename;
	@Column(name = "ntemplatecode")private int ntemplatecode;
	@Column(name = "nstatus")private int nstatus;
	@Column(name = "ntypecode")private int ntypecode;
	

	
	
	public int getntemplatedetailcode() {
		return ntemplatedetailcode;
	}
	public void setntemplatedetailcode(int ntemplatedetailcode) {
		this.ntemplatedetailcode = ntemplatedetailcode;
	}
	public String getstitlename() {
		return stitlename;
	}
	public void setstitlename(String stitlename) {
		this.stitlename = stitlename;
	}
	public int getntemplatecode() {
		return ntemplatecode;
	}
	public void setntemplatecode(int ntemplatecode) {
		this.ntemplatecode = ntemplatecode;
	}
	public int getnstatus() {
		return nstatus;
	}
	public void setnstatus(int nstatus) {
		this.nstatus = nstatus;
	}
	public int getntypecode() {
		return ntypecode;
	}
	public void setntypecode(int ntypecode) {
		this.ntypecode = ntypecode;
	}
	
	
	@Override
	public TemplateDetail mapRow(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {

		TemplateDetail objPopupTemplateDetail = new TemplateDetail();
		objPopupTemplateDetail.setntemplatedetailcode(objMapper.getInteger("ntemplatedetailcode"));
		objPopupTemplateDetail.setstitlename(objMapper.getString("stitlename"));
		objPopupTemplateDetail.setntemplatecode(objMapper.getInteger("ntemplatecode"));
		objPopupTemplateDetail.setnstatus(objMapper.getInteger("nstatus"));
		objPopupTemplateDetail.setntypecode(objMapper.getInteger("ntypecode"));

		return objPopupTemplateDetail;
	}
	@Override
	public String isActiveFilter(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}
}

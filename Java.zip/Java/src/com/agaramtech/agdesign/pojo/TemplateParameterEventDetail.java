package com.agaramtech.agdesign.pojo;

import java.io.Serializable;
import java.sql.SQLException;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.agaramtech.lims.dao.support.AgaramResultSetMapper;
import com.agaramtech.lims.dao.support.AgaramRowMapper;

@Entity
@Table(name="templateparametereventdetail")
@SuppressWarnings("serial")
public class TemplateParameterEventDetail implements Serializable ,AgaramRowMapper<TemplateParameterEventDetail> {

	@Id
	@Column(name = "ntemplateparametereventdetailcode")private int ntemplateparametereventdetailcode;
	@Column(name = "ntemplatecomponenteventpropertiesdetailcode")private int ntemplatecomponenteventpropertiesdetailcode; 
	@Column(name = "sparametername")private String sparametername;
	@Column(name = "sclassname")private String sclassname;
	@Column(name = "ntype")private int ntype;
	@Column(name = "nstatus")private int nstatus;
	
	
	public int getntemplateparametereventdetailcode() {
		return ntemplateparametereventdetailcode;
	}
	public void setntemplateparametereventdetailcode(
			int ntemplateparametereventdetailcode) {
		this.ntemplateparametereventdetailcode = ntemplateparametereventdetailcode;
	}
	public int getntemplatecomponenteventpropertiesdetailcode() {
		return ntemplatecomponenteventpropertiesdetailcode;
	}
	public void setntemplatecomponenteventpropertiesdetailcode(
			int ntemplatecomponenteventpropertiesdetailcode) {
		this.ntemplatecomponenteventpropertiesdetailcode = ntemplatecomponenteventpropertiesdetailcode;
	}
	public String getsparametername() {
		return sparametername;
	}
	public void setsparametername(String sparametername) {
		this.sparametername = sparametername;
	}
	public String getsclassname() {
		return sclassname;
	}
	public void setsclassname(String sclassname) {
		this.sclassname = sclassname;
	}
	public int getntype() {
		return ntype;
	}
	public void setntype(int ntype) {
		this.ntype = ntype;
	}
	public int getnstatus() {
		return nstatus;
	}
	public void setnstatus(int nstatus) {
		this.nstatus = nstatus;
	}
	
	
	
	@Override
	public TemplateParameterEventDetail mapRow(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {

		TemplateParameterEventDetail objTemplateParameterEventDetail = new TemplateParameterEventDetail();
		objTemplateParameterEventDetail.setntemplateparametereventdetailcode(objMapper.getInteger("ntemplateparametereventdetailcode"));
		objTemplateParameterEventDetail.setntemplatecomponenteventpropertiesdetailcode(objMapper.getInteger("ntemplatecomponenteventpropertiesdetailcode"));
		objTemplateParameterEventDetail.setsparametername(objMapper.getString("sparametername"));
		objTemplateParameterEventDetail.setsclassname(objMapper.getString("sclassname"));
		objTemplateParameterEventDetail.setntype(objMapper.getInteger("ntype"));
		objTemplateParameterEventDetail.setnstatus(objMapper.getInteger("nstatus"));
		
		return objTemplateParameterEventDetail;
	}
	@Override
	public String isActiveFilter(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	

}

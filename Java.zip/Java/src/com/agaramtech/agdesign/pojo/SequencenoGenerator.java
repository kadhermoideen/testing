package com.agaramtech.agdesign.pojo;
import java.io.Serializable;
import java.sql.SQLException;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.agaramtech.lims.dao.support.AgaramResultSetMapper;
import com.agaramtech.lims.dao.support.AgaramRowMapper;
@Entity
@Table(name="sequencenogenerator")
@SuppressWarnings("serial")
public class SequencenoGenerator implements Serializable,AgaramRowMapper<SequencenoGenerator>{
	@Id
	@Column(name="stablename") private String stablename;
	@Column(name="nsequenceno",length=50) private int nsequenceno;
	@Column(name="nsequencenolength",length=10) private int nsequencenolength;
	@Column(name="sprefixformat",length=2) private String sprefixformat;
	@Column(name="sprefixname",length=3) private String sprefixname;
	@Column(name="ssuffixformat",length=3) private String ssuffixformat;
	@Column(name="ssuffixname",length=3) private String ssuffixname;
	public String getstablename() {
		return stablename;
	}
	public void setstablename(String stablename) {
		this.stablename = stablename;
	}
	public int getnsequenceno() {
		return nsequenceno;
	}
	public void setnsequenceno(int nsequenceno) {
		this.nsequenceno = nsequenceno;
	}
	public int getnsequencenolength() {
		return nsequencenolength;
	}
	public void setnsequencenolength(int nsequencenolength) {
		this.nsequencenolength = nsequencenolength;
	}
	public String getsprefixformat() {
		return sprefixformat;
	}
	public void setsprefixformat(String sprefixformat) {
		this.sprefixformat = sprefixformat;
	}
	public String getsprefixname() {
		return sprefixname;
	}
	public void setsprefixname(String sprefixname) {
		this.sprefixname = sprefixname;
	}
	public String getssuffixformat() {
		return ssuffixformat;
	}
	public void setssuffixformat(String ssuffixformat) {
		this.ssuffixformat = ssuffixformat;
	}
	public String getssuffixname() {
		return ssuffixname;
	}
	public void setssuffixname(String ssuffixname) {
		this.ssuffixname = ssuffixname;
	}
	@Override
	public String isActiveFilter(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {

		return null;
	}
	@Override
	public SequencenoGenerator mapRow(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {
		SequencenoGenerator objSequencenoGenerator = new SequencenoGenerator();
		objSequencenoGenerator.setssuffixname(objMapper.getString("ssuffixname"));
		objSequencenoGenerator.setstablename(objMapper.getString("stablename"));
		objSequencenoGenerator.setnsequencenolength(objMapper.getInteger("nsequencenolength"));
		objSequencenoGenerator.setsprefixformat(objMapper.getString("sprefixformat"));
		objSequencenoGenerator.setssuffixformat(objMapper.getString("ssuffixformat"));
		objSequencenoGenerator.setnsequenceno(objMapper.getInteger("nsequenceno"));
		objSequencenoGenerator.setsprefixname(objMapper.getString("sprefixname"));
		return objSequencenoGenerator;
	}



}

package com.agaramtech.agdesign.pojo;

import java.io.Serializable;
import java.sql.SQLException;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.agaramtech.lims.dao.support.AgaramResultSetMapper;
import com.agaramtech.lims.dao.support.AgaramRowMapper;

@Entity
@Table(name="templatesubcomponentpropertiesdetail")
@SuppressWarnings("serial")
public class TemplateSubComponentPropertiesDetail implements Serializable ,AgaramRowMapper<TemplateSubComponentPropertiesDetail> {

	@Id
	@Column(name = "ntemplatesubcomponentpropertiesdetailcode")private int ntemplatesubcomponentpropertiesdetailcode;
	@Column(name = "ntemplatesubcomponentdetailcode")private int ntemplatesubcomponentdetailcode;
	@Column(name = "npropertiescode")private int npropertiescode;
	@Column(name = "spropertiesvalue")private String spropertiesvalue;
	@Column(name = "nstatus")private int nstatus;
	
	
	public int getntemplatesubcomponentpropertiesdetailcode() {
		return ntemplatesubcomponentpropertiesdetailcode;
	}
	public void setntemplatesubcomponentpropertiesdetailcode(
			int ntemplatesubcomponentpropertiesdetailcode) {
		this.ntemplatesubcomponentpropertiesdetailcode = ntemplatesubcomponentpropertiesdetailcode;
	}
	public int getntemplatesubcomponentdetailcode() {
		return ntemplatesubcomponentdetailcode;
	}
	public void setntemplatesubcomponentdetailcode(
			int ntemplatesubcomponentdetailcode) {
		this.ntemplatesubcomponentdetailcode = ntemplatesubcomponentdetailcode;
	}
	public int getnpropertiescode() {
		return npropertiescode;
	}
	public void setnpropertiescode(int npropertiescode) {
		this.npropertiescode = npropertiescode;
	}
	public String getspropertiesvalue() {
		return spropertiesvalue;
	}
	public void setspropertiesvalue(String spropertiesvalue) {
		this.spropertiesvalue = spropertiesvalue;
	}
	public int getnstatus() {
		return nstatus;
	}
	public void setnstatus(int nstatus) {
		this.nstatus = nstatus;
	}
	
	
	@Override
	public TemplateSubComponentPropertiesDetail mapRow(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {

		TemplateSubComponentPropertiesDetail objTemplateSubComponentPropertiesDetail = new TemplateSubComponentPropertiesDetail();
		objTemplateSubComponentPropertiesDetail.setntemplatesubcomponentpropertiesdetailcode(objMapper.getInteger("ntemplatesubcomponentpropertiesdetailcode"));
		objTemplateSubComponentPropertiesDetail.setntemplatesubcomponentdetailcode(objMapper.getInteger("ntemplatesubcomponentdetailcode"));
		objTemplateSubComponentPropertiesDetail.setnpropertiescode(objMapper.getInteger("npropertiescode"));
		objTemplateSubComponentPropertiesDetail.setspropertiesvalue(objMapper.getString("spropertiesvalue"));
		objTemplateSubComponentPropertiesDetail.setnstatus(objMapper.getInteger("nstatus"));
		
		return objTemplateSubComponentPropertiesDetail;
	}
	@Override
	public String isActiveFilter(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}
}

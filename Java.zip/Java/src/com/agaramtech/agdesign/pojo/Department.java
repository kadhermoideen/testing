package com.agaramtech.agdesign.pojo;

import java.io.Serializable;
import java.sql.SQLException;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.agaramtech.lims.dao.support.AgaramResultSetMapper;
import com.agaramtech.lims.dao.support.AgaramRowMapper;

@Entity
@Table(name="department")
@SuppressWarnings("serial")
public class Department  implements Serializable ,AgaramRowMapper<Department>{

	@Id
	@Column(name = "ndepartmentcode")private int ndepartmentcode;
	@Column(name = "sdeptmentname")private String sdeptmentname;
	@Column(name = "sdepartmentdesc")private String sdepartmentdesc;
	
	public int getndepartmentcode() {
		return ndepartmentcode;
	}

	public void setndepartmentcode(int ndepartmentcode) {
		this.ndepartmentcode = ndepartmentcode;
	}

	public String getsdeptmentname() {
		return sdeptmentname;
	}

	public void setsdeptmentname(String sdeptmentname) {
		this.sdeptmentname = sdeptmentname;
	}

	public String getsdepartmentdesc() {
		return sdepartmentdesc;
	}

	public void setsdepartmentdesc(String sdepartmentdesc) {
		this.sdepartmentdesc = sdepartmentdesc;
	}

	@Override
	public Department mapRow(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {
		
		Department objDepartment = new Department();
		objDepartment.setndepartmentcode(objMapper.getInteger("ndepartmentcode"));
		objDepartment.setsdeptmentname(objMapper.getString("sdeptmentname"));
		objDepartment.setsdepartmentdesc(objMapper.getString("sdepartmentdesc"));

		return objDepartment;
	}

	@Override
	public String isActiveFilter(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

}

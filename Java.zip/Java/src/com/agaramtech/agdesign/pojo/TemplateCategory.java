/**
 * @author C.Manikandan
 * @Date 22-May-2014
 * @time 11:25:15 AM
 */
package com.agaramtech.agdesign.pojo;

import java.io.Serializable;
import java.sql.SQLException;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.agaramtech.lims.dao.support.AgaramResultSetMapper;
import com.agaramtech.lims.dao.support.AgaramRowMapper;

@Entity
@Table(name="templatecategory")
@SuppressWarnings("serial")
public class TemplateCategory implements Serializable ,AgaramRowMapper<TemplateCategory> {

	@Id
	@Column(name = "ncategorycode")private int ncategorycode;
	@Column(name = "scategoryname")private String scategoryname; 
	@Column(name = "nstatus")private int nstatus;

	public int getncategorycode() {
		return ncategorycode;
	}

	public void setncategorycode(int ncategorycode) {
		this.ncategorycode = ncategorycode;
	}

	public String getscategoryname() {
		return scategoryname;
	}

	public void setscategoryname(String scategoryname) {
		this.scategoryname = scategoryname;
	}

	public int getnstatus() {
		return nstatus;
	}

	public void setnstatus(int nstatus) {
		this.nstatus = nstatus;
	}

	@Override
	public String isActiveFilter(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {
		objMapper.setfield("nstatus");
		objMapper.setvalue(1);
		return objMapper.toString();

	}

	@Override
	public TemplateCategory mapRow(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {
		TemplateCategory objTemplateCategory = new TemplateCategory();
		objTemplateCategory.setncategorycode(objMapper.getInteger("ncategorycode"));
		objTemplateCategory.setnstatus(objMapper.getInteger("nstatus"));
		objTemplateCategory.setscategoryname(objMapper.getString("scategoryname"));

		return objTemplateCategory;
	}

}

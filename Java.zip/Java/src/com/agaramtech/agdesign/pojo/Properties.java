/**
 * @author R.Manikandan
 * @Date 05-Aug-2014
 * @time 10:07:15 PM
 */
package com.agaramtech.agdesign.pojo;

import java.io.Serializable;
import java.sql.SQLException;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.agaramtech.lims.dao.support.AgaramResultSetMapper;
import com.agaramtech.lims.dao.support.AgaramRowMapper;

@Entity
@Table(name="properties")
@SuppressWarnings("serial")
public class Properties implements Serializable ,AgaramRowMapper<Properties> {

	@Id
	@Column(name = "npropertiescode")private int npropertiescode;
	@Column(name = "npropertytypecode")private int npropertytypecode;
	@Column(name = "spropertyname",length = 100)private String spropertyname;
	@Column(name = "sclassname",length = 255)private String sclassname;
	@Column(name = "sactualvalue",length = 100)private String sactualvalue;
	@Column(name = "nstatus")private int nstatus;

	public int getnpropertiescode() {
		return npropertiescode;
	}

	public void setnpropertiescode(int npropertiescode) {
		this.npropertiescode = npropertiescode;
	}

	public int getnpropertytypecode() {
		return npropertytypecode;
	}

	public void setnpropertytypecode(int npropertytypecode) {
		this.npropertytypecode = npropertytypecode;
	}

	public String getspropertyname() {
		return spropertyname;
	}

	public void setspropertyname(String spropertyname) {
		this.spropertyname = spropertyname;
	}

	public String getsclassname() {
		return sclassname;
	}

	public void setsclassname(String sclassname) {
		this.sclassname = sclassname;
	}

	public String getsactualvalue() {
		return sactualvalue;
	}

	public void setsactualvalue(String sactualvalue) {
		this.sactualvalue = sactualvalue;
	}

	public int getnstatus() {
		return nstatus;
	}

	public void setnstatus(int nstatus) {
		this.nstatus = nstatus;
	}


	@Override
	public Properties mapRow(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {

		Properties objProperties = new Properties();
		objProperties.setsclassname(objMapper.getString("sclassname"));
		objProperties.setnpropertiescode(objMapper.getInteger("npropertiescode"));
		objProperties.setspropertyname(objMapper.getString("spropertyname"));
		objProperties.setnstatus(objMapper.getInteger("nstatus"));
		objProperties.setnpropertytypecode(objMapper.getInteger("npropertytypecode"));
		objProperties.setsactualvalue(objMapper.getString("sactualvalue"));

		return objProperties;
	}

	@Override
	public String isActiveFilter(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

}

package com.agaramtech.agdesign.pojo;

import java.io.Serializable;
import java.sql.SQLException;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.agaramtech.lims.dao.support.AgaramResultSetMapper;
import com.agaramtech.lims.dao.support.AgaramRowMapper;

@Entity
@Table(name="sectionmaster")
@SuppressWarnings("serial")
public class SectionMaster  implements Serializable ,AgaramRowMapper<SectionMaster> {


	@Id
	@Column(name = "nsectioncode")private int nsectioncode;
	@Column(name = "ssectionname")private String ssectionname;
	@Column(name = "ssectiondesc")private String ssectiondesc;



	public int getnsectioncode() {
		return nsectioncode;
	}

	public void setnsectioncode(int nsectioncode) {
		this.nsectioncode = nsectioncode;
	}

	public String getssectionname() {
		return ssectionname;
	}

	public void setssectionname(String ssectionname) {
		this.ssectionname = ssectionname;
	}

	public String getssectiondesc() {
		return ssectiondesc;
	}

	public void setssectiondesc(String ssectiondesc) {
		this.ssectiondesc = ssectiondesc;
	}

	@Override
	public SectionMaster mapRow(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {
		SectionMaster objSectionMaster = new SectionMaster();


		objSectionMaster.setnsectioncode(objMapper.getInteger("nsectioncode"));
		objSectionMaster.setssectionname(objMapper.getString("ssectionname"));
		objSectionMaster.setssectiondesc(objMapper.getString("ssectiondesc"));

		return objSectionMaster;
	}

	@Override
	public String isActiveFilter(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

}

/**
 * @author C.Manikandan
 * @Date 22-May-2014
 * @time 11:25:15 AM
 */
package com.agaramtech.agdesign.pojo;

import java.io.Serializable;
import java.sql.SQLException;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.agaramtech.lims.dao.support.AgaramResultSetMapper;
import com.agaramtech.lims.dao.support.AgaramRowMapper;

@Entity
@Table(name="template")
@SuppressWarnings("serial")
public class Template implements Serializable ,AgaramRowMapper<Template> {

	@Id
	@Column(name = "ntemplatecode")private int ntemplatecode;
	@Column(name = "stemplatename")private String stemplatename;
	@Column(name = "ncategorycode")private int ncategorycode;
	@Column(name = "sicon")private String sicon;
	@Column(name = "sclassname",length=100)private String sclassname;	
	@Column(name = "nversioncode",length=100)private int nversioncode;	   
	@Column(name = "nstatus")private int nstatus;
	
	transient private String stitlename;
	transient private int ntemplatedetailcode;

	public String getstitlename() {
		return stitlename;
	}
	public void setstitlename(String stitlename) {
		this.stitlename = stitlename;
	}
	public int getntemplatedetailcode() {
		return ntemplatedetailcode;
	}
	public void setntemplatedetailcode(int ntemplatedetailcode) {
		this.ntemplatedetailcode = ntemplatedetailcode;
	}
	public String getsicon() {
		return sicon;
	}

	public void setsicon(String sicon) {
		this.sicon = sicon;
	}
	
	public String getsclassname() {
		return sclassname;
	}

	public void setsclassname(String sclassname) {
		this.sclassname = sclassname;
	}

	public int getntemplatecode() {
		return ntemplatecode;
	}

	public void setntemplatecode(int ntemplatecode) {
		this.ntemplatecode = ntemplatecode;
	}

	public String getstemplatename() {
		return stemplatename;
	}

	public void setstemplatename(String stemplatename) {
		this.stemplatename = stemplatename;
	}

	public int getncategorycode() {
		return ncategorycode;
	}

	public void setncategorycode(int ncategorycode) {
		this.ncategorycode = ncategorycode;
	}

	public int getnversioncode() {
		return nversioncode;
	}

	public void setnversioncode(int nversioncode) {
		this.nversioncode = nversioncode;
	}

	public int getnstatus() {
		return nstatus;
	}

	public void setnstatus(int nstatus) {
		this.nstatus = nstatus;
	}

	@Override
	public String isActiveFilter(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {
		objMapper.setfield("nstatus");
		objMapper.setvalue(1);
		return objMapper.toString();

	}

	@Override
	public Template mapRow(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {
		Template objTemplate = new Template();
		objTemplate.setntemplatecode(objMapper.getInteger("ntemplatecode"));
		objTemplate.setntemplatedetailcode(objMapper.getInteger("ntemplatedetailcode"));
		objTemplate.setnstatus(objMapper.getInteger("nstatus"));
		objTemplate.setstemplatename(objMapper.getString("stemplatename"));
		objTemplate.setnversioncode(objMapper.getInteger("nversioncode"));
		objTemplate.setsicon(objMapper.getString("sicon"));
		objTemplate.setsclassname(objMapper.getString("sclassname"));
		objTemplate.setstitlename(objMapper.getString("stitlename"));
		objTemplate.setncategorycode(objMapper.getInteger("ncategorycode"));
		return objTemplate;
	}

}

package com.agaramtech.agdesign.pojo;

import java.io.Serializable;
import java.sql.SQLException;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.agaramtech.lims.dao.support.AgaramResultSetMapper;
import com.agaramtech.lims.dao.support.AgaramRowMapper;

@Entity
@Table(name="tabtemplatedetail")
@SuppressWarnings("serial")
public class TabTemplateDetail implements Serializable ,AgaramRowMapper<TabTemplateDetail> {

	@Id
	@Column(name = "ntabtemplatedetailcode")private int ntabtemplatedetailcode;
	@Column(name = "ntemplatedetailcode")private int ntemplatedetailcode;
	@Column(name = "ntemplatecode")private int ntemplatecode;  
	@Column(name = "nstatus")private int nstatus;
	
	public int getntabtemplatedetailcode() {
		return ntabtemplatedetailcode;
	}
	public void setntabtemplatedetailcode(int ntabtemplatedetailcode) {
		this.ntabtemplatedetailcode = ntabtemplatedetailcode;
	}
	public int getntemplatedetailcode() {
		return ntemplatedetailcode;
	}
	public void setntemplatedetailcode(int ntemplatedetailcode) {
		this.ntemplatedetailcode = ntemplatedetailcode;
	}
	public int getntemplatecode() {
		return ntemplatecode;
	}
	public void setntemplatecode(int ntemplatecode) {
		this.ntemplatecode = ntemplatecode;
	}
	public int getnstatus() {
		return nstatus;
	}
	public void setnstatus(int nstatus) {
		this.nstatus = nstatus;
	}
	
	
	@Override
	public String isActiveFilter(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {
		objMapper.setfield("nstatus");
		objMapper.setvalue(1);
		return objMapper.toString();

	}

	@Override
	public TabTemplateDetail mapRow(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {
		TabTemplateDetail objTabTemplateDetail = new TabTemplateDetail();
		objTabTemplateDetail.setntabtemplatedetailcode(objMapper.getInteger("ntabtemplatedetailcode"));
		objTabTemplateDetail.setntemplatedetailcode(objMapper.getInteger("ntemplatedetailcode"));
		objTabTemplateDetail.setntemplatecode(objMapper.getInteger("ntemplatecode"));
		objTabTemplateDetail.setnstatus(objMapper.getInteger("nstatus"));
		
		return objTabTemplateDetail;
	}


}

package com.agaramtech.agdesign.pojo;

import java.io.Serializable;



@SuppressWarnings("serial")
public class ComponentSubNodeMapping implements Serializable {

	private String id;
	private String name;
	private String classname;
	private String parameterindex;
	private String service;
	private String method;
	private String javaclass;
	private String datatype;
	private String fieldname;
	private String propertiescode;
	private String serviceid;
	
	public String getserviceid() {
		return serviceid;
	}
	public void setserviceid(String serviceid) {
		this.serviceid = serviceid;
	}
	public String getpropertiescode() {
		return propertiescode;
	}
	public void setpropertiescode(String propertiescode) {
		this.propertiescode = propertiescode;
	}
	public String getid() {
		return id;
	}
	public void setid(String id) {
		this.id = id;
	}
	public String getname() {
		return name;
	}
	public void setname(String name) {
		this.name = name;
	}
	public String getclassname() {
		return classname;
	}
	public void setclassname(String classname) {
		this.classname = classname;
	}
	public String getparameterindex() {
		return parameterindex;
	}
	public void setparameterindex(String parameterindex) {
		this.parameterindex = parameterindex;
	}
	public String getservice() {
		return service;
	}
	public void setservice(String service) {
		this.service = service;
	}
	public String getmethod() {
		return method;
	}
	public void setmethod(String method) {
		this.method = method;
	}
	public String getjavaclass() {
		return javaclass;
	}
	public void setjavaclass(String javaclass) {
		this.javaclass = javaclass;
	}
	public String getdatatype() {
		return datatype;
	}
	public void setdatatype(String datatype) {
		this.datatype = datatype;
	}
	public String getfieldname() {
		return fieldname;
	}
	public void setfieldname(String fieldname) {
		this.fieldname = fieldname;
	}



}

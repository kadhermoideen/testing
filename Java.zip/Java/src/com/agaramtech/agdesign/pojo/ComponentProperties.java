/**
 * @author R.Manikandan
 * @Date 04-Aug-2014
 * @time 05:01:15 PM
 */
package com.agaramtech.agdesign.pojo;

import java.io.Serializable;
import java.sql.SQLException;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.agaramtech.lims.dao.support.AgaramResultSetMapper;
import com.agaramtech.lims.dao.support.AgaramRowMapper;

@Entity
@Table(name="componentproperties")
@SuppressWarnings("serial")
public class ComponentProperties implements Serializable ,AgaramRowMapper<ComponentProperties> {

	@Id
	@Column(name = "ncomponentpropertycode")private int ncomponentpropertycode;
	@Column(name = "ncomponentcode")private int ncomponentcode;
	@Column(name = "npropertiescode")private int npropertiescode;
	@Column(name = "sdefaultvalue",length = 100)private String sdefaultvalue;	   
	@Column(name = "nstatus")private int nstatus;
	@Column(name = "nuniquepropertycode")private int nuniquepropertycode;

	transient
	private int npropertytypecode;

	transient
	private String spropertyname;



	public int getncomponentpropertycode() {
		return ncomponentpropertycode;
	}
	public void setncomponentpropertycode(int ncomponentpropertycode) {
		this.ncomponentpropertycode = ncomponentpropertycode;
	}
	public int getncomponentcode() {
		return ncomponentcode;
	}
	public void setncomponentcode(int ncomponentcode) {
		this.ncomponentcode = ncomponentcode;
	}
	public int getnpropertiescode() {
		return npropertiescode;
	}
	public void setnpropertiescode(int npropertiescode) {
		this.npropertiescode = npropertiescode;
	}
	public String getsdefaultvalue() {
		return sdefaultvalue;
	}
	public void setsdefaultvalue(String sdefaultvalue) {
		this.sdefaultvalue = sdefaultvalue;
	}
	public int getnstatus() {
		return nstatus;
	}
	public void setnstatus(int nstatus) {
		this.nstatus = nstatus;
	}
	public int getnpropertytypecode() {
		return npropertytypecode;
	}
	public void setnpropertytypecode(int npropertytypecode) {
		this.npropertytypecode = npropertytypecode;
	}
	public String getspropertyname() {
		return spropertyname;
	}
	public void setspropertyname(String spropertyname) {
		this.spropertyname = spropertyname;
	}

	public int getnuniquepropertycode() {
		return nuniquepropertycode;
	}
	public void setnuniquepropertycode(int nuniquepropertycode) {
		this.nuniquepropertycode = nuniquepropertycode;
	}
	@Override
	public ComponentProperties mapRow(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {

		ComponentProperties objComponentProperties = new ComponentProperties();
		objComponentProperties.setncomponentpropertycode(objMapper.getInteger("ncomponentpropertycode"));
		objComponentProperties.setsdefaultvalue(objMapper.getString("sdefaultvalue"));
		objComponentProperties.setnstatus(objMapper.getInteger("nstatus"));
		objComponentProperties.setncomponentcode(objMapper.getInteger("ncomponentcode"));
		objComponentProperties.setnpropertiescode(objMapper.getInteger("npropertiescode"));
		objComponentProperties.setnuniquepropertycode(objMapper.getInteger("nuniquepropertycode"));

		objComponentProperties.setnpropertytypecode(objMapper.getInteger("npropertytypecode"));
		objComponentProperties.setspropertyname(objMapper.getString("spropertyname"));

		return objComponentProperties;
	}
	@Override
	public String isActiveFilter(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}




}

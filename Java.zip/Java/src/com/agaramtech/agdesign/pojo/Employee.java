package com.agaramtech.agdesign.pojo;

import java.io.Serializable;
import java.sql.SQLException;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.agaramtech.lims.dao.support.AgaramResultSetMapper;
import com.agaramtech.lims.dao.support.AgaramRowMapper;

@Entity
@Table(name="employee")
@SuppressWarnings("serial")
public class Employee implements Serializable ,AgaramRowMapper<Employee>{

	@Id
	@Column(name = "nemployeecode")private int nemployeecode;
	@Column(name = "ndepartmentcode")private int ndepartmentcode;
	@Column(name = "semployeename")private String semployeename;
	@Column(name = "semployeedesc")private String semployeedesc;
 
	public int getnemployeecode() {
		return nemployeecode;
	}
	public void setnemployeecode(int nemployeecode) {
		this.nemployeecode = nemployeecode;
	}
	public int getndepartmentcode() {
		return ndepartmentcode;
	}
	public void setndepartmentcode(int ndepartmentcode) {
		this.ndepartmentcode = ndepartmentcode;
	}
	public String getsemployeename() {
		return semployeename;
	}
	public void setsemployeename(String semployeename) {
		this.semployeename = semployeename;
	}
	public String getsemployeedesc() {
		return semployeedesc;
	}
	public void setsemployeedesc(String semployeedesc) {
		this.semployeedesc = semployeedesc;
	}
	@Override
	public Employee mapRow(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {
		Employee objEmployee = new Employee();
		
		objEmployee.setnemployeecode(objMapper.getInteger("nemployeecode"));
		objEmployee.setndepartmentcode(objMapper.getInteger("ndepartmentcode"));
		objEmployee.setsemployeename(objMapper.getString("semployeename"));
		objEmployee.setsemployeedesc(objMapper.getString("semployeedesc"));

		return objEmployee;
	}
	@Override
	public String isActiveFilter(AgaramResultSetMapper<Object> objMapper)
			throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}


}

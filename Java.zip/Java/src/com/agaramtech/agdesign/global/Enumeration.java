package com.agaramtech.agdesign.global;

public class Enumeration {

	public enum TransactionStatus
	{
		NA(-1),
		DELETED(-1),
		ACTIVE(1),
		DEACTIVE(2),
		YES(3),
		NO(4),
		LOCK(5),
		UNLOCK(6),
		RETIRED(7),
		DRAFT(8),
		MANUAL(9),
		SYSTEM(10),
		START(11),
		RESTART(12),
		STOP(13),
		RECEIVED(14),
		GOODS_IN(15),
		GOODS_RECEIVED(16),
		PREREGISTER(17),
		REGISTERED(18),
		RECIEVED_IN_LAB(19),
		ALLOTTED(20),
		PARTIALLY(21),
		COMPLETED(22),
		CHECKED(23),
		REVIEWED(24),
		VERIFIED(25),
		APPROVED(26),
		AUTHORISED(27),
		RELEASED(28),
		RECOM_RETEST(29),
		RECOM_RECALC(30),
		RETEST(31),
		RECALC(32),
		REJECTED(33),
		CANCELED(34),
		HOLD(35),
		RESERVED(36),
		QUARENTINE(37),
		SCHEDULED(38),
		RE_SCHEDULED(39),
		INVITED(40),
		ACCEPTED(41),
		INITIATED(42),
		ADD(43),
		EDIT(44),
		DELETE(45),
		DEFAULT(46),
		RECEIVE(47),
		ISSUE(48),
		AUTO(49),
		PASS(50),
		FAIL(51),
		WITHDRAWN(52),
		CORRECTION(53),
		CERTIFIED(54);

		private final int transactionstatus;  

		private TransactionStatus(int transactionstatus) {
			this.transactionstatus = transactionstatus;
		}

		public int gettransactionstatus() {
			return transactionstatus;
		}
	}

	public enum TemplateType
	{
		SCREEN_TEMPLATE(1,"Screen"),
		POPUP_TEMPLATE(2,"PopUp");

		private final int templatetype; 
		private final String templatetypename; 

		private TemplateType(int templatetype,String templatetypename) {
			this.templatetype = templatetype;
			this.templatetypename = templatetypename;
		}

		public int gettemplatetype() {
			return templatetype;
		}
		public String gettemplatetypename() {
			return templatetypename;
		}
	}

	public enum Properties
	{
		SERVICE(20,"service"),
		SUBMIT(7,"submit"),
		CLOSE(30,"close"),
		LABEL(13,"label"),
		METHOD(21,"method");

		private final int propertiescode; 
		private final String propertiesname; 

		private Properties(int propertiescode,String propertiesname) {
			this.propertiescode = propertiescode;
			this.propertiesname = propertiesname;
		}

		public int getpropertiescode() {
			return propertiescode;
		}
		public String getpropertiesname() {
			return propertiesname;
		}
	}


	public enum SystemComponets
	{
		SUBMIT_BUTTON(20,"Submit"),
		CLOSE_BUTTON(21,"Close");

		private final int componentcode; 
		private final String componentname; 

		private SystemComponets(int componentcode,String componentname) {
			this.componentcode = componentcode;
			this.componentname = componentname;
		}

		public int getcomponentcode() {
			return componentcode;
		}
		public String getcomponentname() {
			return componentname;
		}
	}

	public enum PropertyType
	{
		STYLE(1,"Style"),
		EVENT(2,"Event"),
		DATASOURCE(3,"Datasource"),
		COMMON(4,"Common");

		private final int propertypecode; 
		private final String propertypename; 

		private PropertyType(int propertypecode,String propertypename) {
			this.propertypecode = propertypecode;
			this.propertypename = propertypename;
		}

		public int getpropertypecode() {
			return propertypecode;
		}

		public String getpropertypename() {
			return propertypename;
		}


	}

}

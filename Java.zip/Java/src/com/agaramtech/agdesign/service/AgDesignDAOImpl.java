/**
 * @author S.Kadher Moideen
 */
package com.agaramtech.agdesign.service;

import java.io.ByteArrayInputStream;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.transaction.annotation.Transactional;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;

import com.agaramtech.agdesign.global.Enumeration;
import com.agaramtech.agdesign.pojo.ComponentNodeMapping;
import com.agaramtech.agdesign.pojo.ComponentProperties;
import com.agaramtech.agdesign.pojo.ComponentSubNodeMapping;
import com.agaramtech.agdesign.pojo.Components;
import com.agaramtech.agdesign.pojo.ConditionalArgument;
import com.agaramtech.agdesign.pojo.Department;
import com.agaramtech.agdesign.pojo.Employee;
import com.agaramtech.agdesign.pojo.ListMappingPropertiesDetail;
import com.agaramtech.agdesign.pojo.Operators;
import com.agaramtech.agdesign.pojo.PropertiesScreen;
import com.agaramtech.agdesign.pojo.SectionMaster;
import com.agaramtech.agdesign.pojo.SequencenoGenerator;
import com.agaramtech.agdesign.pojo.Template;
import com.agaramtech.agdesign.pojo.TemplateComponentDetail;
import com.agaramtech.agdesign.pojo.TemplateComponentEventDetail;
import com.agaramtech.agdesign.pojo.TemplateComponentEventPropertiesDetail;
import com.agaramtech.agdesign.pojo.TemplateComponentGroupDetail;
import com.agaramtech.agdesign.pojo.TemplateComponentPropertiesDetail;
import com.agaramtech.agdesign.pojo.TemplateDetail;
import com.agaramtech.agdesign.pojo.TemplateParameterEventDetail;
import com.agaramtech.agdesign.pojo.TemplateSubComponentDetail;
import com.agaramtech.agdesign.pojo.TemplateSubComponentPropertiesDetail;
import com.agaramtech.agdesign.pojo.TemplateSubParameterEventDetail;
import com.agaramtech.lims.dao.support.AgaramDaoSupport;
import com.agaramtech.lims.dao.support.AgaramEntityMethods;
import com.agaramtech.lims.dao.support.bridge.RDBMSBridge;
import com.agaramtech.lims.dao.support.bridge.RDBMSParameter;
import com.agaramtech.lims.dao.support.enums.RDBMSEnum;
import com.agaramtech.lims.dao.support.global.AgaramtechGeneralfunction;

import flex.messaging.io.ArrayCollection;
@SuppressWarnings("all")
@Transactional(rollbackFor = Exception.class)
public class AgDesignDAOImpl extends AgaramDaoSupport implements AgDesignDAO{

	final Log logging = LogFactory.getLog(AgDesignDAOImpl.class);

	private static int dataBaseType = 0;
	private final AgaramtechGeneralfunction objGeneral;
	private final java.util.Properties objProperties;
	private Map<String,List<?>> mapList = null;
	private final Map<String,Object> mapObject = null;
	private final StringBuilder xmlBuilderManip = new StringBuilder();

	public AgDesignDAOImpl(RDBMSParameter objParameter,AgaramtechGeneralfunction objGeneral,java.util.Properties objProperties) {
		super(objParameter,objGeneral);
		if(objParameter.getsdatabasetype().equals(RDBMSEnum.DB_MYSQL.getDataBaseType())) {
			dataBaseType = RDBMSEnum.DB_MYSQL.getType();
		} else if(objParameter.getsdatabasetype().equals(RDBMSEnum.DB_POSTGRESQL.getDataBaseType())) {
			dataBaseType = RDBMSEnum.DB_POSTGRESQL.getType();
		} else if(objParameter.getsdatabasetype().equals(RDBMSEnum.DB_MICROSOFT_SQL_SERVER.getDataBaseType())) {
			dataBaseType = RDBMSEnum.DB_MICROSOFT_SQL_SERVER.getType();
		} else if(objParameter.getsdatabasetype().equals(RDBMSEnum.DB_ORACLE.getDataBaseType())) {
			dataBaseType = RDBMSEnum.DB_ORACLE.getType();
		}
		this.objGeneral = objGeneral;
		this.objProperties = objProperties;
		RDBMSBridge.dataBaseType = dataBaseType;
	}

	@Override
	public String getAgDesignPreInitialize() throws Exception {
		String xml = getTreeNode();

		if(xml != "")
			return xml;
		else
			return null;

	}

	Map<Integer, String> objTreeMap = null;
	private String getTreeNode() throws Exception{

		Map<String,List<?>>  map = findByMultiTablesPlainSql("Select * from Components where nstatus="+Enumeration.TransactionStatus.ACTIVE.gettransactionstatus()+";"
				+ " Select * from Template where nstatus="+Enumeration.TransactionStatus.ACTIVE.gettransactionstatus()+" and ncategorycode="+Enumeration.TemplateType.SCREEN_TEMPLATE.gettemplatetype()+";", Components.class,Template.class);
		map.put("PopUpTemplate", findBySinglePlainSql(" Select * from Template where nstatus="+Enumeration.TransactionStatus.ACTIVE.gettransactionstatus()+" and ncategorycode="+Enumeration.TemplateType.POPUP_TEMPLATE.gettemplatetype()+" ", Template.class));
		StringBuilder objBuilder = new StringBuilder();
		if(map != null){
			if(map.size() > 0){
				String query = null;
				Iterator<Map.Entry<String, List<?>>> entries = map.entrySet().iterator();
				while (entries.hasNext()) {
					Map.Entry<String, List<?>> entry = entries.next();
					objBuilder.append(getChildNode(entry.getKey(),entry.getValue()));
				}

			}
		}

		return objBuilder.toString();
	}

	private String getChildNode(String key,List lst){
		String root = "";
		switch(key){
		case "Components":{
			root = "<node name='"+key+"'>";
			for(Iterator<Components> iterator = lst.iterator(); iterator.hasNext();) {
				Components objComponents = iterator.next();
				root = root +"<node nprimarycode='"+objComponents.getncomponentcode()+"' icon='"+objComponents.getsicon()+"' name='"+objComponents.getscomponentname()+"' classname='"+objComponents.getsclassname()+"'></node>";
			}
			root = root + "</node>";

			logging.info(root);
		}
		break;
		case "Template":{
			root = "<node name='"+"Screen"+key+"'>";
			for(Iterator<Template> iterator = lst.iterator(); iterator.hasNext();) {
				Template objTemplate = iterator.next();
				root = root +"<node nprimarycode='"+objTemplate.getntemplatecode()+"' icon='"+objTemplate.getsicon()+"' name='"+objTemplate.getstemplatename()+"' classname='"+objTemplate.getsclassname()+"'></node>";
			}
			root = root + "</node>";
			logging.info(root);
		}
		break;
		case "PopUpTemplate":{
			root = "<node name='"+key+"'>";
			for(Iterator<Template> iterator = lst.iterator(); iterator.hasNext();) {
				Template objTemplate = iterator.next();
				root = root +"<node nprimarycode='"+objTemplate.getntemplatecode()+"' icon='"+objTemplate.getsicon()+"' name='"+objTemplate.getstemplatename()+"' classname='"+objTemplate.getsclassname()+"'></node>";
			}
			root = root + "</node>";
			logging.info(root);
		}
		break;
		default:
			break;
		}
		return root;
	}

	@Override
	public String getAgViewerPreInitialize() throws Exception {
		String xml = getViewerTreeNode();

		if(xml != "")
			return xml;
		else
			return null;

	}

	@Override
	public String getPopUpEventProperties() throws Exception {
		String xml = getPopUpEventTreeNode();

		if(xml != "")
			return xml;
		else
			return null;

	}

	private String getPopUpEventTreeNode() throws Exception{
		mapList = new TreeMap<String,List<?>>();
		mapList.put("PopUpTemplate", findBySinglePlainSql(" select t.ntemplatecode,t.stemplatename,t.sicon,t.sclassname,td.ntemplatedetailcode from template t,templatedetail td "
				+ "where t.ntemplatecode=td.ntemplatecode and t.nstatus="+Enumeration.TransactionStatus.ACTIVE.gettransactionstatus()+" and "
				+ "td.nstatus="+Enumeration.TransactionStatus.ACTIVE.gettransactionstatus()+" and td.ntypecode = "+Enumeration.TemplateType.POPUP_TEMPLATE.gettemplatetype()+" ", Template.class));
		StringBuilder objBuilder = new StringBuilder();
		if(mapList != null){
			if(mapList.size() > 0){
				String query = null;
				Iterator<Map.Entry<String, List<?>>> entries = mapList.entrySet().iterator();
				while (entries.hasNext()) {
					Map.Entry<String, List<?>> entry = entries.next();
					objBuilder.append(getViewerChildNode(entry.getKey(),entry.getValue()));
				}

			}
		}

		return objBuilder.toString();
	}


	private String getViewerTreeNode() throws Exception{
		Map<String,List<?>>  map = findByMultiTablesPlainSql("select t.ntemplatecode,t.stemplatename,t.sicon,t.sclassname,td.ntemplatedetailcode from template t,templatedetail td where "
				+ " t.ntemplatecode=td.ntemplatecode and t.nstatus="+Enumeration.TransactionStatus.ACTIVE.gettransactionstatus()+" "
				+ "and td.nstatus="+Enumeration.TransactionStatus.ACTIVE.gettransactionstatus()+" and td.ntypecode = "+Enumeration.TemplateType.SCREEN_TEMPLATE.gettemplatetype()+";",Template.class);

		map.put("PopUpTemplate", findBySinglePlainSql(" select t.ntemplatecode,t.stemplatename,t.sicon,t.sclassname,td.ntemplatedetailcode from template t,templatedetail td "
				+ "where t.ntemplatecode=td.ntemplatecode and t.nstatus="+Enumeration.TransactionStatus.ACTIVE.gettransactionstatus()+" and "
				+ "td.nstatus="+Enumeration.TransactionStatus.ACTIVE.gettransactionstatus()+" and td.ntypecode = "+Enumeration.TemplateType.POPUP_TEMPLATE.gettemplatetype()+" ", Template.class));
		StringBuilder objBuilder = new StringBuilder();
		if(map != null){
			if(map.size() > 0){
				String query = null;
				Iterator<Map.Entry<String, List<?>>> entries = map.entrySet().iterator();
				while (entries.hasNext()) {
					Map.Entry<String, List<?>> entry = entries.next();
					objBuilder.append(getViewerChildNode(entry.getKey(),entry.getValue()));
				}

			}
		}

		return objBuilder.toString();
	}

	private String getViewerChildNode(String key,List lst){
		String root = "";
		switch(key){
		case "Template":{
			root = "<node name='"+"Screen"+key+"'>";
			for(Iterator<Template> iterator = lst.iterator(); iterator.hasNext();) {
				Template objTemplate = iterator.next();
				root = root +"<node nprimarycode='"+objTemplate.getntemplatecode()+"' ntemplatedetailcode='"+objTemplate.getntemplatedetailcode()+"' icon='"+objTemplate.getsicon()+"' name='"+objTemplate.getstemplatename()+"' classname='"+objTemplate.getsclassname()+"'></node>";
			}
			root = root + "</node>";
			logging.info(root);
		}
		break;
		case "PopUpTemplate":{
			root = "<node name='"+key+"'>";
			for(Iterator<Template> iterator = lst.iterator(); iterator.hasNext();) {
				Template objTemplate = iterator.next();
				root = root +"<node nprimarycode='"+objTemplate.getntemplatecode()+"' ntemplatedetailcode='"+objTemplate.getntemplatedetailcode()+"' icon='"+objTemplate.getsicon()+"' name='"+objTemplate.getstemplatename()+"' classname='"+objTemplate.getsclassname()+"'></node>";
			}
			root = root + "</node>";
			logging.info(root);
		}
		break;
		default:
			break;
		}
		return root;
	}


	@Override
	public List<PropertiesScreen> getPropertiesScreen() throws Exception {
		return (List<PropertiesScreen>) findBySinglePlainSql("Select npropertiesscreencode,sclassname,sname from PropertiesScreen where nstatus="+Enumeration.TransactionStatus.ACTIVE.gettransactionstatus()+"", PropertiesScreen.class);
	}

	@Override
	public List<AgaramEntityMethods> getService() throws Exception {

		return objGeneral.getService();
	}

	@Override
	public String getServiceXML() throws Exception {

		return objGeneral.getServiceXML();
	}

	@Override
	public List<AgaramEntityMethods> getServicePublicMethod(String strService) throws Exception {

		return objGeneral.getServicePublicMethod(strService);
	}

	@Override
	public List<AgaramEntityMethods> getMethodParameter(String strService,String strMethod)   throws Exception{
		return objGeneral.getMethodParameter(strService,strMethod);
	}

	@Override
	public String getEntityXML() throws Exception {
		return objGeneral.getEntityXML();
	}

	@Override
	public String getFieldsXML(String classname) throws Exception {
		return objGeneral.getFieldsXML(classname);
	}


	@Override
	public String getComponentsXML(String dataProviderXML,String findXML,String insertXML,String id) throws Exception {

		int replaceindex = findXML.indexOf("/>");

		int inserxmlIndex = insertXML.indexOf("/>");
		insertXML = insertXML.substring(0, inserxmlIndex) + " "+ "id=\""+id+"\"" + "/>";
		String insert=findXML.substring(0,replaceindex) + ">" + insertXML +"</node>";

		logging.info("dataProviderXML---->"+dataProviderXML);
		logging.info("findXML---->"+findXML);
		logging.info("insertXML---->"+insertXML);
		logging.info("insert---->"+insert);

		String lowerCase = dataProviderXML.toLowerCase();
		String find = findXML.replaceAll("\"", "");
		int index = lowerCase.indexOf(findXML.toLowerCase());
		if(index > -1){
			String findText= dataProviderXML.substring(index);
			logging.info("findText---->"+findText);
			int textLastIndex = findText.indexOf("/>");
			String actualText=dataProviderXML.substring(index,index+(textLastIndex+2));
			logging.info("actualText---->"+actualText);
			actualText = actualText.replaceAll("\"", "");
			if(actualText.equalsIgnoreCase(find)){
				dataProviderXML = dataProviderXML.substring(0,index)+""+insert+""+dataProviderXML.substring(index+(textLastIndex+2),dataProviderXML.length());  
				logging.info("ada  sdfsdf  taProviderXML---->"+dataProviderXML);
			}
			System.err.println(dataProviderXML);
		}

		logging.info("dataProviderXML Final---->"+dataProviderXML);
		return dataProviderXML;
	}

	@Override
	public String getComponentsVariableXML(String dataProviderXML,String findXML,int itemIndex) throws Exception {

		String xml = "<node name='++ Variables'>";
		for(int i = 0; i<itemIndex; i++){
			xml = xml + "<node propertiescode='-1' templatecode='-1' componentdetailcode='-1' id='Variable"+i+"' componentname='System-Variable' name='Variable-"+i+"' classname='java.lang.Object'></node>";
		}
		xml = xml + "</node>";


		String lowerCase = dataProviderXML.toLowerCase();
		String find = findXML.replaceAll("\"", "");
		int index = lowerCase.indexOf(findXML.toLowerCase());
		if(index > -1){
			String findText= dataProviderXML.substring(index);
			logging.info("findText---->"+findText);
			String actualText=dataProviderXML.substring(index,index+findText.length());
			logging.info("actualText---->"+actualText);
			actualText = actualText.replaceAll("\"", "");
			if(actualText.equalsIgnoreCase(find)){
				dataProviderXML = dataProviderXML.substring(0,index)+""+xml+""+dataProviderXML.substring(index+(findText.length()),dataProviderXML.length());  
				logging.info("ada  sdfsdf  taProviderXML---->"+dataProviderXML);
			}
			System.err.println(dataProviderXML);
		}

		logging.info("dataProviderXML Final---->"+dataProviderXML);
		return dataProviderXML;
	}

	@Override
	public String getParameterEntityFieldsXML(String dataProviderXML,String findXML,String classname,String oldXML,String oldClass) throws Exception{
		int replaceindex;
		String insert;
		String lowerCase;
		String find;
		int index;
		String findText;
		int textLastIndex;
		String actualText;
		if(oldXML != "" && oldClass != ""){

			logging.info("step one---->"+oldXML);
			logging.info("step two---->"+oldClass);
			replaceindex = oldXML.indexOf("/>");
			String replaced = oldXML.substring(0,replaceindex) + ">";
			insert=oldXML.substring(0,replaceindex) + ">" + objGeneral.getEntityFieldsXML1(oldClass) +"</node>";

			lowerCase = dataProviderXML.toLowerCase();

			index = lowerCase.indexOf(replaced.toLowerCase());
			if(index > -1){
				findText= dataProviderXML.substring(index);
				textLastIndex = findText.indexOf("</node>");				
				logging.info("textLastIndex---->"+textLastIndex);
				//	if(actualText1.equalsIgnoreCase(find)){

				dataProviderXML = dataProviderXML.substring(0,index)+""+oldXML+""+dataProviderXML.substring(index+(textLastIndex+7),dataProviderXML.length());  

				System.err.println(dataProviderXML);

			}
		}
		replaceindex = findXML.indexOf("/>");
		insert=findXML.substring(0,replaceindex) + ">" + objGeneral.getEntityFieldsXML(classname) +"</node>";

		logging.info("dataProviderXML---->"+dataProviderXML);
		logging.info("findXML---->"+findXML);
		logging.info("insertXML---->"+classname);
		logging.info("insert---->"+insert);

		lowerCase = dataProviderXML.toLowerCase();
		find = findXML.replaceAll("\"", "");
		index = lowerCase.indexOf(findXML.toLowerCase());
		if(index > -1){
			findText= dataProviderXML.substring(index);
			logging.info("findText---->"+findText);
			textLastIndex = findText.indexOf("/>");
			actualText=dataProviderXML.substring(index,index+(textLastIndex+2));
			logging.info("actualText---->"+actualText);
			actualText = actualText.replaceAll("\"", "");
			if(actualText.equalsIgnoreCase(find)){
				dataProviderXML = dataProviderXML.substring(0,index)+""+insert+""+dataProviderXML.substring(index+(textLastIndex+2),dataProviderXML.length());  
				logging.info("ada  sdfsdf  taProviderXML---->"+dataProviderXML);
			}
			System.err.println(dataProviderXML);
		}

		logging.info("dataProviderXML Final---->"+dataProviderXML);
		return dataProviderXML;
	}

	@Override
	public List<ComponentProperties> getControlsEvent(String scontrolclassname,int neventtype,int ntemplatecode)
			throws Exception {
		String str = null;
		if(scontrolclassname.equalsIgnoreCase(Enumeration.TemplateType.POPUP_TEMPLATE.gettemplatetypename())){

			str = "select cp.ntemplatepropertycode,c.ncategorycode,cp.npropertiescode,pr.npropertytypecode,pr.spropertyname from templateproperties cp,properties pr,template c "+
					" where c.ncategorycode = cp.ncategorycode and "+
					" c.ntemplatecode = cp.ntemplatecode and "+
					" pr.npropertiescode = cp.npropertiescode and cp.nstatus = "+Enumeration.TransactionStatus.ACTIVE.gettransactionstatus()+" and c.ntemplatecode="+ntemplatecode+" and cp.ncategorycode="+Enumeration.TemplateType.POPUP_TEMPLATE.gettemplatetype()+" ";
		}else if(scontrolclassname.equalsIgnoreCase(Enumeration.TemplateType.SCREEN_TEMPLATE.gettemplatetypename())){
			str = "select cp.ntemplatepropertycode,c.ncategorycode,cp.npropertiescode,pr.npropertytypecode,pr.spropertyname from templateproperties cp,properties pr,template c "+
					" where c.ncategorycode = cp.ncategorycode and "+
					" c.ntemplatecode = cp.ntemplatecode and "+
					" pr.npropertiescode = cp.npropertiescode and cp.nstatus = "+Enumeration.TransactionStatus.ACTIVE.gettransactionstatus()+" and c.ntemplatecode="+ntemplatecode+" and cp.ncategorycode="+Enumeration.TemplateType.SCREEN_TEMPLATE.gettemplatetype()+" ";

		}else{
			str = "select cp.ncomponentpropertycode,c.ncomponentcode,cp.npropertiescode,pr.npropertytypecode,pr.spropertyname,cp.nuniquepropertycode from componentproperties cp,properties pr,components c " +
					" where c.ncomponentcode = cp.ncomponentcode and pr.npropertiescode = cp.npropertiescode and c.sicon = '"+scontrolclassname+"' " +
					" and pr.npropertytypecode = "+neventtype+" and cp.nstatus = "+Enumeration.TransactionStatus.ACTIVE.gettransactionstatus();
		}
		logging.info("getControlsEvent str ---> "+str);

		return (List<ComponentProperties>) findBySinglePlainSql(str,ComponentProperties.class);
	}

	@Override
	public String getMethodXML(String classname) throws Exception {
		return objGeneral.getMethodXML(classname);
	}

	@Override
	public String getMethodParameterXML(String servicename, String methodname)
			throws Exception {
		return objGeneral.getMethodParameterXML(servicename,methodname);
	}

	@Override
	public String getMethodParameterWithEntitFieldsXML(String servicename, String methodname,String serviceid) throws Exception {
		return objGeneral.getMethodParameterWithEntityFieldsXML(servicename,methodname,serviceid);
	}

	@Override
	public String getReturnTypeXML(String strService, String strMethod,String serviceid)
			throws Exception {
		return objGeneral.getReturnTypeXML(strService,strMethod,serviceid);
	}

	@Override
	public String getConditionalArgument() throws Exception
	{
		String str = null;
		String root = "";
		str = "select nconditionalcode,sconditionalname,nstatus from conditionalargument where nstatus = "+Enumeration.TransactionStatus.ACTIVE.gettransactionstatus()+"";
		logging.info("getConditionalArgument str ---> "+str);
		//return (List<ConditionalArgument>) findBySinglePlainSql(str,ConditionalArgument.class);
		List<ConditionalArgument> lst = (List<ConditionalArgument>) findBySinglePlainSql(str,ConditionalArgument.class);


		root = "<node name='Conditional'>";


		for(Iterator<ConditionalArgument> iterator = lst.iterator(); iterator.hasNext();) 
		{
			ConditionalArgument objConditionalArgument = iterator.next();
			//root = root + " <node id = '"+ objConditionalArgument.getnconditionalcode() +"'  name = '"+ objConditionalArgument.getsconditionalname() +"' /></node>";
			root = root + " <node id = '"+ objConditionalArgument.getnconditionalcode() +"'  name = '"+ objConditionalArgument.getsconditionalname() +"' />";
		}
		root = root + "</node>";


		logging.info(root);
		return root;
	}

	@Override
	public String getOperators() throws Exception
	{
		String str = null;
		String root = "";
		str = "select noperatorscode,soperatorsname,ssyntax,nstatus from operators where nstatus  = "+Enumeration.TransactionStatus.ACTIVE.gettransactionstatus()+"";
		logging.info("getOperators str ---> "+str);
		//return (List<Operators>) findBySinglePlainSql(str,Operators.class);


		List<Operators> lst = (List<Operators>) findBySinglePlainSql(str,Operators.class);


		root = "<node name='Operators'>";


		for(Iterator<Operators> iterator = lst.iterator(); iterator.hasNext();) 
		{
			Operators objOperators = iterator.next();
			//root = root + " <node id = '"+ objConditionalArgument.getnconditionalcode() +"'  name = '"+ objConditionalArgument.getsconditionalname() +"' /></node>";
			root = root + " <node id = '"+ objOperators.getnoperatorscode() +"'  name = '"+ objOperators.getssyntax() +"' />";
		}
		root = root + "</node>";


		logging.info(root);
		return root;
	}

	//insertScreenTemplate
	//	@Override
	//	public List<Object> insertScreenTemplate(ScreenTemplateDetail objScreenTemplateDetail) throws Exception{
	//
	//		ScreenTemplateDetail obj = (ScreenTemplateDetail) insertObject(objScreenTemplateDetail, SequencenoGenerator.class, "nsequenceno");
	//
	//		List<Object> lst = new ArrayCollection();
	//
	//		lst.add(obj);
	//
	//		return lst;
	//	}

	private TreeMap<String,ComponentNodeMapping> map = null;
	private String firstKey = null;

	private void dumpLoop(Node node,String indent) {
		switch(node.getNodeType()) {
		case Node.CDATA_SECTION_NODE:
			System.out.println(indent + "CDATA_SECTION_NODE");
			break;
		case Node.COMMENT_NODE:
			System.out.println(indent + "COMMENT_NODE");
			break;
		case Node.DOCUMENT_FRAGMENT_NODE:
			System.out.println(indent + "DOCUMENT_FRAGMENT_NODE");
			break;
		case Node.DOCUMENT_NODE:
			System.out.println(indent + "DOCUMENT_NODE");
			break;
		case Node.DOCUMENT_TYPE_NODE:
			System.out.println(indent + "DOCUMENT_TYPE_NODE");
			break;
		case Node.ELEMENT_NODE:
			Element element = (Element) node;
			if (element.getNodeName().contains("node")) {

				if(!(element.getAttribute("name").equals("Components"))){
					if(map.size() > 0){
						if(map.containsKey(element.getAttribute("id")))
						{
							ComponentNodeMapping objMapping = map.get(element.getAttribute("id"));
							if(objMapping.getname().equals("DataGrid")){
								ComponentSubNodeMapping objSubMapping = new ComponentSubNodeMapping();

								if(element.getAttribute("type").equals("Field")){
									objSubMapping = objMapping.getobjsubnodemapping();
									objSubMapping.setjavaclass(element.getAttribute("classname"));
									objSubMapping.setfieldname(element.getAttribute("name"));
									objSubMapping.setdatatype(element.getAttribute("datatype"));
									objSubMapping.setmethod(element.getAttribute("method"));
									objSubMapping.setparameterindex(element.getAttribute("parameterindex"));
									objSubMapping.setservice(element.getAttribute("service"));
									objSubMapping.setserviceid(element.getAttribute("serviceid"));
									objMapping.setobjsubnodemapping(objSubMapping);
									//	objMapping.objSet.add(objSubMapping);
									objMapping.setObjSet(objSubMapping);
									//									map.put(objMapping.getid(),objMapping);
								}else{
									objSubMapping.setname(element.getAttribute("name"));
									objSubMapping.setclassname(element.getAttribute("classname"));
									objSubMapping.setid(element.getAttribute("id"));
									objMapping.setobjsubnodemapping(objSubMapping);
									objMapping.setObjSet(objSubMapping);
									//									map.put(objMapping.getid(),objMapping);
								}
								map.put(objMapping.getid(),objMapping);
							}else{
								if(element.getAttribute("type").equals("Field")){
									objMapping.setjavaclass(element.getAttribute("classname"));
									objMapping.setfieldname(element.getAttribute("name"));
									objMapping.setdatatype(element.getAttribute("datatype"));
									objMapping.setmethod(element.getAttribute("method"));
									objMapping.setparameterindex(element.getAttribute("parameterindex"));
									objMapping.setservice(element.getAttribute("service"));
									objMapping.setserviceid(element.getAttribute("serviceid"));
									objMapping.setparentclass(element.getAttribute("parentclass"));

									if(objMapping.getcomponentdetailcode().equals("-1")){
										objMapping.setpropertiescode(map.get(firstKey).getpropertiescode());
										objMapping.settemplatecode(map.get(firstKey).gettemplatecode());
									}
								}
								map.put(objMapping.getid(),objMapping);
							}

						}else{
							ComponentNodeMapping objMapping = new ComponentNodeMapping();
							objMapping.setname(element.getAttribute("name"));
							objMapping.setclassname(element.getAttribute("classname"));
							objMapping.setid(element.getAttribute("id"));

							objMapping.settemplatecode(element.getAttribute("templatecode"));
							objMapping.setpropertiescode(element.getAttribute("propertiescode"));
							objMapping.setcomponentdetailcode(element.getAttribute("componentdetailcode"));

							if(element.getAttribute("type").equals("Field")){
								objMapping.setjavaclass(element.getAttribute("classname"));
								objMapping.setfieldname(element.getAttribute("name"));
								objMapping.setdatatype(element.getAttribute("datatype"));
								objMapping.setmethod(element.getAttribute("method"));
								objMapping.setparameterindex(element.getAttribute("parameterindex"));
								objMapping.setservice(element.getAttribute("service"));
								objMapping.setserviceid(element.getAttribute("serviceid"));
								objMapping.setparentclass(element.getAttribute("parentclass"));

								if(objMapping.getcomponentdetailcode().equals("-1")){
									objMapping.setpropertiescode(map.get(firstKey).getpropertiescode());
									objMapping.settemplatecode(map.get(firstKey).gettemplatecode());
								}
							}
							if(!objMapping.getcomponentdetailcode().equals(""))
								map.put(objMapping.getid(),objMapping);
						}
					}else{
						ComponentNodeMapping objMapping = new ComponentNodeMapping();
						objMapping.setname(element.getAttribute("name"));
						objMapping.setclassname(element.getAttribute("classname"));
						objMapping.setid(element.getAttribute("id"));

						objMapping.settemplatecode(element.getAttribute("templatecode"));
						objMapping.setpropertiescode(element.getAttribute("propertiescode"));
						objMapping.setcomponentdetailcode(element.getAttribute("componentdetailcode"));
						if(element.getAttribute("type").equals("Field")){
							objMapping.setjavaclass(element.getAttribute("classname"));
							objMapping.setfieldname(element.getAttribute("name"));
							objMapping.setdatatype(element.getAttribute("datatype"));
							objMapping.setmethod(element.getAttribute("method"));
							objMapping.setparameterindex(element.getAttribute("parameterindex"));
							objMapping.setservice(element.getAttribute("service"));
							objMapping.setserviceid(element.getAttribute("serviceid"));
							objMapping.setparentclass(element.getAttribute("parentclass"));

							if(objMapping.getcomponentdetailcode().equals("-1")){
								objMapping.setpropertiescode(map.get(firstKey).getpropertiescode());
								objMapping.settemplatecode(map.get(firstKey).gettemplatecode());
							}
						}

						if(firstKey == null)
							firstKey = objMapping.getid();
						
						map.put(objMapping.getid(),objMapping);
					}
				}
			}
			System.out.println(indent + "ELEMENT_NODE");
			break;
		case Node.ENTITY_NODE:
			System.out.println(indent + "ENTITY_NODE");
			break;
		case Node.ENTITY_REFERENCE_NODE:
			System.out.println(indent + "ENTITY_REFERENCE_NODE");
			break;
		case Node.NOTATION_NODE:
			System.out.println(indent + "NOTATION_NODE");
			break;
		case Node.PROCESSING_INSTRUCTION_NODE:
			System.out.println(indent + "PROCESSING_INSTRUCTION_NODE");
			break;
		case Node.TEXT_NODE:
			System.out.println(indent + "TEXT_NODE");
			Text els = (Text) node;
			break;
		default:
			System.out.println(indent + "Unknown node");
			break;
		}
		NodeList list = node.getChildNodes();
		for(int i=0; i<list.getLength(); i++)
			dumpLoop(list.item(i),indent + "   ");
	}


	private void dumpLoopValueMember(Node node,String indent) {
		switch(node.getNodeType()) {
		case Node.CDATA_SECTION_NODE:
			System.out.println(indent + "CDATA_SECTION_NODE");
			break;
		case Node.COMMENT_NODE:
			System.out.println(indent + "COMMENT_NODE");
			break;
		case Node.DOCUMENT_FRAGMENT_NODE:
			System.out.println(indent + "DOCUMENT_FRAGMENT_NODE");
			break;
		case Node.DOCUMENT_NODE:
			System.out.println(indent + "DOCUMENT_NODE");
			break;
		case Node.DOCUMENT_TYPE_NODE:
			System.out.println(indent + "DOCUMENT_TYPE_NODE");
			break;
		case Node.ELEMENT_NODE:
			Element element = (Element) node;
			if (element.getNodeName().contains("node")) {

				if(!(element.getAttribute("name").equals("Components"))){
					if(map.size() > 0){
						if(map.containsKey(element.getAttribute("id")))
						{
							ComponentNodeMapping objMapping = map.get(element.getAttribute("id"));
							if(objMapping.getcomponentname().equals("DataGrid")){
								ComponentSubNodeMapping objSubMapping = new ComponentSubNodeMapping();

								if(element.getAttribute("type").equals("Field")){
									objSubMapping = objMapping.getobjsubnodemapping();
									objSubMapping.setjavaclass(element.getAttribute("classname"));
									objSubMapping.setfieldname(element.getAttribute("name"));
									objSubMapping.setdatatype(element.getAttribute("datatype"));
									objSubMapping.setmethod(element.getAttribute("method"));
									objSubMapping.setparameterindex(element.getAttribute("parameterindex"));
									objSubMapping.setservice(element.getAttribute("service"));
									objSubMapping.setserviceid(element.getAttribute("serviceid"));
									objMapping.setobjsubnodemapping(objSubMapping);
									//	objMapping.objSet.add(objSubMapping);
									objMapping.setObjSet(objSubMapping);
									//									map.put(objMapping.getid(),objMapping);
								}else{
									objSubMapping.setname(element.getAttribute("name"));
									objSubMapping.setclassname(element.getAttribute("classname"));
									objSubMapping.setid(element.getAttribute("id"));
									objSubMapping.setpropertiescode(element.getAttribute("propertiescode"));
									objMapping.setobjsubnodemapping(objSubMapping);
									objMapping.setObjSet(objSubMapping);
									//									map.put(objMapping.getid(),objMapping);
								}
								map.put(objMapping.getid(),objMapping);
							}else if(objMapping.getcomponentname().equals("ComboBox")){
								ComponentSubNodeMapping objSubMapping = new ComponentSubNodeMapping();

								if(element.getAttribute("type").equals("Field")){
									objSubMapping = objMapping.getobjsubnodemapping();
									objSubMapping.setjavaclass(element.getAttribute("classname"));
									objSubMapping.setfieldname(element.getAttribute("name"));
									objSubMapping.setdatatype(element.getAttribute("datatype"));
									objSubMapping.setmethod(element.getAttribute("method"));
									objSubMapping.setparameterindex(element.getAttribute("parameterindex"));
									objSubMapping.setservice(element.getAttribute("service"));
									objSubMapping.setserviceid(element.getAttribute("serviceid"));
									objMapping.setobjsubnodemapping(objSubMapping);
									//	objMapping.objSet.add(objSubMapping);
									objMapping.setObjSet(objSubMapping);
									//									map.put(objMapping.getid(),objMapping);
								}else{
									objSubMapping.setname(element.getAttribute("name"));
									objSubMapping.setclassname(element.getAttribute("classname"));
									objSubMapping.setid(element.getAttribute("id"));
									objSubMapping.setpropertiescode(element.getAttribute("propertiescode"));
									objMapping.setobjsubnodemapping(objSubMapping);
									objMapping.setObjSet(objSubMapping);
									//									map.put(objMapping.getid(),objMapping);
								}
								map.put(objMapping.getid(),objMapping);
							}
							else if(objMapping.getcomponentname().equals("SearchTextInput")){
								ComponentSubNodeMapping objSubMapping = new ComponentSubNodeMapping();

								if(element.getAttribute("type").equals("Field")){
									objSubMapping = objMapping.getobjsubnodemapping();
									objSubMapping.setjavaclass(element.getAttribute("classname"));
									objSubMapping.setfieldname(element.getAttribute("name"));
									objSubMapping.setdatatype(element.getAttribute("datatype"));
									objSubMapping.setmethod(element.getAttribute("method"));
									objSubMapping.setparameterindex(element.getAttribute("parameterindex"));
									objSubMapping.setservice(element.getAttribute("service"));
									objSubMapping.setserviceid(element.getAttribute("serviceid"));
									objMapping.setobjsubnodemapping(objSubMapping);
									//	objMapping.objSet.add(objSubMapping);
									objMapping.setObjSet(objSubMapping);
									//									map.put(objMapping.getid(),objMapping);
								}else{
									objSubMapping.setname(element.getAttribute("name"));
									objSubMapping.setclassname(element.getAttribute("classname"));
									objSubMapping.setid(element.getAttribute("id"));
									objSubMapping.setpropertiescode(element.getAttribute("propertiescode"));
									objMapping.setobjsubnodemapping(objSubMapping);
									objMapping.setObjSet(objSubMapping);
									//									map.put(objMapping.getid(),objMapping);
								}
								map.put(objMapping.getid(),objMapping);
							}
							else if(objMapping.getcomponentname().equals("List")){
								ComponentSubNodeMapping objSubMapping = new ComponentSubNodeMapping();

								if(element.getAttribute("type").equals("Field")){
									objSubMapping = objMapping.getobjsubnodemapping();
									objSubMapping.setjavaclass(element.getAttribute("classname"));
									objSubMapping.setfieldname(element.getAttribute("name"));
									objSubMapping.setdatatype(element.getAttribute("datatype"));
									objSubMapping.setmethod(element.getAttribute("method"));
									objSubMapping.setparameterindex(element.getAttribute("parameterindex"));
									objSubMapping.setservice(element.getAttribute("service"));
									objSubMapping.setserviceid(element.getAttribute("serviceid"));
									objMapping.setobjsubnodemapping(objSubMapping);
									//	objMapping.objSet.add(objSubMapping);
									objMapping.setObjSet(objSubMapping);
									//									map.put(objMapping.getid(),objMapping);
								}else{
									objSubMapping.setname(element.getAttribute("name"));
									objSubMapping.setclassname(element.getAttribute("classname"));
									objSubMapping.setid(element.getAttribute("id"));
									objSubMapping.setpropertiescode(element.getAttribute("propertiescode"));
									objMapping.setobjsubnodemapping(objSubMapping);
									objMapping.setObjSet(objSubMapping);
									//									map.put(objMapping.getid(),objMapping);
								}
								map.put(objMapping.getid(),objMapping);
							}
							else{
								objMapping.setjavaclass(element.getAttribute("classname"));
								objMapping.setfieldname(element.getAttribute("name"));
								objMapping.setdatatype(element.getAttribute("datatype"));
								objMapping.setmethod(element.getAttribute("method"));
								objMapping.setparameterindex(element.getAttribute("parameterindex"));
								objMapping.setservice(element.getAttribute("service"));
								objMapping.setparentclass(element.getAttribute("parentclass"));
								objMapping.setpropertiescode(element.getAttribute("propertiescode"));
								map.put(objMapping.getid(),objMapping);
							}

						}else{
							ComponentNodeMapping objMapping = new ComponentNodeMapping();
							objMapping.setname(element.getAttribute("name"));
							objMapping.setclassname(element.getAttribute("classname"));
							objMapping.setid(element.getAttribute("id"));
							objMapping.setcomponentdetailcode(element.getAttribute("componentdetailcode"));
							objMapping.setpropertiescode(element.getAttribute("propertiescode"));
							if(element.getAttribute("type").equals("Field")){
								objMapping.setjavaclass(element.getAttribute("classname"));
								objMapping.setfieldname(element.getAttribute("name"));
								objMapping.setdatatype(element.getAttribute("datatype"));
								objMapping.setmethod(element.getAttribute("method"));
								objMapping.setparameterindex(element.getAttribute("parameterindex"));
								objMapping.setservice(element.getAttribute("service"));
								objMapping.setparentclass(element.getAttribute("parentclass"));
							}
							map.put(objMapping.getid(),objMapping);
						}
					}else{
						ComponentNodeMapping objMapping = new ComponentNodeMapping();
						objMapping.setname(element.getAttribute("name"));
						objMapping.setclassname(element.getAttribute("classname"));
						objMapping.setid(element.getAttribute("id"));
						objMapping.setcomponentdetailcode(element.getAttribute("componentdetailcode"));
						objMapping.setpropertiescode(element.getAttribute("propertiescode"));
						objMapping.setcomponentname(element.getAttribute("componentname"));

						if(element.getAttribute("type").equals("Field")){
							objMapping.setjavaclass(element.getAttribute("classname"));
							objMapping.setfieldname(element.getAttribute("name"));
							objMapping.setdatatype(element.getAttribute("datatype"));
							objMapping.setmethod(element.getAttribute("method"));
							objMapping.setparameterindex(element.getAttribute("parameterindex"));
							objMapping.setservice(element.getAttribute("service"));
							objMapping.setparentclass(element.getAttribute("parentclass"));
						}

						map.put(objMapping.getid(),objMapping);
					}
				}
			}
			System.out.println(indent + "ELEMENT_NODE");
			break;
		case Node.ENTITY_NODE:
			System.out.println(indent + "ENTITY_NODE");
			break;
		case Node.ENTITY_REFERENCE_NODE:
			System.out.println(indent + "ENTITY_REFERENCE_NODE");
			break;
		case Node.NOTATION_NODE:
			System.out.println(indent + "NOTATION_NODE");
			break;
		case Node.PROCESSING_INSTRUCTION_NODE:
			System.out.println(indent + "PROCESSING_INSTRUCTION_NODE");
			break;
		case Node.TEXT_NODE:
			System.out.println(indent + "TEXT_NODE");
			Text els = (Text) node;
			break;
		default:
			System.out.println(indent + "Unknown node");
			break;
		}
		NodeList list = node.getChildNodes();
		for(int i=0; i<list.getLength(); i++)
			dumpLoopValueMember(list.item(i),indent + "   ");
	}

	@Override
	public void insertEventMapping(String paramtermapping,String resultsetmapping) throws Exception
	{
		int npropertiescode = 0;
		int ncomponentdetailcode = 0;
		int npropertiescodesub = 0;
		int ntemplateparametereventdetailcode = 0;
		int ntemplatecomponenteventpropertiesdetailcode = 0;
		int ntemplatecomponenteventpropertiesdetailcodeMethod = 0;
		int ntemplatesubcomponentdetailcode = 0;

		String scomponentname = "";
		String sclassname = "";
		String sdatatype = "";
		String sfieldname = "";
		String sid = "";
		String sjavaclass = "";
		String smethod = "";
		String sname = "";
		String sparameterindex = "";
		String sservice = "";
		String sserviceid = "";
		int nstatus = 1;
		int ncolumncode = 1; 

		TemplateComponentEventDetail objPopupTemplateComponentEventDetail;
		TemplateComponentEventPropertiesDetail objPopupTemplateComponentEventPropertiesDetail;
		TemplateComponentEventPropertiesDetail objPopupTemplateComponentEventPropertiesDetailMethod;
		TemplateParameterEventDetail objPopupTemplateParameterEventDetail;
		TemplateSubParameterEventDetail objPopupTemplateSubParameterEventDetail;
		ListMappingPropertiesDetail objPopupListMappingPropertiesDetail; 

		TemplateSubComponentDetail objPopupTemplateSubComponentDetail; 
		TemplateSubComponentPropertiesDetail objPopupTemplateSubComponentPropertiesDetail;

		ByteArrayInputStream bais = null;

		Map<Integer,Integer> paramterIndex= new TreeMap<Integer,Integer>();

		List<TemplateComponentEventDetail> list = new ArrayList<TemplateComponentEventDetail>();
		List<TemplateComponentEventPropertiesDetail> list1 = new ArrayList<TemplateComponentEventPropertiesDetail>();
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		DocumentBuilder db = dbf.newDocumentBuilder();
		Document dom;
		if(paramtermapping != null){
			if(paramtermapping != ""){
				map = new TreeMap<String, ComponentNodeMapping>();
				bais = new ByteArrayInputStream(paramtermapping.getBytes());
				dom = db.parse(bais);
				dumpLoop(dom,"");

				for (Map.Entry<String, ComponentNodeMapping> entry : map.entrySet()) {
					System.out.println("Key = " + entry.getKey() + ", Value = " + entry.getValue());
					ComponentNodeMapping objComponentNodeMapping = entry.getValue();

					//----
					ncomponentdetailcode = Integer.parseInt(objComponentNodeMapping.getcomponentdetailcode());
					npropertiescode = Integer.parseInt(objComponentNodeMapping.getpropertiescode());
					scomponentname = objComponentNodeMapping.getcomponentname();
					//-----

					//-----2
					npropertiescodesub = Integer.parseInt(objComponentNodeMapping.getpropertiescode());
					sclassname = objComponentNodeMapping.getclassname();
					sdatatype = objComponentNodeMapping.getdatatype();
					sfieldname = objComponentNodeMapping.getfieldname();
					sid = objComponentNodeMapping.getid();
					sjavaclass = objComponentNodeMapping.getjavaclass();
					smethod = objComponentNodeMapping.getmethod();
					sname = objComponentNodeMapping.getname();
					sparameterindex = objComponentNodeMapping.getparameterindex();
					sservice = objComponentNodeMapping.getservice();
					sserviceid = objComponentNodeMapping.getserviceid();



					if(ntemplatecomponenteventpropertiesdetailcodeMethod==0)
					{
						String st = "select c.* from templatecomponentdetail a" +
								" left outer join templatecomponentdetail b on a.ntemplatecomponentgroupdetailcode = b.ntemplatecomponentgroupdetailcode and" +
								" 	a.ntemplatecomponentdetailcode = " + ncomponentdetailcode + " and a.ncomponentcode = 20" +
								" join templatecomponenteventdetail c on a.ntemplatecomponentdetailcode = c.ntemplatecomponentdetailcode" +	
								" where c.npropertiescode = 7";

						objPopupTemplateComponentEventDetail = (TemplateComponentEventDetail) findBySinglePlainSql(st, TemplateComponentEventDetail.class).get(0);

						//PopupTemplateComponentEventPropertiesDetail for service
						objPopupTemplateComponentEventPropertiesDetail = new TemplateComponentEventPropertiesDetail(); 

						objPopupTemplateComponentEventPropertiesDetail.setntemplatecomponenteventdetailcode(objPopupTemplateComponentEventDetail.getntemplatecomponenteventdetailcode());
						objPopupTemplateComponentEventPropertiesDetail.setnpropertiescode(20);
						objPopupTemplateComponentEventPropertiesDetail.setspropertiesvalue(sserviceid);
						objPopupTemplateComponentEventPropertiesDetail.setnstatus(nstatus);

						//PopupTemplateComponentEventPropertiesDetail for method
						objPopupTemplateComponentEventPropertiesDetailMethod = new TemplateComponentEventPropertiesDetail(); 

						objPopupTemplateComponentEventPropertiesDetailMethod.setntemplatecomponenteventdetailcode(objPopupTemplateComponentEventDetail.getntemplatecomponenteventdetailcode());
						objPopupTemplateComponentEventPropertiesDetailMethod.setnpropertiescode(21);
						objPopupTemplateComponentEventPropertiesDetailMethod.setspropertiesvalue(smethod);
						objPopupTemplateComponentEventPropertiesDetailMethod.setnstatus(nstatus);

						List<TemplateComponentEventPropertiesDetail> lst = new ArrayCollection();

						lst.add(objPopupTemplateComponentEventPropertiesDetail);
						lst.add(objPopupTemplateComponentEventPropertiesDetailMethod);


						lst = (List<TemplateComponentEventPropertiesDetail>) insertBatch(lst,  SequencenoGenerator.class, "nsequenceno");


						objPopupTemplateComponentEventPropertiesDetailMethod = lst.get(1);


						ntemplatecomponenteventpropertiesdetailcodeMethod = objPopupTemplateComponentEventPropertiesDetailMethod.getntemplatecomponenteventpropertiesdetailcode();



					}
					//					if(scomponentname.equals("ComboBox") || scomponentname.equals("SearchTextInput"))
					//					{



					if(paramterIndex.size() > 0){
						if(!(paramterIndex.containsKey(Integer.parseInt(sparameterindex)))){
							objPopupTemplateParameterEventDetail = new TemplateParameterEventDetail(); 
							objPopupTemplateParameterEventDetail.setntemplatecomponenteventpropertiesdetailcode(ntemplatecomponenteventpropertiesdetailcodeMethod);
							objPopupTemplateParameterEventDetail.setsparametername(sdatatype);
							objPopupTemplateParameterEventDetail.setsclassname(sjavaclass);
							objPopupTemplateParameterEventDetail.setntype(nstatus);
							objPopupTemplateParameterEventDetail.setnstatus(nstatus);
							objPopupTemplateParameterEventDetail = (TemplateParameterEventDetail) insertObject(objPopupTemplateParameterEventDetail, SequencenoGenerator.class, "nsequenceno");
							ntemplateparametereventdetailcode = objPopupTemplateParameterEventDetail.getntemplateparametereventdetailcode();
							paramterIndex.put(Integer.parseInt(sparameterindex), ntemplateparametereventdetailcode);
						}else{
							ntemplateparametereventdetailcode = paramterIndex.get(Integer.parseInt(sparameterindex));
						}
					}else{
						objPopupTemplateParameterEventDetail = new TemplateParameterEventDetail(); 
						objPopupTemplateParameterEventDetail.setntemplatecomponenteventpropertiesdetailcode(ntemplatecomponenteventpropertiesdetailcodeMethod);
						objPopupTemplateParameterEventDetail.setsparametername(sdatatype);
						objPopupTemplateParameterEventDetail.setsclassname(sjavaclass);
						objPopupTemplateParameterEventDetail.setntype(nstatus);
						objPopupTemplateParameterEventDetail.setnstatus(nstatus);
						objPopupTemplateParameterEventDetail = (TemplateParameterEventDetail) insertObject(objPopupTemplateParameterEventDetail, SequencenoGenerator.class, "nsequenceno");
						ntemplateparametereventdetailcode = objPopupTemplateParameterEventDetail.getntemplateparametereventdetailcode();
						paramterIndex.put(Integer.parseInt(sparameterindex), ntemplateparametereventdetailcode);
					}

					//PopupTemplateParameterEventDetail








					//PopupTemplateSubParameterEventDetail
					objPopupTemplateSubParameterEventDetail = new TemplateSubParameterEventDetail(); 

					objPopupTemplateSubParameterEventDetail.setntemplateparametereventdetailcode(ntemplateparametereventdetailcode);
					objPopupTemplateSubParameterEventDetail.setntemplatecomponentdetailcode(ncomponentdetailcode);
					objPopupTemplateSubParameterEventDetail.setsfieldname(sfieldname);
					objPopupTemplateSubParameterEventDetail.setnstatus(nstatus);

					objPopupTemplateSubParameterEventDetail = (TemplateSubParameterEventDetail) insertObject(objPopupTemplateSubParameterEventDetail, SequencenoGenerator.class, "nsequenceno");
					//					}
					//-----2

					logging.info("Step seven--npropertiescode---->"+npropertiescode);
					if(objComponentNodeMapping.getObjSet() != null){
						if(objComponentNodeMapping.getObjSet().size() > 0){
							for(Iterator<ComponentSubNodeMapping> iterators=objComponentNodeMapping.getObjSet().iterator();iterators.hasNext();){
								ComponentSubNodeMapping objMapping = iterators.next();
								//


								System.err.println("getclassname===>"+sclassname);
								System.err.println("getdatatype===>"+sdatatype);
								System.err.println("getfieldname===>"+sfieldname);
								System.err.println("getid===>"+sid);
								System.err.println("getjavaclass===>"+sjavaclass);
								System.err.println("getmethod===>"+smethod);
								System.err.println("getname===>"+sname);
								System.err.println("getparameterindex===>"+sparameterindex);
								System.err.println("getservice===>"+sservice);
								//
							}
						}
					}
					logging.info("Step eight--npropertiescode---->"+npropertiescode);
				}
			}
		}

		logging.info("Step nine--npropertiescode---->"+npropertiescode);
		if(resultsetmapping != null){
			if(resultsetmapping != ""){
				map = new TreeMap<String, ComponentNodeMapping>();
				bais = new ByteArrayInputStream(resultsetmapping.getBytes());
				dom = db.parse(bais);
				dumpLoopValueMember(dom,"");

				for (Map.Entry<String, ComponentNodeMapping> entry : map.entrySet()) {
					System.out.println("Key = " + entry.getKey() + ", Value = " + entry.getValue() + ", ComponentId = " + entry.getValue().getcomponentdetailcode() + ", propertiescode = " + entry.getValue().getpropertiescode());

					ncomponentdetailcode = Integer.parseInt(entry.getValue().getcomponentdetailcode());
					npropertiescode = Integer.parseInt(entry.getValue().getpropertiescode());
					scomponentname = entry.getValue().getcomponentname();

					//PopupTemplateComponentEventDetail
					objPopupTemplateComponentEventDetail = new TemplateComponentEventDetail(); 

					objPopupTemplateComponentEventDetail.setntemplatecomponentdetailcode(ncomponentdetailcode);
					objPopupTemplateComponentEventDetail.setnpropertiescode(npropertiescode);
					objPopupTemplateComponentEventDetail.setnstatus(nstatus);

					objPopupTemplateComponentEventDetail = (TemplateComponentEventDetail) insertObject(objPopupTemplateComponentEventDetail, SequencenoGenerator.class, "nsequenceno");


					ComponentNodeMapping objComponentNodeMapping = entry.getValue();
					if(objComponentNodeMapping.getObjSet() != null){
						if(objComponentNodeMapping.getObjSet().size() > 0){
							for(Iterator<ComponentSubNodeMapping> iterators=objComponentNodeMapping.getObjSet().iterator();iterators.hasNext();){
								ComponentSubNodeMapping objMapping = iterators.next();

								npropertiescodesub = Integer.parseInt(objMapping.getpropertiescode());
								sclassname = objMapping.getclassname();
								sdatatype = objMapping.getdatatype();
								sfieldname = objMapping.getfieldname();
								sid = objMapping.getid();
								sjavaclass = objMapping.getjavaclass();
								smethod = objMapping.getmethod();
								sname = objMapping.getname();
								sparameterindex = objMapping.getparameterindex();
								sservice = objMapping.getservice();
								sserviceid = objMapping.getserviceid();

								System.err.println("getclassname===>"+sclassname);
								System.err.println("getdatatype===>"+sdatatype);
								System.err.println("getfieldname===>"+sfieldname);
								System.err.println("getid===>"+sid);
								System.err.println("getjavaclass===>"+sjavaclass);
								System.err.println("getmethod===>"+smethod);
								System.err.println("getname===>"+sname);
								System.err.println("getparameterindex===>"+sparameterindex);
								System.err.println("getservice===>"+sservice);


								if(ntemplatecomponenteventpropertiesdetailcodeMethod==0)
								{
									//PopupTemplateComponentEventPropertiesDetail for service
									objPopupTemplateComponentEventPropertiesDetail = new TemplateComponentEventPropertiesDetail(); 

									objPopupTemplateComponentEventPropertiesDetail.setntemplatecomponenteventdetailcode(objPopupTemplateComponentEventDetail.getntemplatecomponenteventdetailcode());
									objPopupTemplateComponentEventPropertiesDetail.setnpropertiescode(20);
									objPopupTemplateComponentEventPropertiesDetail.setspropertiesvalue(sserviceid);
									objPopupTemplateComponentEventPropertiesDetail.setnstatus(nstatus);

									//PopupTemplateComponentEventPropertiesDetail for method
									objPopupTemplateComponentEventPropertiesDetailMethod = new TemplateComponentEventPropertiesDetail(); 

									objPopupTemplateComponentEventPropertiesDetailMethod.setntemplatecomponenteventdetailcode(objPopupTemplateComponentEventDetail.getntemplatecomponenteventdetailcode());
									objPopupTemplateComponentEventPropertiesDetailMethod.setnpropertiescode(21);
									objPopupTemplateComponentEventPropertiesDetailMethod.setspropertiesvalue(smethod);
									objPopupTemplateComponentEventPropertiesDetailMethod.setnstatus(nstatus);

									List<TemplateComponentEventPropertiesDetail> lst = new ArrayCollection();

									lst.add(objPopupTemplateComponentEventPropertiesDetail);
									lst.add(objPopupTemplateComponentEventPropertiesDetailMethod);


									lst = (List<TemplateComponentEventPropertiesDetail>) insertBatch(lst,  SequencenoGenerator.class, "nsequenceno");


									objPopupTemplateComponentEventPropertiesDetailMethod = lst.get(1);


									ntemplatecomponenteventpropertiesdetailcodeMethod = objPopupTemplateComponentEventPropertiesDetailMethod.getntemplatecomponenteventpropertiesdetailcode();
								}
								if(scomponentname.equals("ComboBox") || scomponentname.equals("SearchTextInput"))
								{
									//PopupTemplateParameterEventDetail
									objPopupTemplateParameterEventDetail = new TemplateParameterEventDetail(); 

									objPopupTemplateParameterEventDetail.setntemplatecomponenteventpropertiesdetailcode(ntemplatecomponenteventpropertiesdetailcodeMethod);
									objPopupTemplateParameterEventDetail.setsparametername(sdatatype);
									objPopupTemplateParameterEventDetail.setsclassname(sjavaclass);
									objPopupTemplateParameterEventDetail.setntype(nstatus);
									objPopupTemplateParameterEventDetail.setnstatus(nstatus);

									objPopupTemplateParameterEventDetail = (TemplateParameterEventDetail) insertObject(objPopupTemplateParameterEventDetail, SequencenoGenerator.class, "nsequenceno");

									//PopupTemplateSubParameterEventDetail
									objPopupTemplateSubParameterEventDetail = new TemplateSubParameterEventDetail(); 

									objPopupTemplateSubParameterEventDetail.setntemplateparametereventdetailcode(objPopupTemplateParameterEventDetail.getntemplateparametereventdetailcode());
									objPopupTemplateSubParameterEventDetail.setntemplatecomponentdetailcode(ncomponentdetailcode);
									objPopupTemplateSubParameterEventDetail.setsfieldname(sfieldname);
									objPopupTemplateSubParameterEventDetail.setnstatus(nstatus);

									objPopupTemplateSubParameterEventDetail = (TemplateSubParameterEventDetail) insertObject(objPopupTemplateSubParameterEventDetail, SequencenoGenerator.class, "nsequenceno");
								}
								else if (scomponentname.equals("DataGrid"))
								{

									//PopupTemplateSubComponentDetail
									objPopupTemplateSubComponentDetail = new TemplateSubComponentDetail(); 

									objPopupTemplateSubComponentDetail.setntemplatecomponentdetailcode(ncomponentdetailcode);
									objPopupTemplateSubComponentDetail.setncolumncode(ncolumncode);
									objPopupTemplateSubComponentDetail.setnorderby(ncolumncode);
									objPopupTemplateSubComponentDetail.setnstatus(nstatus);

									objPopupTemplateSubComponentDetail = (TemplateSubComponentDetail) insertObject(objPopupTemplateSubComponentDetail, SequencenoGenerator.class, "nsequenceno");

									ntemplatesubcomponentdetailcode = objPopupTemplateSubComponentDetail.getntemplatesubcomponentdetailcode();

									ncolumncode++;

									//PopupTemplateSubComponentPropertiesDetail
									objPopupTemplateSubComponentPropertiesDetail = new TemplateSubComponentPropertiesDetail(); 

									objPopupTemplateSubComponentPropertiesDetail.setntemplatesubcomponentdetailcode(ntemplatesubcomponentdetailcode);
									objPopupTemplateSubComponentPropertiesDetail.setnpropertiescode(19);
									objPopupTemplateSubComponentPropertiesDetail.setspropertiesvalue(sname);
									objPopupTemplateSubComponentPropertiesDetail.setnstatus(nstatus);

									objPopupTemplateSubComponentPropertiesDetail = (TemplateSubComponentPropertiesDetail) insertObject(objPopupTemplateSubComponentPropertiesDetail, SequencenoGenerator.class, "nsequenceno");

								}

								if(scomponentname.equals("ComboBox") || scomponentname.equals("SearchTextInput") || scomponentname.equals("DataGrid"))
								{
									//PopupListMappingPropertiesDetail
									objPopupListMappingPropertiesDetail = new ListMappingPropertiesDetail(); 


									objPopupListMappingPropertiesDetail.setntemplatecomponentdetaillcode(ncomponentdetailcode);
									if (scomponentname.equals("DataGrid"))
									{
										objPopupListMappingPropertiesDetail.setntemplatesubcomponentdetailcode(ntemplatesubcomponentdetailcode);
									}

									objPopupListMappingPropertiesDetail.setnpropertiescode(npropertiescodesub);
									objPopupListMappingPropertiesDetail.setspropertiesvalue(sfieldname);
									objPopupListMappingPropertiesDetail.setntemplatecomponenteventdetailcode(objPopupTemplateComponentEventDetail.getntemplatecomponenteventdetailcode());
									objPopupListMappingPropertiesDetail.setnstatus(nstatus);

									objPopupListMappingPropertiesDetail = (ListMappingPropertiesDetail) insertObject(objPopupListMappingPropertiesDetail, SequencenoGenerator.class, "nsequenceno");
								}
							}
						}
					}
				}
			}
		}
	}

	//insertScreenTemplateComponent
	//	@Override
	//	public List<Object> insertScreenTemplateComponent(ScreenTemplateComponentGroupDetail objScreenTemplateComponentGroupDetail,ScreenTemplateComponentDetail objScreenTemplateComponentDetail)throws Exception{
	//
	//		//ScreenTemplateComponentGroupDetail 
	//
	//		if(objScreenTemplateComponentGroupDetail.getnscreentemplatecomponentgroupdetailcode()==0)
	//			objScreenTemplateComponentGroupDetail = (ScreenTemplateComponentGroupDetail) insertObject(objScreenTemplateComponentGroupDetail, SequencenoGenerator.class, "nsequenceno");
	//
	//		objScreenTemplateComponentDetail.setnscreentemplatecomponentgroupdetailcode(objScreenTemplateComponentGroupDetail.getnscreentemplatecomponentgroupdetailcode());
	//
	//
	//
	//		//ScreenTemplateComponentDetail
	//
	//		ScreenTemplateComponentDetail objComponent = (ScreenTemplateComponentDetail) insertObject(objScreenTemplateComponentDetail, SequencenoGenerator.class, "nsequenceno");
	//
	//		objComponent.setcomponentdetailcode(objComponent.getnscreentemplatecomponentdetailcode());
	//
	//		String st = " select 0 nscreentemplatecomponentpropertiesdetailcode," + 
	//				objComponent.getnscreentemplatecomponentdetailcode() + " nscreentemplatecomponentdetailcode, " +
	//				" p.npropertiescode,cp.sdefaultvalue spropertiesvalue,1 nstatus " +
	//				" from componentproperties cp " +
	//
	//				" join Properties p on p.npropertiescode = cp.npropertiescode and " +
	//				objComponent.getncomponentcode() + " = cp.ncomponentcode" +
	//				" where p.npropertytypecode = 4 and p.nstatus="+Enumeration.TransactionStatus.ACTIVE.gettransactionstatus();
	//
	//		List<ScreenTemplateComponentPropertiesDetail> lstComponentProperties = (List<ScreenTemplateComponentPropertiesDetail>) findBySinglePlainSql(st, ScreenTemplateComponentPropertiesDetail.class);
	//
	//
	//
	//		//ScreenTemplateComponentPropertiesDetail
	//
	//		insertBatch(lstComponentProperties, SequencenoGenerator.class, "nsequenceno");
	//
	//		List<Object> lst = new ArrayCollection();
	//
	//		lst.add(objComponent);
	//
	//		return lst;
	//
	//	}

	//insertPopupTemplate
	@Override
	public List<Object> insertPopupTemplate(TemplateDetail objPopupTemplateDetail) throws Exception{

		TemplateDetail obj = (TemplateDetail) insertObject(objPopupTemplateDetail, SequencenoGenerator.class, "nsequenceno");

		List<Object> lst = new ArrayCollection();;

		lst.add(obj);

		return lst;
	}

	//insertPopupTemplateComponent
	@Override
	public TemplateComponentDetail insertTemplateComponent(TemplateComponentGroupDetail objPopupTemplateComponentGroupDetail,TemplateComponentDetail objPopupTemplateComponentDetail)throws Exception{

		//PopupTemplateComponentGroupDetail 

		if(objPopupTemplateComponentGroupDetail != null){
			if(objPopupTemplateComponentGroupDetail.getntemplatecomponentgroupdetailcode()==0){

				String query = "select tcd.* from templatedetail td,templatecomponentgroupdetail tcgd,templatecomponentdetail tcd "
						+ " where td.ntemplatedetailcode = tcgd.ntemplatedetailcode and tcgd.ntemplatecomponentgroupdetailcode = tcd.ntemplatecomponentgroupdetailcode "
						+ " and ncomponentcode in("+Enumeration.SystemComponets.SUBMIT_BUTTON.getcomponentcode()+","+Enumeration.SystemComponets.CLOSE_BUTTON.getcomponentcode()+") and td.ntemplatedetailcode = "+objPopupTemplateComponentGroupDetail.getntemplatedetailcode()+"";

				objPopupTemplateComponentGroupDetail = (TemplateComponentGroupDetail) insertObject(objPopupTemplateComponentGroupDetail, SequencenoGenerator.class, "nsequenceno");

				if(!(((List<TemplateComponentDetail>)findBySinglePlainSql(query, TemplateComponentDetail.class)).size() > 0))
				{
					if(objPopupTemplateComponentGroupDetail.getntemplatetype() == Enumeration.TemplateType.POPUP_TEMPLATE.gettemplatetype())
					{
						List<TemplateComponentDetail> lst1 = new ArrayList<TemplateComponentDetail>();
						List<TemplateComponentEventDetail> lst2 = new ArrayList<TemplateComponentEventDetail>();

						List<TemplateComponentPropertiesDetail> lst3 = new ArrayList<TemplateComponentPropertiesDetail>();


						logging.info("step one");
						TemplateComponentDetail objDetail = new TemplateComponentDetail();
						objDetail.setncomponentcode(Enumeration.SystemComponets.CLOSE_BUTTON.getcomponentcode());
						objDetail.setntemplatecomponentgroupdetailcode(objPopupTemplateComponentGroupDetail.getntemplatecomponentgroupdetailcode());
						objDetail.setscomponentid("btnclose");
						objDetail.setnstatus(Enumeration.TransactionStatus.ACTIVE.gettransactionstatus());

						TemplateComponentDetail objDetail2 = new TemplateComponentDetail();
						objDetail2.setncomponentcode(Enumeration.SystemComponets.SUBMIT_BUTTON.getcomponentcode());
						objDetail2.setntemplatecomponentgroupdetailcode(objPopupTemplateComponentGroupDetail.getntemplatecomponentgroupdetailcode());
						objDetail2.setscomponentid("btnsubmit");
						objDetail2.setnstatus(Enumeration.TransactionStatus.ACTIVE.gettransactionstatus());

						lst1.add(objDetail);
						lst1.add(objDetail2);


						List<TemplateComponentDetail> lsts = (List<TemplateComponentDetail>) insertBatch(lst1,  SequencenoGenerator.class, "nsequenceno");

						logging.info("step one");

						for(TemplateComponentDetail objComponentDetail:lsts){

							TemplateComponentEventDetail objComponentEventDetail = new TemplateComponentEventDetail();
							TemplateComponentPropertiesDetail objPropertiesDetail = new TemplateComponentPropertiesDetail();

							logging.info("step sdfsdf");
							objComponentEventDetail.setntemplatecomponentdetailcode(objComponentDetail.getntemplatecomponentdetailcode());
							objComponentEventDetail.setnstatus(Enumeration.TransactionStatus.ACTIVE.gettransactionstatus());

							objPropertiesDetail.setnstatus(Enumeration.TransactionStatus.ACTIVE.gettransactionstatus());
							objPropertiesDetail.setntemplatecomponentdetailcode(objComponentDetail.getntemplatecomponentdetailcode());
							objPropertiesDetail.setnpropertiescode(Enumeration.Properties.LABEL.getpropertiescode());
							logging.info("step sdfsdf");
							objComponentEventDetail.setnstatus(Enumeration.TransactionStatus.ACTIVE.gettransactionstatus());
							if(objComponentDetail.getscomponentid().equals("btnclose")){
								objComponentEventDetail.setnpropertiescode(Enumeration.Properties.CLOSE.getpropertiescode());
								objPropertiesDetail.setspropertiesvalue(Enumeration.SystemComponets.CLOSE_BUTTON.getcomponentname());
							}else if(objComponentDetail.getscomponentid().equals("btnsubmit")){
								objComponentEventDetail.setnpropertiescode(Enumeration.Properties.SUBMIT.getpropertiescode());
								objPropertiesDetail.setspropertiesvalue(Enumeration.SystemComponets.SUBMIT_BUTTON.getcomponentname());
							}
							lst2.add(objComponentEventDetail);
							lst3.add(objPropertiesDetail);
						}
						insertBatch(lst2,  SequencenoGenerator.class, "nsequenceno");
						insertBatch(lst3,  SequencenoGenerator.class, "nsequenceno");
						logging.info("step sdfsdf");
					}
				}
			}
		}
		logging.info("step sdfsdf");
		objPopupTemplateComponentDetail.setntemplatecomponentgroupdetailcode(objPopupTemplateComponentGroupDetail.getntemplatecomponentgroupdetailcode());

		//PopupTemplateComponentDetail

		TemplateComponentDetail objComponent = (TemplateComponentDetail) insertObject(objPopupTemplateComponentDetail, SequencenoGenerator.class, "nsequenceno");
		objComponent.setcomponentdetailcode(objComponent.getntemplatecomponentdetailcode());

		String st = " select 0 ntemplatecomponentpropertiesdetailcode," + objComponent.getntemplatecomponentdetailcode() + 
				" ntemplatecomponentdetailcode, " +
				" p.npropertiescode,cp.sdefaultvalue spropertiesvalue,1 nstatus " +
				" from componentproperties cp " +

				" join Properties p on p.npropertiescode = cp.npropertiescode and " +
				objComponent.getncomponentcode() + " = cp.ncomponentcode" +
				" where p.npropertytypecode = 4 and p.nstatus="+Enumeration.TransactionStatus.ACTIVE.gettransactionstatus();

		List<TemplateComponentPropertiesDetail> lstComponentProperties = (List<TemplateComponentPropertiesDetail>) findBySinglePlainSql(st, TemplateComponentPropertiesDetail.class);

		insertBatch(lstComponentProperties, SequencenoGenerator.class, "nsequenceno");


		return objComponent;

	}

	@Override
	public void updateTemplateComponentPropertiesDetail(String scomponentid, int npropertiescode , String spropertiesvalue) throws Exception
	{
		final String querys = "update TemplateComponentPropertiesDetail set spropertiesvalue = '"+ spropertiesvalue +"'  from TemplateComponentDetail ptcd , TemplateComponentPropertiesDetail ptcpd " +
				"where ptcd.ntemplatecomponentdetailcode = ptcpd.ntemplatecomponentdetailcode " +
				"and ptcd.scomponentid = '"+ scomponentid +"' and ptcpd.npropertiescode = "+ npropertiescode +"" ;
		//logging.info("getOperators str ---> "+strQuery);
		// getHibernateTemplate().bulkUpdate(strQuery);


		getHibernateTemplate().execute(new HibernateCallback<Integer>() {

			@Override
			public Integer doInHibernate(Session sess)
					throws HibernateException, SQLException {
				// TODO Auto-generated method stub
				return sess.createSQLQuery(querys).executeUpdate();
			}
		});


	}

	@Override
	public List<TemplateComponentPropertiesDetail> getTemplateComponentPropertiesDetail(int ntemplatecomponentdetailcode) throws Exception{

		String st = "";

		if(ntemplatecomponentdetailcode>0)
			st = " ntemplatecomponentdetailcode = " + ntemplatecomponentdetailcode + " and ";

		st = " select npropertiescode,spropertiesvalue from TemplateComponentPropertiesDetail" +
				" where " + st + " nstatus = 1";

		return (List<TemplateComponentPropertiesDetail>) findBySinglePlainSql(st, TemplateComponentPropertiesDetail.class);
	}

	@Override
	public List<Employee> getEmployee() throws Exception{

		String st = " select * from employee";

		return (List<Employee>) findBySinglePlainSql(st, Employee.class);
	}


	@Override
	public List<Department> getDepartment() throws Exception{
		String st = " select * from department";

		return (List<Department>) findBySinglePlainSql(st, Department.class);
	}

	@Override
	public List getScreenDesign() throws Exception{


		String query = "DECLARE @cols AS NVARCHAR(MAX), @query  AS NVARCHAR(MAX) " +
				" select @cols = STUFF((SELECT ',' + QUOTENAME(p.spropertyname) from properties p " +
				" FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)'),1,1,'') print @cols " +
				" set @query = 'select sscreenname,scontainerid,sclassname,' + @cols + " +
				" 'from (" +
				" select PopTempDet.nscreentemplatedetailcode,PopTempDet.sscreenname, " +
				" PopTempCompGrpDet.nscreentemplatecomponentgroupdetailcode,PopTempCompGrpDet.scontainerid, " +
				" PopTempCompDet.nscreentemplatecomponentdetailcode, " +
				" PopTempCompDet.ncomponentcode,Comp.sclassname, Pro.spropertyname,PopTempProDet.spropertiesvalue " +
				" from screentemplatecomponentpropertiesdetail PopTempProDet join properties Pro on PopTempProDet.npropertiescode = Pro.npropertiescode " +
				" join screentemplatecomponentdetail PopTempCompDet on PopTempCompDet.nscreentemplatecomponentdetailcode = PopTempProDet.nscreentemplatecomponentdetailcode " +
				" join components Comp on Comp.ncomponentcode = PopTempCompDet.ncomponentcode " +
				" join screentemplatecomponentgroupdetail PopTempCompGrpDet on PopTempCompGrpDet.nscreentemplatecomponentgroupdetailcode = PopTempCompDet.nscreentemplatecomponentgroupdetailcode " +
				" join screentemplatedetail PopTempDet on PopTempDet.nscreentemplatedetailcode = PopTempCompGrpDet.nscreentemplatedetailcode " +
				" ) d " +
				" pivot " +
				" ( " +
				" max(spropertiesvalue) " +
				" for spropertyname in (' + @cols + ') " +
				" ) piv'; " +
				" print @query " +
				" execute(@query)";

		logging.info("query--> "+query);
		List<?> lstRtn = getJdbcTemplate().queryForList(query);

		return lstRtn;
	}

	@Override
	public List getPopUpDesign(int popuptemplatecode) throws Exception{

		String query = "DECLARE @cols AS NVARCHAR(MAX), @query  AS NVARCHAR(MAX) " +
				" select @cols = STUFF((SELECT ',' + QUOTENAME(p.spropertyname) from properties p " +
				" FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)') ,1,1,'') print @cols " +
				" set @query = 'select scomponentid,stitlename,scontainerid,sclassname,' + @cols + " +
				" 'from (" +
				" select PopTempCompDet.scomponentid,PopTempDet.ntemplatedetailcode,PopTempDet.stitlename, " +
				" PopTempCompGrpDet.ntemplatecomponentgroupdetailcode,PopTempCompGrpDet.scontainerid, " +
				" PopTempCompDet.ntemplatecomponentdetailcode, PopTempCompDet.ncomponentcode,Comp.sclassname, " +
				" Pro.spropertyname,PopTempProDet.spropertiesvalue from templatecomponentpropertiesdetail PopTempProDet " +
				" join properties Pro on PopTempProDet.npropertiescode = Pro.npropertiescode " +
				" join templatecomponentdetail PopTempCompDet on PopTempCompDet.ntemplatecomponentdetailcode = PopTempProDet.ntemplatecomponentdetailcode " +
				" join components Comp on Comp.ncomponentcode = PopTempCompDet.ncomponentcode " +
				" join templatecomponentgroupdetail PopTempCompGrpDet on PopTempCompGrpDet.ntemplatecomponentgroupdetailcode = PopTempCompDet.ntemplatecomponentgroupdetailcode " +
				" join templatedetail PopTempDet on PopTempDet.ntemplatedetailcode = PopTempCompGrpDet.ntemplatedetailcode " +
				" ) d " +
				" pivot " +
				" ( " +
				" max(spropertiesvalue) " +
				" for spropertyname in (' + @cols + ') " +
				" ) piv'; " +
				" print @query " +
				" execute(@query)";


		logging.info("query--> "+query);
		List<?> lstRtn = getJdbcTemplate().queryForList(query);

		return lstRtn;
	}

	private List<TemplateComponentDetail> getComponentDetails(int nPopUpCode)throws Exception {
		String query = "select ptcd.ntemplatecomponentdetailcode,cp.scomponentname,ptcgd.ntemplatecomponentgroupdetailcode,ptcgd.scontainerid,ptcgd.nnoofcontrols,ptcd.ncomponentcode, " +
				" ptcd.scomponentid,cp.sclassname from templatecomponentgroupdetail ptcgd, templatecomponentdetail ptcd, components cp " +
				" where ptcgd.ntemplatecomponentgroupdetailcode = ptcd.ntemplatecomponentgroupdetailcode and cp.ncomponentcode = ptcd.ncomponentcode " +
				" and ptcgd.ntemplatedetailcode = "+nPopUpCode+" and ptcgd.nstatus = "+Enumeration.TransactionStatus.ACTIVE.gettransactionstatus()+" and ptcd.nstatus = "+Enumeration.TransactionStatus.ACTIVE.gettransactionstatus()+" and cp.nstatus="+Enumeration.TransactionStatus.ACTIVE.gettransactionstatus()+"";

		return (List<TemplateComponentDetail>) findBySinglePlainSql(query, TemplateComponentDetail.class);
	}

	private Template getTemplateInfo(int nPopUpCode) throws Exception{
		String query = "select t.*,td.stitlename from template t,templatedetail td where t.ntemplatecode = td.ntemplatecode and td.ntemplatedetailcode = " + nPopUpCode + " and t.nstatus="+Enumeration.TransactionStatus.ACTIVE.gettransactionstatus()+"";
		return (Template)findBySingleObjectPlainSql(query, Template.class);
	}

	private List<TemplateComponentGroupDetail> getTemplateGroupInfo(int nPopUpCode) throws Exception{
		String query = "select tg.* from template t,templatedetail td,templatecomponentgroupdetail tg "
				+ " where t.ntemplatecode = td.ntemplatecode and td.ntemplatedetailcode=tg.ntemplatedetailcode and "
				+ " t.nstatus="+Enumeration.TransactionStatus.ACTIVE.gettransactionstatus()+" and td.nstatus="+Enumeration.TransactionStatus.ACTIVE.gettransactionstatus()+" "
				+ " and tg.nstatus="+Enumeration.TransactionStatus.ACTIVE.gettransactionstatus()+" and td.ntemplatedetailcode = " + nPopUpCode + "";
		return (List<TemplateComponentGroupDetail>) findBySinglePlainSql(query, TemplateComponentGroupDetail.class);
	}


	@Override
	public Map<Integer,Object> getTemplateComponentDesign(int nPopUpCode) throws Exception 
	{
		logging.info("nPopUpCode---> "+nPopUpCode);
		Map<Integer,Object> returnObject = new TreeMap<Integer,Object>();
		Map<String,Object> objProperties = null;

		List<TemplateComponentDetail> lstComponents = getComponentDetails(nPopUpCode);

		if(lstComponents != null && lstComponents.size() > 0)
		{
			objProperties = new HashMap<String,Object>();
			objProperties.put("Components",lstComponents);
			objProperties.put("InsertEvent",getInsertEventProperties(nPopUpCode));
			objProperties.put("Template",getTemplateInfo(nPopUpCode));
			objProperties.put("TemplateGroup",getTemplateGroupInfo(nPopUpCode));
			returnObject.put(-1,objProperties);

			for(TemplateComponentDetail obj : lstComponents)
			{
				objProperties = new HashMap<String,Object>();
				objProperties.put(Enumeration.PropertyType.COMMON.getpropertypename(),getCommonProperties(obj.getntemplatecomponentdetailcode()));
				objProperties.put(Enumeration.PropertyType.DATASOURCE.getpropertypename(),getDataSourceProperties(obj.getntemplatecomponentdetailcode()));
				returnObject.put(obj.getntemplatecomponentdetailcode(),objProperties);
			}
			//	objProperties = new HashMap<String,List>();
			//	objProperties.put("Template",getTemplateInfo(nPopUpCode));
			//	returnObject.put(-2,objProperties);
		}

		return returnObject;
	}

	private List<?> getCommonProperties(int componentdetailcode) throws Exception {

		String strQuery = " DECLARE @cols AS NVARCHAR(MAX), @query  AS NVARCHAR(MAX) select @cols = STUFF((SELECT ',' + QUOTENAME(p.sactualvalue) " +
				" from properties p where npropertytypecode = "+Enumeration.PropertyType.COMMON.getpropertypecode()+" FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)') ,1,1,'') " +
				" print @cols set @query = 'select stitlename,scontainerid,sclassname,' + @cols +  'from  ( " +
				" select PopTempDet.ntemplatedetailcode,PopTempDet.stitlename, PopTempCompGrpDet.ntemplatecomponentgroupdetailcode,PopTempCompGrpDet.scontainerid, " +
				" PopTempCompDet.ntemplatecomponentdetailcode, PopTempCompDet.ncomponentcode,Comp.sclassname, Pro.sactualvalue,PopTempProDet.spropertiesvalue " +
				" from templatecomponentpropertiesdetail PopTempProDet join properties Pro on PopTempProDet.npropertiescode = Pro.npropertiescode " +
				" join templatecomponentdetail PopTempCompDet on PopTempCompDet.ntemplatecomponentdetailcode = PopTempProDet.ntemplatecomponentdetailcode " +
				" join components Comp on Comp.ncomponentcode = PopTempCompDet.ncomponentcode join templatecomponentgroupdetail PopTempCompGrpDet on " +
				" PopTempCompGrpDet.ntemplatecomponentgroupdetailcode = PopTempCompDet.ntemplatecomponentgroupdetailcode join templatedetail PopTempDet on " +
				" PopTempDet.ntemplatedetailcode = PopTempCompGrpDet.ntemplatedetailcode where PopTempCompDet.ntemplatecomponentdetailcode in ("+componentdetailcode+") " +
				" ) d " +
				" pivot " +
				" ( " +
				" max(spropertiesvalue) " +
				" for sactualvalue in (' + @cols + ') " +
				" ) piv'; " +
				" print @query execute(@query)";

		logging.info("collectPopUpCommonProperties---> "+strQuery);


		List<?> lstRtn = getJdbcTemplate().queryForList(strQuery);

		return lstRtn;

	}

	private List<?> getDataSourceProperties(int componentdetailcode) throws Exception {

		String strQuery = "DECLARE @cols AS NVARCHAR(MAX), @query  AS NVARCHAR(MAX) select @cols = STUFF((SELECT ',' + QUOTENAME(p.sactualvalue) " +
				" from properties p where npropertytypecode = "+Enumeration.PropertyType.DATASOURCE.getpropertypecode()+" FOR XML PATH(''), TYPE ).value('.', 'NVARCHAR(MAX)'),1,1,'')  print @cols " +
				" set @query = 'select stitlename,scontainerid,scomponentname,spropertyname2,spropertiesvalue2,spropertiesvalue3,spropertiesvalue4,' + @cols + " +
				" 'from (select PopTempDet.ntemplatedetailcode,PopTempDet.stitlename, PopTempCompGrpDet.ntemplatecomponentgroupdetailcode,PopTempCompGrpDet.scontainerid, " +
				" PopTempCompDet.ntemplatecomponentdetailcode,  PopTempCompDet.ncomponentcode,Comp.scomponentname, PopLstMapProDet.ntemplatesubcomponentdetailcode, " +
				" Pro2.sactualvalue spropertyname2,  PopTempSubCompProDet.spropertiesvalue spropertiesvalue2,Pro3.sactualvalue spropertyname3,  " +
				" PopTempCompEvtProDet.spropertiesvalue spropertiesvalue3,Pro4.sactualvalue spropertyname4,  PopTempCompEvtProDet2.spropertiesvalue spropertiesvalue4, " +
				" Pro.sactualvalue,PopLstMapProDet.spropertiesvalue from listmappingpropertiesdetail PopLstMapProDet join properties Pro on PopLstMapProDet.npropertiescode = Pro.npropertiescode " +
				" left outer join templatesubcomponentpropertiesdetail PopTempSubCompProDet on PopTempSubCompProDet.ntemplatesubcomponentdetailcode = " +
				" PopLstMapProDet.ntemplatesubcomponentdetailcode left outer join properties Pro2 on  PopTempSubCompProDet.npropertiescode = Pro2.npropertiescode " +
				" left outer join templatecomponenteventdetail PopTempCompEvtDet on PopTempCompEvtDet.ntemplatecomponenteventdetailcode = PopLstMapProDet.ntemplatecomponenteventdetailcode " +
				" left outer join templatecomponenteventdetail PopTempCompEvtDet2 on PopTempCompEvtDet2.ntemplatecomponentdetailcode = PopLstMapProDet.ntemplatecomponentdetaillcode " +
				" and PopTempCompEvtDet2.npropertiescode = 12 left outer join templatecomponenteventpropertiesdetail PopTempCompEvtProDet on " +
				" PopTempCompEvtProDet.ntemplatecomponenteventdetailcode = PopTempCompEvtDet2.ntemplatecomponenteventdetailcode  and PopTempCompEvtProDet.npropertiescode = 20 " +
				" left outer join properties Pro3 on  PopTempCompEvtProDet.npropertiescode = Pro3.npropertiescode left outer join templatecomponenteventpropertiesdetail PopTempCompEvtProDet2 on " +
				" PopTempCompEvtProDet2.ntemplatecomponenteventdetailcode = PopTempCompEvtDet2.ntemplatecomponenteventdetailcode  and PopTempCompEvtProDet2.npropertiescode = 21 " +
				" left outer join properties Pro4 on  PopTempCompEvtProDet2.npropertiescode = Pro4.npropertiescode join templatecomponentdetail PopTempCompDet on " +
				" PopTempCompDet.ntemplatecomponentdetailcode = PopTempCompEvtDet.ntemplatecomponentdetailcode join components Comp on Comp.ncomponentcode = PopTempCompDet.ncomponentcode " +
				" join templatecomponentgroupdetail PopTempCompGrpDet on  PopTempCompGrpDet.ntemplatecomponentgroupdetailcode = PopTempCompDet.ntemplatecomponentgroupdetailcode " +
				" join templatedetail PopTempDet on  PopTempDet.ntemplatedetailcode = PopTempCompGrpDet.ntemplatedetailcode  where PopTempCompDet.ntemplatecomponentdetailcode = "+componentdetailcode+" ) d " +
				" pivot (max(spropertiesvalue) for sactualvalue in (' + @cols + ') ) piv'; print @query execute(@query)";

		logging.info("collectPopUpDataSourceProperties---> "+strQuery);
		List<?> lstRtn = getJdbcTemplate().queryForList(strQuery);

		return lstRtn;

	}

	private List getInsertEventProperties(int ntemplatedetailcode) throws Exception {
		List<?> lstRtn = null;
		String strQuery1 = "select tcd.ncomponentcode,td.ntemplatedetailcode as componentdetailcode,tcd.ntemplatecomponentdetailcode from templatedetail td,templatecomponentgroupdetail tcgd,templatecomponentdetail tcd " +
				" where td.ntemplatedetailcode = tcgd.ntemplatedetailcode and tcgd.ntemplatecomponentgroupdetailcode = tcd.ntemplatecomponentgroupdetailcode " +
				" and ncomponentcode = "+Enumeration.SystemComponets.SUBMIT_BUTTON.getcomponentcode()+" and td.ntemplatedetailcode = "+ntemplatedetailcode+" and " +
				" td.ntypecode = "+Enumeration.TemplateType.POPUP_TEMPLATE.gettemplatetype()+" and td.nstatus = "+Enumeration.TransactionStatus.ACTIVE.gettransactionstatus()+" and " +
				" tcgd.nstatus = "+Enumeration.TransactionStatus.ACTIVE.gettransactionstatus()+" and tcd.nstatus = "+Enumeration.TransactionStatus.ACTIVE.gettransactionstatus();

		List<TemplateComponentDetail> lstComponentDetails = (List<TemplateComponentDetail>) findBySinglePlainSql(strQuery1, TemplateComponentDetail.class);

		if(lstComponentDetails != null && lstComponentDetails.size() > 0)
		{
			String strQuery = "select method.spropertiesvalue methodname,method.servicename,method.ntemplatecomponentdetailcode,"
					+ " method.ncomponentcode,parameter.sparametername,parameter.sclassname, dense_rank()over(order by parameter.ntemplateparametereventdetailcode) rownum,"
					+ " field.sfieldname,'$'+field.scomponentid+'$' value,field.ntemplatecomponentdetailcode,field.scomponentid,field.ncomponentcode,field.sclassname "
					+ " from (select templatecomponentgroupdetail.ntemplatedetailcode,component.ntemplatecomponentdetailcode,component.scomponentid,component.ncomponentcode,"
					+ " componentclass.sclassname,field.sfieldname,field.ntemplateparametereventdetailcode from templatecomponentdetail component "
					+ " join templatecomponentgroupdetail on templatecomponentgroupdetail.ntemplatecomponentgroupdetailcode = component.ntemplatecomponentgroupdetailcode "
					+ " join components componentclass on componentclass.ncomponentcode = component.ncomponentcode "
					+ " join templatesubparametereventdetail field on component.ntemplatecomponentdetailcode = field.ntemplatecomponentdetailcode) field "
					+ " join templateparametereventdetail parameter on parameter.ntemplateparametereventdetailcode = field.ntemplateparametereventdetailcode "
					+ " join (select method.ntemplatecomponenteventpropertiesdetailcode,method.spropertiesvalue,service.spropertiesvalue servicename,"
					+ " TempCompEvtDet.ntemplatecomponentdetailcode,TempCompDet.ncomponentcode from templatecomponenteventpropertiesdetail method "
					+ " join templatecomponenteventdetail TempCompEvtDet on TempCompEvtDet.ntemplatecomponenteventdetailcode = method.ntemplatecomponenteventdetailcode "
					+ " join templatecomponentdetail TempCompDet on TempCompDet.ntemplatecomponentdetailcode = TempCompEvtDet.ntemplatecomponentdetailcode left "
					+ " join templatecomponenteventpropertiesdetail service on TempCompEvtDet.ntemplatecomponenteventdetailcode = service.ntemplatecomponenteventdetailcode "
					+ " and service.npropertiescode = 20) method on method.ntemplatecomponenteventpropertiesdetailcode = parameter.ntemplatecomponenteventpropertiesdetailcode "
					+ " where method.ncomponentcode = "+lstComponentDetails.get(0).getncomponentcode()+" and field.ntemplatedetailcode = "+ntemplatedetailcode+" and "
					+ " method.ntemplatecomponentdetailcode = "+lstComponentDetails.get(0).getntemplatecomponentdetailcode()+" for xml auto ";

			logging.info("collectPopUpDataSourceProperties---> "+strQuery);

			if(lstRtn == null)
				lstRtn = new ArrayList<>();

				lstRtn = getJdbcTemplate().queryForList(strQuery);
		}
		return lstRtn;
	}


	@Override
	public List<SectionMaster> getSection() throws Exception {
		return (List<SectionMaster>) findBySinglePlainSql("select * from sectionmaster", SectionMaster.class);
	}

	@Override
	public void insertEmployee(Employee objEmployee,Department objDepartment) throws Exception{
		insertObject(objEmployee, SequencenoGenerator.class, "nsequenceno");
	}

	@Override
	public void insertEmployee(Employee objEmployee) throws Exception{
		insertObject(objEmployee, SequencenoGenerator.class, "nsequenceno");
	}

	@Override
	public Object invokeInsertMethod(String templateValues) throws Exception {

		objGeneral.invokeTemplateMethod(templateValues);
		return null;
	}

	@Override
	public void insertListTesting1(List<Employee> lstEmployees) throws Exception{

	}
}





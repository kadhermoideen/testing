/**
 * @author S.Kadher Moideen
 */
package com.agaramtech.agdesign.service;

import java.util.List;
import java.util.Map;

import com.agaramtech.agdesign.pojo.ComponentProperties;
import com.agaramtech.agdesign.pojo.Department;
import com.agaramtech.agdesign.pojo.Employee;
import com.agaramtech.agdesign.pojo.PropertiesScreen;
import com.agaramtech.agdesign.pojo.SectionMaster;
import com.agaramtech.agdesign.pojo.TemplateComponentDetail;
import com.agaramtech.agdesign.pojo.TemplateComponentGroupDetail;
import com.agaramtech.agdesign.pojo.TemplateComponentPropertiesDetail;
import com.agaramtech.agdesign.pojo.TemplateDetail;
import com.agaramtech.lims.dao.support.AgaramEntityMethods;



public interface AgDesignDAO {
	
	/**
	* @author Kadher Moideen
	* @date 05-June-2014
	* @time 05:20:14 PM
	*/
	
	public String getAgDesignPreInitialize()throws Exception;
	public List<AgaramEntityMethods> getService()throws Exception;
	public List<PropertiesScreen> getPropertiesScreen() throws Exception;
	public String getServiceXML() throws Exception;
	public String getMethodXML(String classname) throws Exception;
	public String getMethodParameterXML(String servicename,String methodname) throws Exception;
	public String getEntityXML() throws Exception;
	public String getFieldsXML(String classname) throws Exception;
	public List<ComponentProperties> getControlsEvent(String scontrolclassname,int neventtype,int ntemplatecode)  throws Exception ;
	public String getComponentsXML(String dataProviderXML,String findXML,String insertXML,String id) throws Exception;
	public List<AgaramEntityMethods> getServicePublicMethod(String strService)   throws Exception;
	
	public List<AgaramEntityMethods> getMethodParameter(String strService,String strMethod)   throws Exception;
	public String getReturnTypeXML(String strService,String strMethod,String serviceid)   throws Exception;
	public void insertEventMapping(String paramtermapping,String resultsetmapping) throws Exception;
	public String getOperators() throws Exception;
	public String getConditionalArgument() throws Exception;
	public String getAgViewerPreInitialize() throws Exception;
	public String getPopUpEventProperties() throws Exception;
	public String getComponentsVariableXML(String dataProviderXML,String findXML,int itemIndex) throws Exception;
	
	public String getMethodParameterWithEntitFieldsXML(String servicename, String methodname,String serviceid)throws Exception;
	public String getParameterEntityFieldsXML(String dataProviderXML,String findXML,String classname,String oldXML,String oldClass) throws Exception;

	
	//public List<Object> insertScreenTemplate(ScreenTemplateDetail objScreenTemplateDetail)throws Exception;
	//public List<Object> insertScreenTemplateComponent(ScreenTemplateComponentGroupDetail objScreenTemplateComponentGroupDetail,ScreenTemplateComponentDetail objScreenTemplateComponentDetail)throws Exception;
	
	public List<Object> insertPopupTemplate(TemplateDetail objPopupTemplateDetail)throws Exception;
	public TemplateComponentDetail insertTemplateComponent(TemplateComponentGroupDetail objPopupTemplateComponentGroupDetail,TemplateComponentDetail objPopupTemplateComponentDetail)throws Exception;
	
	public void updateTemplateComponentPropertiesDetail(String scomponentid, int npropertiescode , String spropertiesvalue) throws Exception;
	public List<TemplateComponentPropertiesDetail> getTemplateComponentPropertiesDetail(int ntemplatecomponentdetailcode) throws Exception;
	public List<Employee> getEmployee() throws Exception;
	public List getScreenDesign() throws Exception;
	public List getPopUpDesign(int popuptemplatecode) throws Exception;
	public List<Department> getDepartment() throws Exception;
	
	
	public Map<Integer,Object> getTemplateComponentDesign(int nPopUpCode) throws Exception;
	
	public List<SectionMaster> getSection()throws Exception;
	
	public void insertEmployee(Employee objEmployee,Department objDepartment) throws Exception;
	public void insertEmployee(Employee objEmployee) throws Exception;
	
	public Object invokeInsertMethod(String templateValues) throws Exception;
	
	public void insertListTesting1(List<Employee> lstEmployees) throws Exception;
}

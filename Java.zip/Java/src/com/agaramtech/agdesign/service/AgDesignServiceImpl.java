/**
 * @author S.Kadher Moideen
 */
package com.agaramtech.agdesign.service;

import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.agaramtech.agdesign.pojo.ComponentProperties;
import com.agaramtech.agdesign.pojo.Department;
import com.agaramtech.agdesign.pojo.Employee;
import com.agaramtech.agdesign.pojo.PropertiesScreen;
import com.agaramtech.agdesign.pojo.SectionMaster;
import com.agaramtech.agdesign.pojo.TemplateComponentDetail;
import com.agaramtech.agdesign.pojo.TemplateComponentGroupDetail;
import com.agaramtech.agdesign.pojo.TemplateComponentPropertiesDetail;
import com.agaramtech.agdesign.pojo.TemplateDetail;
import com.agaramtech.lims.dao.support.AgaramEntityMethods;

import flex.messaging.io.ArrayCollection;

@SuppressWarnings("finally")
public class AgDesignServiceImpl implements AgDesignService {
	final Log logging = LogFactory.getLog(AgDesignServiceImpl.class);


	private AgDesignDAO objAgDesignDAO;


	public AgDesignDAO getObjAgDesignDAO() {
		return objAgDesignDAO;
	}

	public void setObjAgDesignDAO(AgDesignDAO objAgDesignDAO) {
		this.objAgDesignDAO = objAgDesignDAO;
	}

	/**
	 * @author Kadher Moideen
	 * @date 05-June-2014
	 * @time 05:20:14 PM
	 */

	@Override
	public String getAgDesignPreInitialize()throws Exception{
		String xml =null;
		try
		{
			xml = objAgDesignDAO.getAgDesignPreInitialize();
		}
		catch (Exception e) {
			logging.error("getAgDesignPreInitialize()"+e.getMessage());
			logging.error("getAgDesignPreInitialize()"+e.getCause());
			logging.error("getAgDesignPreInitialize()"+e.getLocalizedMessage());
		}
		finally{
			return xml;
		}
	}
	@Override
	public String getAgViewerPreInitialize() throws Exception
	{
		String xml =null;
		try
		{
			xml = objAgDesignDAO.getAgViewerPreInitialize();
		}
		catch (Exception e) {
			logging.error("getAgViewerPreInitialize()"+e.getMessage());
			logging.error("getAgViewerPreInitialize()"+e.getCause());
			logging.error("getAgViewerPreInitialize()"+e.getLocalizedMessage());
		}
		finally{
			return xml;
		}
	}
	@Override
	public String getPopUpEventProperties() throws Exception{
		String xml =null;
		try
		{
			xml = objAgDesignDAO.getPopUpEventProperties();
		}
		catch (Exception e) {
			logging.error("getPopUpEventProperties()"+e.getMessage());
			logging.error("getPopUpEventProperties()"+e.getCause());
			logging.error("getPopUpEventProperties()"+e.getLocalizedMessage());
		}
		finally{
			return xml;
		}
	}
	@Override
	public String getComponentsVariableXML(String dataProviderXML,String findXML,int itemIndex) throws Exception{
		String xml =null;
		try
		{
			xml = objAgDesignDAO.getComponentsVariableXML(dataProviderXML,findXML,itemIndex);
		}
		catch (Exception e) {
			logging.error("getComponentsVariableXML()"+e.getMessage());
			logging.error("getComponentsVariableXML()"+e.getCause());
			logging.error("getComponentsVariableXML()"+e.getLocalizedMessage());
		}
		finally{
			return xml;
		}
	}
	@Override
	public List<PropertiesScreen> getPropertiesScreen() throws Exception{
		List<PropertiesScreen> lst =null;
		try
		{
			lst = objAgDesignDAO.getPropertiesScreen();
		}
		catch (Exception e) {
			logging.error("getPropertiesScreen()"+e.getMessage());
			logging.error("getPropertiesScreen()"+e.getCause());
			logging.error("getPropertiesScreen()"+e.getLocalizedMessage());
		}
		finally{
			return lst;
		}
	}

	@Override
	public List<AgaramEntityMethods> getService() {
		try
		{
			return objAgDesignDAO.getService();
		}
		catch (Exception e) {
			logging.error("getService()"+e.getMessage());
			logging.error("getService()"+e.getCause());
			logging.error("getService()"+e.getLocalizedMessage());
			return null;
		}
	}

	@Override
	public String getEntityXML() throws Exception{
		String xml =null;
		try
		{
			xml = objAgDesignDAO.getEntityXML();
		}
		catch (Exception e) {
			logging.error("getEntityXML()"+e.getMessage());
			logging.error("getEntityXML()"+e.getCause());
			logging.error("getEntityXML()"+e.getLocalizedMessage());
		}
		finally{
			return xml;
		}
	}

	@Override
	public String getFieldsXML(String classname) throws Exception{
		String xml =null;
		try
		{
			xml = objAgDesignDAO.getFieldsXML(classname);
		}
		catch (Exception e) {
			logging.error("getFieldsXML()"+e.getMessage());
			logging.error("getFieldsXML()"+e.getCause());
			logging.error("getFieldsXML()"+e.getLocalizedMessage());
		}
		finally{
			return xml;
		}
	}

	@Override
	public String getComponentsXML(String dataProviderXML,String findXML,String insertXML,String id) throws Exception{
		String xml =null;
		try
		{
			xml = objAgDesignDAO.getComponentsXML(dataProviderXML,findXML,insertXML,id);
		}
		catch (Exception e) {
			logging.error("getComponentsXML()"+e.getMessage());
			logging.error("getComponentsXML()"+e.getCause());
			logging.error("getComponentsXML()"+e.getLocalizedMessage());
		}
		finally{
			return xml;
		}
	}

	@Override
	public List<ComponentProperties> getControlsEvent(String scontrolclassname,int neventtype,int ntemplatecode){
		try
		{
			return objAgDesignDAO.getControlsEvent(scontrolclassname,neventtype,ntemplatecode);
		}
		catch (Exception e) {
			logging.error("getEntityWithFields()"+e.getMessage());
			logging.error("getEntityWithFields()"+e.getCause());
			logging.error("getEntityWithFields()"+e.getLocalizedMessage());
			return null;
		}
	}


	@Override
	public List<AgaramEntityMethods> getServicePublicMethod(String strService){
		try
		{
			return objAgDesignDAO.getServicePublicMethod(strService);
		}
		catch (Exception e) {
			logging.error("getEntityWithFields()"+e.getMessage());
			logging.error("getEntityWithFields()"+e.getCause());
			logging.error("getEntityWithFields()"+e.getLocalizedMessage());
			return null;
		}
	}

	@Override
	public List<AgaramEntityMethods> getMethodParameter(String strService,String strMethod){
		try
		{
			return objAgDesignDAO.getMethodParameter(strService,strMethod);
		}
		catch (Exception e) {
			logging.error("getEntityWithFields()"+e.getMessage());
			logging.error("getEntityWithFields()"+e.getCause());
			logging.error("getEntityWithFields()"+e.getLocalizedMessage());
			return null;
		}
	}

	@Override
	public String getServiceXML(){
		try
		{
			return objAgDesignDAO.getServiceXML();
		}
		catch (Exception e) {
			logging.error("getEntityWithFields()"+e.getMessage());
			logging.error("getEntityWithFields()"+e.getCause());
			logging.error("getEntityWithFields()"+e.getLocalizedMessage());
			return null;
		}
	}

	@Override
	public String getMethodXML(String classname){
		try
		{
			return objAgDesignDAO.getMethodXML(classname);
		}
		catch (Exception e) {
			logging.error("getMethodXML()"+e.getMessage());
			logging.error("getMethodXML()"+e.getCause());
			logging.error("getMethodXML()"+e.getLocalizedMessage());
			return null;
		}
	}

	@Override
	public String getMethodParameterXML(String servicename, String methodname) {
		try
		{
			logging.info("servicename--> "+ servicename);
			logging.info("methodname--> "+ methodname);
			return objAgDesignDAO.getMethodParameterXML(servicename,methodname);
		}
		catch (Exception e) {
			logging.error("getMethodParameterXML()"+e.getMessage());
			logging.error("getMethodParameterXML()"+e.getCause());
			logging.error("getMethodParameterXML()"+e.getLocalizedMessage());
			return null;
		}
	}

	@Override
	public String getParameterEntityFieldsXML(String dataProviderXML,String findXML,String classname,String oldXML,String oldClass) throws Exception{
		String xml =null;
		try
		{
			xml = objAgDesignDAO.getParameterEntityFieldsXML(dataProviderXML,findXML,classname,oldXML,oldClass);
		}
		catch (Exception e) {
			logging.error("getParameterEntityFieldsXML()"+e.getMessage());
			logging.error("getParameterEntityFieldsXML()"+e.getCause());
			logging.error("getParameterEntityFieldsXML()"+e.getLocalizedMessage());
		}
		finally{
			return xml;
		}
	}

	@Override
	public String getReturnTypeXML(String strService, String strMethod,String serviceid) {
		try
		{
			return objAgDesignDAO.getReturnTypeXML(strService,strMethod,serviceid);
		}
		catch (Exception e) {
			logging.error("getReturnTypeXML()"+e.getMessage());
			logging.error("getReturnTypeXML()"+e.getCause());
			logging.error("getReturnTypeXML()"+e.getLocalizedMessage());
			return null;
		}
	}

	@Override
	public String getOperators()
	{
		String svalue = "";
		try
		{
			svalue =  objAgDesignDAO.getOperators();
		}
		catch (Exception e) {
			logging.error("getOperators()"+e.getMessage());
			logging.error("getOperators()"+e.getCause());
			logging.error("getOperators()"+e.getLocalizedMessage());
			//return svalue;
		}
		finally{
			return svalue;
		}
	}
	@Override
	public String getConditionalArgument()
	{
		String svalue = "";
		try
		{
			svalue =  objAgDesignDAO.getConditionalArgument();
		}
		catch (Exception e) {
			logging.error("getConditionalArgument()"+e.getMessage());
			logging.error("getConditionalArgument()"+e.getCause());
			logging.error("getConditionalArgument()"+e.getLocalizedMessage());
			//return svalue;
		}
		finally{
			return svalue;
		}
	}

	@Override
	public String getMethodParameterWithEntitFieldsXML(String servicename, String methodname,String serviceid)throws Exception{


		String xml =null;
		try
		{
			xml = objAgDesignDAO.getMethodParameterWithEntitFieldsXML(servicename,methodname,serviceid);
		}
		catch (Exception e) {
			logging.error("getMethodParameterWithEntitFieldsXML()"+e.getMessage());
			logging.error("getMethodParameterWithEntitFieldsXML()"+e.getCause());
			logging.error("getMethodParameterWithEntitFieldsXML()"+e.getLocalizedMessage());
		}
		finally{
			return xml;
		}
	}

	//screen function begin
	//	@Override
	//	public List<Object> insertScreenTemplate(ScreenTemplateDetail objScreenTemplateDetail)throws Exception{
	//
	//		List<Object> lst = new ArrayCollection();
	//
	//		try
	//		{
	//			lst = objAgDesignDAO.insertScreenTemplate(objScreenTemplateDetail);
	//		}
	//		catch (Exception e) {
	//			logging.error("insertScreenTemplate()"+e.getMessage());
	//			logging.error("insertScreenTemplate()"+e.getCause());
	//			logging.error("insertScreenTemplate()"+e.getLocalizedMessage());
	//		}
	//		finally{
	//			return lst;
	//		}
	//	}

	//	@Override
	//	public List<Object> insertScreenTemplateComponent(ScreenTemplateComponentGroupDetail objScreenTemplateComponentGroupDetail,ScreenTemplateComponentDetail objScreenTemplateComponentDetail)throws Exception{
	//
	//		List<Object> lst = new ArrayCollection();
	//
	//		try
	//		{
	//			lst =  objAgDesignDAO.insertScreenTemplateComponent(objScreenTemplateComponentGroupDetail,objScreenTemplateComponentDetail);
	//		}
	//		catch (Exception e) {
	//			logging.error("insertScreenTemplate()"+e.getMessage());
	//			logging.error("insertScreenTemplate()"+e.getCause());
	//			logging.error("insertScreenTemplate()"+e.getLocalizedMessage());
	//		}
	//		finally{
	//			return lst;
	//		}
	//	}
	//screen function end

	//popup function begin
	@Override
	public List<Object> insertPopupTemplate(TemplateDetail objPopupTemplateDetail)throws Exception{

		List<Object> lst = new ArrayCollection();

		try
		{
			lst = objAgDesignDAO.insertPopupTemplate(objPopupTemplateDetail);
		}
		catch (Exception e) {
			logging.error("insertScreenTemplate()"+e.getMessage());
			logging.error("insertScreenTemplate()"+e.getCause());
			logging.error("insertScreenTemplate()"+e.getLocalizedMessage());
		}
		finally{
			return lst;
		}
	}

	@Override
	public TemplateComponentDetail insertTemplateComponent(TemplateComponentGroupDetail objPopupTemplateComponentGroupDetail,TemplateComponentDetail objPopupTemplateComponentDetail)throws Exception{
		TemplateComponentDetail objComponentDetail = null;
		try	{
			objComponentDetail =  objAgDesignDAO.insertTemplateComponent(objPopupTemplateComponentGroupDetail,objPopupTemplateComponentDetail);
		}
		catch (Exception e) {
			logging.error("insertTemplateComponent()"+e.getMessage());
			logging.error("insertTemplateComponent()"+e.getCause());
			logging.error("insertTemplateComponent()"+e.getLocalizedMessage());
		}
		finally{
			return objComponentDetail;
		}
	}
	//popup function end

	@Override
	public String updateTemplateComponentPropertiesDetail(String scomponentid, int npropertiescode , String spropertiesvalue) throws Exception
	{
		String str ="";
		try
		{
			objAgDesignDAO.updateTemplateComponentPropertiesDetail(scomponentid, npropertiescode, spropertiesvalue);
		}
		catch (Exception e) 
		{
			logging.error("insertScreenTemplate()"+e.getMessage());
			logging.error("insertScreenTemplate()"+e.getCause());
			logging.error("insertScreenTemplate()"+e.getLocalizedMessage());
		}
		finally
		{
			return str;
		}
	}

	@Override
	public List<TemplateComponentPropertiesDetail> getTemplateComponentPropertiesDetail(int ntemplatecomponentdetailcode) throws Exception{
		try
		{
			return  objAgDesignDAO.getTemplateComponentPropertiesDetail(ntemplatecomponentdetailcode);
		}
		catch (Exception e) 
		{
			logging.error("getTemplateComponentPropertiesDetail()"+e.getMessage());
			logging.error("getTemplateComponentPropertiesDetail()"+e.getCause());
			logging.error("getTemplateComponentPropertiesDetail()"+e.getLocalizedMessage());
			return null;
		}
	}
	@Override
	public List<Department> getDepartment(){
		try
		{
			return  objAgDesignDAO.getDepartment();
		}
		catch (Exception e) 
		{
			logging.error("getDepartment()"+e.getMessage());
			logging.error("getDepartment()"+e.getCause());
			logging.error("getDepartment()"+e.getLocalizedMessage());
			return null;
		}
	}

	@Override
	public List<Employee> getEmployee(){
		try
		{
			return  objAgDesignDAO.getEmployee();
		}
		catch (Exception e) 
		{
			logging.error("getEmployee()"+e.getMessage());
			logging.error("getEmployee()"+e.getCause());
			logging.error("getEmployee()"+e.getLocalizedMessage());
			return null;
		}
	}

	@Override
	public List getScreenDesign(){
		try
		{
			return  objAgDesignDAO.getScreenDesign();
		}
		catch (Exception e) 
		{
			logging.error("getScreenDesign()"+e.getMessage());
			logging.error("getScreenDesign()"+e.getCause());
			logging.error("getScreenDesign()"+e.getLocalizedMessage());
			return null;
		}
	}

	@Override
	public List getPopUpDesign(int popuptemplatecode){
		try
		{
			return  objAgDesignDAO.getPopUpDesign(popuptemplatecode);
		}
		catch (Exception e) 
		{
			logging.error("getPopUpDesign()"+e.getMessage());
			logging.error("getPopUpDesign()"+e.getCause());
			logging.error("getPopUpDesign()"+e.getLocalizedMessage());
			return null;
		}
	}
	@Override
	public void insertEventMapping(String paramtermapping,String resultsetmapping) throws Exception{
		try
		{
			objAgDesignDAO.insertEventMapping(paramtermapping,resultsetmapping);
		}
		catch (Exception e) 
		{
			logging.error("insertEventMapping()"+e.getMessage());
			logging.error("insertEventMapping()"+e.getCause());
			logging.error("insertEventMapping()"+e.getLocalizedMessage());
		}
	}

	@Override
	public List<SectionMaster> getSection() {
		try
		{
			return objAgDesignDAO.getSection();
		}
		catch (Exception e) 
		{
			logging.error("getSection()"+e.getMessage());
			logging.error("getSection()"+e.getCause());
			logging.error("getSection()"+e.getLocalizedMessage());
			return null;
		}
	}

	@Override
	public Map<Integer,Object> getTemplateComponentDesign(
			int nPopUpCode) {
		try
		{
			return objAgDesignDAO.getTemplateComponentDesign(nPopUpCode);
		}
		catch (Exception e) 
		{
			logging.error("getTemplateComponentDesign()"+e.getMessage());
			logging.error("getTemplateComponentDesign()"+e.getCause());
			logging.error("getTemplateComponentDesign()"+e.getLocalizedMessage());
			return null;
		}
	}

	@Override
	public void insertEmployee(Employee objEmployee,Department objDepartment) throws Exception{
		try
		{
			objAgDesignDAO.insertEmployee(objEmployee,objDepartment);
		}
		catch (Exception e) 
		{
			logging.error("insertEmployee()"+e.getMessage());
			logging.error("insertEmployee()"+e.getCause());
			logging.error("insertEmployee()"+e.getLocalizedMessage());
		}
	}

	@Override
	public void insertEmployee(Employee objEmployee) throws Exception{
		try
		{
			logging.info("insertEmployee()1 ");
			objAgDesignDAO.insertEmployee(objEmployee);
			logging.info("insertEmployee()2 ");
		}
		catch (Exception e) 
		{
			logging.error("insertEmployee()"+e.getMessage());
			logging.error("insertEmployee()"+e.getCause());
			logging.error("insertEmployee()"+e.getLocalizedMessage());
		}
	}

	@Override
	public Object invokeInsertMethod(String templateValues) {
		try
		{
			return objAgDesignDAO.invokeInsertMethod(templateValues);
		}
		catch (Exception e) 
		{
			logging.error("invokeInsertMethod()"+e.getMessage());
			logging.error("invokeInsertMethod()"+e.getCause());
			logging.error("invokeInsertMethod()"+e.getLocalizedMessage());
			return null;
		}
	}

	@Override
	public void insertListTesting1(List<Employee> lstEmployees) {
		try
		{
			objAgDesignDAO.insertListTesting1(lstEmployees);
		}
		catch (Exception e) 
		{
			logging.error("invokeTemplateMethod()"+e.getMessage());
			logging.error("invokeTemplateMethod()"+e.getCause());
			logging.error("invokeTemplateMethod()"+e.getLocalizedMessage());
			 
		}
	}

}

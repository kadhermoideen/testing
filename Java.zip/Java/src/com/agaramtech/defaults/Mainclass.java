package com.agaramtech.defaults;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.agaramtech.agdesign.service.AgDesignServiceImpl;

public class Mainclass{ 

	public static void main(String arg[])
	{
		try{

			ApplicationContext ac =new ClassPathXmlApplicationContext("/applicationContext.xml");

			AgDesignServiceImpl ll =ac.getBean(AgDesignServiceImpl.class);

//			String provider = "<node name=\"Components\">"+
//					" <node propertiescode=\"7\" templatecode=\"5\" componentdetailcode=\"311\" id=\"cmb0\" componentname=\"ComboBox\" name=\"ComboBox\" classname=\"com.agaramtech.controls.lims.script.AgaramtechComboBox\"/>"+
//					" <node propertiescode=\"7\" templatecode=\"5\" componentdetailcode=\"312\" id=\"txt1\" componentname=\"TextInput\" name=\"TextInput\" classname=\"com.agaramtech.controls.lims.script.AgaramtechTextInput\"/>"+
//					"</node>"+
//					"<node name=\"++ Variables\"/>";
			
			
			String provider = "<node name=\"Components\"><node name=\"Components\">"+
			  "<node propertiescode=\"7\" templatecode=\"5\" componentdetailcode=\"3\" id=\"cmb0\" componentname=\"ComboBox\" name=\"ComboBox\" classname=\"com.agaramtech.controls.lims.script.AgaramtechComboBox\">"+
			   " <node parentclass=\"com.agaramtech.agdesign.pojo.Employee\" parameterindex=\"1\" serviceid=\"javaAgDesignService\" service=\"com.agaramtech.agdesign.service.AgDesignServiceImpl\" method=\"insertEmployee\" classname=\"com.agaramtech.agdesign.pojo.Employee\" datatype=\"int\" name=\"nemployeecode\" type=\"Field\" id=\"cmb0\"/>"+
			  "</node>"+
			  "<node propertiescode=\"7\" templatecode=\"5\" componentdetailcode=\"4\" id=\"txt1\" componentname=\"TextInput\" name=\"TextInput\" classname=\"com.agaramtech.controls.lims.script.AgaramtechTextInput\">"+
			   " <node parentclass=\"com.agaramtech.agdesign.pojo.Employee\" parameterindex=\"1\" serviceid=\"javaAgDesignService\" service=\"com.agaramtech.agdesign.service.AgDesignServiceImpl\" method=\"insertEmployee\" classname=\"com.agaramtech.agdesign.pojo.Employee\" datatype=\"int\" name=\"ndepartmentcode\" type=\"Field\" id=\"txt1\"/>"+
			  "</node>"+
			  "<node propertiescode=\"7\" templatecode=\"5\" componentdetailcode=\"5\" id=\"txa2\" componentname=\"TextArea\" name=\"TextArea\" classname=\"com.agaramtech.controls.lims.script.AgaramtechTextArea\">"+
			  "  <node parentclass=\"com.agaramtech.agdesign.pojo.Employee\" parameterindex=\"1\" serviceid=\"javaAgDesignService\" service=\"com.agaramtech.agdesign.service.AgDesignServiceImpl\" method=\"insertEmployee\" classname=\"com.agaramtech.agdesign.pojo.Employee\" datatype=\"class java.lang.String\" name=\"semployeename\" type=\"Field\" id=\"txa2\"/>"+
			  "</node>"+
			  "<node propertiescode=\"7\" templatecode=\"5\" componentdetailcode=\"6\" id=\"txt3\" componentname=\"SearchTextInput\" name=\"SearchTextInput\" classname=\"com.agaramtech.controls.lims.script.AgaramtechSearchTextInput\">"+
			  "  <node parentclass=\"com.agaramtech.agdesign.pojo.Employee\" parameterindex=\"1\" serviceid=\"javaAgDesignService\" service=\"com.agaramtech.agdesign.service.AgDesignServiceImpl\" method=\"insertEmployee\" classname=\"com.agaramtech.agdesign.pojo.Employee\" datatype=\"class java.lang.String\" name=\"semployeedesc\" type=\"Field\" id=\"txt3\"/>"+
			  "</node>"+
			"</node>"+
			"<node name=\"++ Variables\">"+
			"  <node propertiescode=\"-1\" templatecode=\"-1\" componentdetailcode=\"-1\" id=\"Variable0\" componentname=\"System-Variable\" name=\"Variable-0\" classname=\"java.lang.Object\">"+
			 "   <node parentclass=\"com.agaramtech.agdesign.pojo.Department\" parameterindex=\"2\" serviceid=\"javaAgDesignService\" service=\"com.agaramtech.agdesign.service.AgDesignServiceImpl\" method=\"insertEmployee\" classname=\"com.agaramtech.agdesign.pojo.Department\" datatype=\"int\" name=\"ndepartmentcode\" type=\"Field\" id=\"Variable0\"/>"+
			 " </node>"+
			 " <node propertiescode=\"-1\" templatecode=\"-1\" componentdetailcode=\"-1\" id=\"Variable1\" componentname=\"System-Variable\" name=\"Variable-1\" classname=\"java.lang.Object\">"+
			  "  <node parentclass=\"com.agaramtech.agdesign.pojo.Department\" parameterindex=\"2\" serviceid=\"javaAgDesignService\" service=\"com.agaramtech.agdesign.service.AgDesignServiceImpl\" method=\"insertEmployee\" classname=\"com.agaramtech.agdesign.pojo.Department\" datatype=\"class java.lang.String\" name=\"sdeptmentname\" type=\"Field\" id=\"Variable1\"/>"+
			  "</node>"+
			  "<node propertiescode=\"-1\" templatecode=\"-1\" componentdetailcode=\"-1\" id=\"Variable2\" componentname=\"System-Variable\" name=\"Variable-2\" classname=\"java.lang.Object\">"+
			  "  <node parentclass=\"com.agaramtech.agdesign.pojo.Department\" parameterindex=\"2\" serviceid=\"javaAgDesignService\" service=\"com.agaramtech.agdesign.service.AgDesignServiceImpl\" method=\"insertEmployee\" classname=\"com.agaramtech.agdesign.pojo.Department\" datatype=\"class java.lang.String\" name=\"sdepartmentdesc\" type=\"Field\" id=\"Variable2\"/>"+
			  "</node>"+
			"</node></node>";
//			String node="<node name=\"++ Variables\"/>";
			ll.insertEventMapping(provider,null);

		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
	}


}

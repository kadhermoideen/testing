package com.agaramtech.defaults;



import java.io.IOException;
import java.lang.annotation.Annotation;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.context.ApplicationContext;
import org.springframework.flex.core.AbstractDestinationFactory;
import org.springframework.flex.remoting.RemotingDestinationExporter;
import org.springframework.stereotype.Service;
import org.springframework.web.context.support.WebApplicationContextUtils;

/**
 * Servlet implementation class Testservlet
 */
@WebServlet("/Testservlet")
public class Testservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Testservlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	@Override
	@SuppressWarnings({ "unused", "unchecked" })
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		   response.setContentType("text/html");
	        ApplicationContext ac = WebApplicationContextUtils.getRequiredWebApplicationContext(getServletContext());
	       // CredentialServiceImpl cal = ac.getBean(CredentialServiceImpl.class);
	        ac.getBeanDefinitionNames();
	        ac.getBeanNamesForType(RemotingDestinationExporter.class, true, true);
	        
	     
	        
//	        flex.management.runtime.messaging.services.remoting.RemotingDestinationControl
	     
	Map<String,RemotingDestinationExporter> map=ac.getBeansOfType(RemotingDestinationExporter.class, false, true);
	
	for (Map.Entry<String, RemotingDestinationExporter> entry : map.entrySet()) {
		
		
	Method[] mtt=	entry.getValue().getClass().getSuperclass().getDeclaredMethods();
	
	Method mtha;
	try {
		mtha = entry.getValue().getClass().getSuperclass().getDeclaredMethod("getDestinationId",null);
		
		AbstractDestinationFactory djd=entry.getValue();
		
		RemotingDestinationExporter dddd = entry.getValue();
		//dddd.
		mtha.setAccessible(true);
		
		String returnValue = (String)
				mtha.invoke(entry.getValue(),(Object[]) null);
		Object obj = ac.getBean(returnValue);
		System.err.println(obj.getClass().getName());
		System.err.println(returnValue);
	} catch (NoSuchMethodException e2) {
		// TODO Auto-generated catch block
		e2.printStackTrace();
	} catch (SecurityException e2) {
		// TODO Auto-generated catch block
		e2.printStackTrace();
	} catch (IllegalAccessException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IllegalArgumentException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (InvocationTargetException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	
	

	
	/*	try {
		//	dfgsdfg kk = (dfgsdfg) entry.getValue().getClass().getSuperclass().newInstance();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		Method tryd=entry.getValue().getClass().getSuperclass().getDeclaredMethods()[3];
		System.err.println(tryd);
		//tryd.invoke(entry, null);
//		Field [] fields = objAbstractDestinationFactory.getDeclaredFields();
//		for(Field objField:fields){
//			objField.setAccessible(true);
//		}
//		System.out.println("Key : " + entry.getKey() + " Value : "
//			+ entry.getValue());
	}
	 
	 Class<? extends Annotation> arg0=Service.class;
	
Map<String, Object> mst=	 ac.getBeansWithAnnotation(arg0);
//
// List<String>  msf=new ArrayList<>(mst.keySet());
// List<Object>  msv=new ArrayList<>(mst.values());
//
// Map<String , Method[]> gfh =new TreeMap<String , Method[]>(); 
// Map<String ,Type[]> gfh1 =new TreeMap<String , Type[]>(); 
// for(int i=0;i<msf.size();i++)
// {
//	// Object dhd=  ;
//	
//	
//	 Method[] str= null;
//      Class<?>[] std=null;
//     str=ac.getBean(""+msf.get(i)+"").getClass().getDeclaredMethods(); 
//     for(int j=0;j<str.length;j++)
//     {
//    	 
//    	 std=  	str[j].getParameterTypes(); 
//    	 gfh1.put("m1"+i+""+j, std);
//     }
//
//List<Type[]> rrr= new ArrayList<>( gfh1.values());
//     
// System.out.println("ddd"+str);
//// List<> strwe1=Arrays.asList(str);
//
// 
// gfh.put("m1"+i+"", str);
//
// 
// System.out.println("ddd");
// }
//  
// for(int i=0;i<=msf.size();i++)
// {
//	// Object dhd=  ;
//	 Method[] strww= null;
//	 Type[]std=null;
//	 strww= gfh.get("m1"+i);
//	
//	 Arrays.asList(strww);
//	 std=	 (Type[]) strww.getClass().getTypeParameters();
//	 
//	
//
// }
//  
// 
// 
// RemotingDestinationExporter rrrtyj=	(RemotingDestinationExporter) ac.getBean("org.springframework.flex.remoting.RemotingDestinationExporter#0");
//	 
//
//	        
//  Map<String, RemotingDestinationExporter> tt=    ac.getBeansOfType(RemotingDestinationExporter.class);
//
//
//  
//  Object[]  treqw=  tt.values().toArray();
//
//   @SuppressWarnings("unchecked")
//   List track=   Arrays.asList(treqw);
//
//   List<RemotingDestinationExporter> tre=new ArrayList<RemotingDestinationExporter>(tt.values());
//  
//   
//
// //   Map<String, RemotingDestinationExporter> wtt=new HashMap<String, RemotingDestinationExporter>(tre);
//    Track ett=(Track)  tre.get(0);
//    
//    ett.getDestinationId();
// 
	  
	

    
//    try {
//	
//	
//	ett.getClass().getDeclaredFields();
//} catch (Exception e2) {
//	// TODO Auto-generated catch block
//	e2.printStackTrace();
//}
//   
//    
//    Class c = ett.getClass();
//    
//    c.getDeclaredFields();
//    c.getDeclaredMethods();
//    
//  //  c.getField("")
//    Class[] cArg = new Class[1];
//    cArg[0] = String.class;
//    cArg[0] = MessageBroker.class;
//    
//    try {
//		c.getMethod("destroyDestination", cArg);
//	} catch (NoSuchMethodException | SecurityException e1) {
//		// TODO Auto-generated catch block
//		e1.printStackTrace();
//	}
//    
//    try
//    {
//    //	   String json = gson.toJson(ett);	
//    }
//    catch(Exception e)
//    {
//    	
//    }
// 
//  
//    
// //   ett.initialize(id, configMap);
//    
//    
//
//
//	        try {
//				response.getWriter().print("Adding of numbers is = " + cal.getUserRole());
//			} catch (Exception e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//	        response.getWriter().close();
//		
//		
//	}
	}
}

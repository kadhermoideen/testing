package com.agaramtech.defaults;

import com.agaramtech.agdesign.pojo.PropertyType;
import com.agaramtech.lims.dao.support.global.AgaramtechGeneralfunction;


public class RowMapperTemplate {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		AgaramtechGeneralfunction.getRowMapper(PropertyType.class);
		

	}

}
